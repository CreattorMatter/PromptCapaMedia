# tnd-msa-sp-wsclientes0024

Microservicio que permite consultar la información básica de clientes del Banco Pichincha a partir de su número de identificación. Es la migración del servicio SOAP legacy `sqb-msa-wsclientes0024` (IBM IIB) a una arquitectura moderna basada en Spring Boot WebFlux y Apache CXF, exponiendo la operación `ConsultarIdentificacion01` con la misma interfaz SOAP del sistema original.

---

## 🔗 Referencias del Proyecto

| Recurso | Descripción | Enlace |
|---------|-------------|--------|
| **Repositorio** | Código fuente del servicio en Azure DevOps (Banco Pichincha) | [tnd-msa-sp-wsclientes0024](https://dev.azure.com/BancoPichinchaEC/tpl-middleware/_git/tnd-msa-sp-wsclientes0024) |
| **Diagrama de Arquitectura** | Vista interactiva del servicio en el landscape de IcePanel | [Ver en IcePanel](https://s.icepanel.io/wJSECZOwwNkkW8/Tf15/landscape/diagrams/viewer?diagram=Vk1guFX4AC&model=ug5bylgstas&overlay_tab=tags&x1=-1664.3&x2=2224.3&y1=-328&y2=1600) |

---

## Tecnologías

- **Lenguaje:** Java 21
- **Construcción y Gestión de Dependencias:** Gradle 9.4.1
- **Framework:** Spring Boot 3.5.10
- **Web:** Spring WebFlux (Reactivo — Project Reactor)
- **SOAP:** Apache CXF 4.1.1 (solo generación WSDL) + Spring WebFlux JAXB codec (serialización en runtime)
- **Arquitectura:** Hexagonal (Ports & Adapters)
- **Resiliencia:** Resilience4j (Circuit Breaker — desactivado por defecto)
- **Cobertura de Código:** Jacoco (mínimo 75% de instrucciones)
- **Testing:** JUnit 5 + Mockito + Reactor Test + Spring Boot Test (131 tests: 126 unitarios + 5 integración)

---

## Arquitectura del Microservicio

> 🗺️ **Diagrama interactivo**: Consulta la arquitectura completa del servicio en su contexto de landscape en [IcePanel](https://s.icepanel.io/wJSECZOwwNkkW8/Tf15/landscape/diagrams/viewer?diagram=Vk1guFX4AC&model=ug5bylgstas&overlay_tab=tags&x1=-1664.3&x2=2224.3&y1=-328&y2=1600).

El diagrama muestra el flujo de comunicación que sigue el microservicio `tnd-msa-sp-wsclientes0024` para resolver una consulta de cliente:

```
┌─────────────────────────────────────────────────────────────┐
│           ADAPTADOR DE ENTRADA — REST (ACTIVO)              │
│  WSClientes0024Controller  @RestController                  │
│  Spring JAXB codec (SoapEnvelopeRequestDto/ResponseDto)     │
│  POST /IntegrationBus/soap/WSClientes0024  (puerto 8080)    │
└─────────────────────┬───────────────────────────────────────┘
                      │ CustomerRequest + GenericHeaderIn
                      ▼
┌─────────────────────────────────────────────────────────────┐
│      CAPA DE APLICACIÓN (CustomerServiceImpl + Strategy)    │
│  1. validateRequest()          → código error "1" si vacío  │
│  2. normalizeIdentification()  → compatibilidad IIB         │
│  3. customerQueryStrategy.query() → delega al strategy bean │
└──────────────────┬──────────────────────┬───────────────────┘
                   │                      │
          [Primario OCP]          [Failover / Primario BANCS]
                   ▼                      ▼
   ┌───────────────────────┐   ┌──────────────────────────┐
   │ StratioCustomerAdapter│   │ BancsCustomerAdapter     │
   │ mdw-msa-sp-tmp-customer│  │ TX060480                 │
   │ POST SOAP (WebClient) │   │ lib-bnc-api-client       │
   │ XPath parse response  │   │ UMPClientes0002          │
   └───────────────────────┘   └──────────────────────────┘
```

### Patrón de Failover (Fase 3 — Activo)

| Configuración `CCC_CUSTOMER_DATASOURCE` | Fuente Primaria | Fuente Fallback |
|-----------------------------------------|-----------------|-----------------|
| `OCP` (predeterminado)                  | Stratio         | Bancs TX060480  |
| `BANCS`                                 | Bancs TX060480  | Stratio         |

El failover se activa automáticamente mediante `onErrorResume` si la fuente primaria falla (timeout, error HTTP, parse error). Si ambas fuentes fallan, se retorna HTTP 200 con el código y mensaje de error del último servicio consultado en el bloque `<error>` (compatibilidad 100% con IIB — corrección 30-mar-2026).

#### Comportamiento del Failover con Errores de Negocio

**Análisis confirmado** (30-mar-2026): El failover se activa **tanto para errores técnicos como para errores de negocio**, replicando 100% el comportamiento del IIB original.

**Escenarios de activación del failover** (cuando `CCC_CUSTOMER_FAILOVER_ENABLED=true`):

| Tipo de Error | Ejemplo | Failover Activo |
|---------------|---------|-----------------|
| **Error de negocio** | HTTP 200 con `<error><codigo>404</codigo>` | ✅ SÍ |
| **Error técnico** | HTTP 500, timeout, conexión rechazada | ✅ SÍ |
| **Circuit breaker abierto** | Resilience4j bloquea llamadas | ✅ SÍ |

**Ejemplo**: Si Stratio retorna HTTP 200 con `error.codigo="404"` (cliente no encontrado), el sistema automáticamente intenta consultar Bancs. Solo si Bancs también falla, se retorna el error de Bancs al cliente.

**Compatibilidad IIB**: El IIB original también activa failover cuando `serviceOut.error.codigo != '0'` (líneas 223-241 ESQL), no solo para errores técnicos.

---

## Configuración de Entorno de Desarrollo

### Prerrequisitos

- Java 21 instalado
- Acceso a Azure Artifacts (Banco Pichincha) para descargar `lib-bnc-api-client:1.0.0`
- Variables de entorno `ARTIFACT_USERNAME` y `ARTIFACT_TOKEN` configuradas

### Configurar credenciales para Azure Artifacts

```powershell
$env:ARTIFACT_USERNAME = "tu-usuario"
$env:ARTIFACT_TOKEN    = "tu-token-pat"
```

### Generar clases desde WSDL

```bash
./gradlew generateFromWsdl
```

### Compilar sin ejecutar tests

```bash
./gradlew clean build -x architectureReview -x test
```

---

## Variables dentro del Vault

**No aplica** — Las credenciales de conexión se gestionan mediante variables de entorno inyectadas desde Helm.

---

### Variables en `dev.yml` y `application.yml`

Las siguientes variables de entorno se configuran en el archivo `helm/dev.yml` y se referencian en `application.yml`. **Todas usan el prefijo `CCC_`** (estándar Banco Pichincha) y son obligatorias — si falta alguna, Spring Boot falla al arrancar.

#### Fuente de Datos del Cliente

| Variable                         | Descripción                                                                        | Valor por defecto |
|----------------------------------|------------------------------------------------------------------------------------|-------------------|
| `CCC_CUSTOMER_DATASOURCE`        | Fuente primaria: `OCP` (Stratio) o `BANCS` (Adaptador Bancs TX060480)             | `OCP`             |
| `CCC_CUSTOMER_FAILOVER_ENABLED`  | Habilitar failover automático entre fuentes (`true` / `false`)                     | `true`            |

#### Servicio Stratio (`mdw-msa-sp-tmp-customer`)

| Variable                                  | Descripción                                             | Valor por defecto |
|-------------------------------------------|---------------------------------------------------------|-------------------|
| `CCC_STRATIO_CUSTOMER_BASE_URL`           | URL base del servicio Stratio                           | `http://service-mdw-msa-sp-tmp-customer-credit-card.tpl-middleware.svc.cluster.local` |
| `CCC_STRATIO_CUSTOMER_ENDPOINT_PATH`      | Path del endpoint SOAP de Stratio                       | `/PartyReferenceDataDirectory/Reference/Retrieve` |
| `CCC_STRATIO_CUSTOMER_SOAP_NAMESPACE`     | Namespace del WSDL Stratio (`xmlns:ex`)                 | `http://example.com/wsdl/ExampleService` |
| `CCC_STRATIO_CUSTOMER_SOAP_OPERATION`     | Elemento raíz del Body SOAP de Stratio                  | `CustomerRequest` |
| `CCC_STRATIO_CUSTOMER_CONNECTION_TIMEOUT` | Timeout de conexión en ms                               | `2000` |
| `CCC_STRATIO_CUSTOMER_READ_TIMEOUT`       | Timeout de lectura en ms                                | `2000` |
| `CCC_STRATIO_CUSTOMER_MAX_CONNECTIONS`    | Máximo de conexiones simultáneas                        | `-1` (ilimitado) |
| `CCC_STRATIO_MAX_IN_MEMORY_SIZE`          | Buffer máximo respuesta Stratio                         | `5MB` |
| `CCC_STRATIO_PENDING_ACQUIRE_MAX_COUNT`   | Máx. adquisiciones pendientes                           | `-1` |
| `CCC_STRATIO_PENDING_ACQUIRE_TIMEOUT`     | Timeout adquisición conexión Stratio                    | `2s` |
| `CCC_STRATIO_MAX_IDLE_TIME`               | Tiempo máximo inactividad Stratio                       | `10s` |

#### Servicio Bancs API Client (TX060480)

| Variable                              | Descripción                                                  | Valor por defecto |
|---------------------------------------|--------------------------------------------------------------|-------------------|
| `CCC_BANCS_BASE_URL`                  | URL base del adaptador Bancs (`tnd-msa-ad-bnc-customers`)   | `http://service-tnd-msa-ad-bnc-customers.arq-adaptadores.svc.cluster.local/bancs/trx/` |
| `CCC_BANCS_CONNECT_TIMEOUT`           | Timeout de conexión Bancs (ms)                               | `2000` |
| `CCC_BANCS_READ_TIMEOUT`              | Timeout de lectura Bancs (ms)                                | `2000` |
| `CCC_BANCS_LIB_SUPPORT_ENABLED`       | Soporte IIB en `lib-bnc-api-client`                          | `true` |
| `CCC_BANCS_MAX_CONNECTIONS`           | Máx. conexiones pool Bancs                                   | `-1` (ilimitado) |
| `CCC_BANCS_MAX_IDLE_TIME`             | Tiempo máximo inactividad                                    | `10s` |
| `CCC_BANCS_PENDING_ACQUIRE_MAX_COUNT` | Máx. adquisiciones pendientes                                | `-1` |
| `CCC_BANCS_PENDING_ACQUIRE_TIMEOUT`   | Timeout adquisición conexión                                 | `2s` |
| `CCC_BANCS_MAX_IN_MEMORY_SIZE`        | Buffer máximo respuesta Bancs                                | `5MB` |

#### Logging

| Variable                    | Descripción                                            | Valor por defecto |
|-----------------------------|--------------------------------------------------------|-------------------|
| `CCC_LOG_COM_PICHINCHA_SP`  | Nivel de log para el paquete `com.pichincha.sp`        | `INFO`            |

---

## Cómo Ejecutar

### Ejecutar localmente

```bash
./gradlew bootRun
```

> La aplicación arranca en el puerto **8080** (Spring Boot default). Los endpoints quedan disponibles en:
> - Health: `http://localhost:8080/actuator/health`
> - Endpoint SOAP: `http://localhost:8080/IntegrationBus/soap/WSClientes0024`

### Ejecutar en puerto alternativo (si 8080 está en uso)

```powershell
$env:SERVER_PORT=8082; ./gradlew bootRun
```

### Verificar que el servicio está activo

```bash
curl http://localhost:8080/actuator/health
```

---

## API Endpoints

### SOAP — `POST /IntegrationBus/soap/WSClientes0024`

Expone la operación `ConsultarIdentificacion01` para consultar la información básica de un cliente del Banco Pichincha a partir de su número y tipo de identificación.

- **Endpoint:** `http://localhost:8080/IntegrationBus/soap/WSClientes0024`
- **Método:** `POST` — `Content-Type: text/xml | application/xml | application/soap+xml`
- **Namespace:** `http://bpichincha.com/servicios`
- **Operación:** `ConsultarIdentificacion01`

> ℹ️ **No existe endpoint `?wsdl`** — el adaptador JAX-WS fue eliminado (26-mar-2026). El servicio es un `@RestController` WebFlux que acepta/responde XML SOAP.

#### Params (entrada `bodyIn`)

| Campo             | Tipo     | Obligatorio | Descripción                                              |
|-------------------|----------|-------------|----------------------------------------------------------|
| `identificacion`  | `string` | ✅ Sí       | Número de identificación del cliente (máx. 17 caracteres) |
| `tipoIdentificacion` | `string` | ❌ No    | Tipo de identificación (`0001`=Cédula, `0002`=RUC, `0003`=Pasaporte) |

> ℹ️ **Validación de campos** (29-mar-2026):
> - `identificacion`: **OBLIGATORIO** — retorna error código `"1"` si está vacío o solo espacios
> - `tipoIdentificacion`: **OPCIONAL** (`minOccurs="0"` en XSD original) — puede ser `null` o vacío sin generar error

---

### Endpoints Consumidos

| Servicio                   | URL / Transacción                                              | Descripción                              |
|----------------------------|----------------------------------------------------------------|------------------------------------------|
| **Stratio** (primario OCP) | `POST {CCC_STRATIO_CUSTOMER_BASE_URL}{CCC_STRATIO_CUSTOMER_ENDPOINT_PATH}` | Consulta datos completos del cliente     |
| **Bancs TX060480** (fallback) | `{CCC_BANCS_BASE_URL}` → `UMPClientes0002/ConsultarInformacionBasica01` | Consulta información básica — CIF, nombre, estado |

---

### Explicación de la Lógica de Negocio

El microservicio implementa la lógica de negocio migrada del sistema IIB `sqb-msa-wsclientes0024` con **100% de compatibilidad** (validado 30-mar-2026):

1. **Validación de entrada** (heredada de IIB líneas 68-72 ESQL):
   - `identificacion`: **OBLIGATORIA** — retorna HTTP 200 con error código `"1"` y mensaje `"Valor del campo identificacion vacio o invalido"` en el bloque `<error>` si está vacía o solo espacios
   - `tipoIdentificacion`: **OPCIONAL** — no genera error si está ausente o vacía (IIB líneas 77-80 no valida este campo)

2. **Normalización de identificación** (heredada de IIB líneas 63-65 ESQL):
   - Si comienza con `"000"` y tiene más de 10 dígitos → extrae los últimos 10 caracteres
   - Ejemplo: `"0000000602119182"` (16 dígitos) → `"0602119182"` (10 dígitos)

3. **Selección dinámica de datasource**: La variable `CCC_CUSTOMER_DATASOURCE` determina la fuente primaria:
   - `OCP` (predeterminado): consulta primero a Stratio (`mdw-msa-sp-tmp-customer`)
   - `BANCS`: consulta primero a Bancs TX060480

4. **Failover automático** (`CCC_CUSTOMER_FAILOVER_ENABLED=true`): Si la fuente primaria falla (error de red, timeout, respuesta inválida), se activa automáticamente la fuente secundaria mediante `onErrorResume`.

5. **Mensaje de éxito diferenciado**: El campo `<mensaje>` del response varía según la fuente:
   - Respuesta desde Stratio → `"OK-OCP"` (compatibilidad IIB)
   - Respuesta desde Bancs → `"OK"` (compatibilidad IIB)

6. **Propagación de errores alineada con IIB** (corrección 30-mar-2026):
   - **Todos los errores de negocio retornan HTTP 200** con código y mensaje en el bloque `<error>`
   - Errores de Stratio/Bancs: código y mensaje originales preservados (ej: `<codigo>404</codigo>` `<mensaje>Cliente no encontrado</mensaje>`)
   - **Sin SOAP Fault para errores de negocio** — solo para errores técnicos inesperados
   - Cuando ambas fuentes fallan → retorna solo mensaje del **último servicio consultado** (Bancs en OCP→Bancs, Stratio en Bancs→OCP)
   - Compatibilidad 100% con comportamiento IIB original

---

### Resultado de la API

Ejemplo de respuesta exitosa de la operación `ConsultarIdentificacion01`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">
    <S:Body>
        <ns2:ConsultarIdentificacion01Response xmlns:ns2="http://bpichincha.com/servicios">
            <headerOut>
                <dispositivo>5CiD3iOF8whuBQEqbct1tlD2mAuclrM=</dispositivo>
                <empresa>0010</empresa>
                <canal>02</canal>
                <medio>020002</medio>
                <aplicacion>00270</aplicacion>
                <agencia>00012</agencia>
                <tipoTransaccion>304100111</tipoTransaccion>
                <usuario>USINTERT</usuario>
                <guid>550e8400e29b41d4a716446655440000</guid>
                <fechaHora>201608161239203000</fechaHora>
                <sesion>ASDASD77R01YH</sesion>
                <documento>
                    <fechaContable>20260320</fechaContable>
                    <numeroDocumento>000000001</numeroDocumento>
                </documento>
            </headerOut>
            <bodyOut>
                <CIF>3860119</CIF>
                <identificacion>0602119182</identificacion>
                <tipoIdentificacion>0001</tipoIdentificacion>
                <nombre>CAISATASIG TORANZO    DE CARCHIPULLA</nombre>
                <direccion>Amazonas 4545, Pereira,</direccion>
                <tipoCliente>01</tipoCliente>
                <estado>000</estado>
            </bodyOut>
            <error>
                <codigo>0</codigo>
                <mensaje>OK</mensaje>
                <mensajeNegocio>Consulta exitosa</mensajeNegocio>
                <tipo>INFO</tipo>
                <recurso>WSClientes0024/ConsultarIdentificacion01</recurso>
                <componente>ConsultarIdentificacion01</componente>
                <backend>00000</backend>
            </error>
        </ns2:ConsultarIdentificacion01Response>
    </S:Body>
</S:Envelope>
```

---

## Estructura del Resultado de la API

### `bodyOut` — Datos del Cliente

| Campo               | Descripción                                                                            |
|---------------------|----------------------------------------------------------------------------------------|
| `CIF`               | Código Interno de Fuente — identificador único del cliente en el core bancario         |
| `identificacion`    | Número de identificación del cliente consultado                                        |
| `tipoIdentificacion`| Tipo de identificación: `0001`=Cédula, `0002`=RUC, `0003`=Pasaporte                   |
| `nombre`            | Nombre completo del cliente                                                            |
| `direccion`         | Dirección registrada del cliente                                                       |
| `tipoCliente`       | Tipo de cliente (`01`=Normal, `02`=VIP, `03`=Corporativo)                              |
| `estado`            | Estado del cliente (`000`=Activo, otros valores según catálogo)                        |

### `error` — Resultado de la Operación

| Campo           | Descripción                                                                |
|-----------------|----------------------------------------------------------------------------|
| `codigo`        | Código de resultado: `0`=éxito, `1`=error de validación, otros=errores de Stratio/Bancs (ej: `404`, `999`) |
| `mensaje`       | Mensaje descriptivo: `OK` (desde Bancs), `OK-OCP` (desde Stratio), o mensaje de error original |
| `mensajeNegocio`| Descripción legible del resultado                                          |
| `tipo`          | Tipo de respuesta (`INFO`, `ERROR`)                                        |
| `recurso`       | Recurso invocado (`WSClientes0024/ConsultarIdentificacion01`)              |
| `componente`    | Componente que procesó la solicitud (`ConsultarIdentificacion01`)          |
| `backend`       | Código de backend del sistema origen                                       |

---

## Pruebas

Las pruebas se ejecutan con JUnit 5 + Mockito + Reactor Test + Spring Boot Test. La cobertura mínima requerida es del **75% de instrucciones** verificada con Jacoco.

```bash
# Ejecutar todos los tests
./gradlew test

# Generar reporte de cobertura HTML
./gradlew jacocoTestReport

# Verificar que se cumple el mínimo del 75%
./gradlew jacocoTestCoverageVerification
```

Los reportes de cobertura se generan en:
- **XML**: `build/jacoco/test.xml`
- **HTML**: `build/jacoco/html/index.html`

> Las clases generadas desde WSDL (`com/pichincha/sp/infrastructure/soap/generated/**`), las configuraciones (`infrastructure/config/**`) y la clase `Application` están excluidas de la cobertura.

### Estado Actual de Tests (31-mar-2026)

✅ **BUILD SUCCESSFUL** — Todos los tests pasando (131/131)

**Suite de tests**:
- ✅ **126 tests unitarios** con `@ExtendWith(MockitoExtension.class)`
- ✅ **5 tests de integración** con `@SpringBootTest` (`StratioWebClientConfigTest`)

**Correcciones recientes**:
- ✅ Eliminados tests de validación de `tipoIdentificacion` (campo opcional según IIB) (29-mar-2026)
- ✅ Ajustadas aserciones de mensajes de error para compatibilidad 100% con IIB (29-mar-2026)
- ✅ Validado comportamiento de failover con mensajes originales sin prefijos (29-mar-2026)
- ✅ **Implementada propagación de errores HTTP 200** para errores de Stratio/Bancs (30-mar-2026)
- ✅ **Creado test de integración para `StratioWebClientConfig`** (31-mar-2026)
- ✅ **Corregido uso de `@MockBean`** (reemplazo de `@MockitoBean` inexistente) (31-mar-2026)

---

### Casos de Pruebas

Los casos cubren todas las combinaciones de `CCC_CUSTOMER_DATASOURCE` (OCP / BANCS) × `CCC_CUSTOMER_FAILOVER_ENABLED` (true / false), más los casos de validación de entrada heredados del sistema IIB original.

La estrategia activa se selecciona **una sola vez al arranque** por `CustomerStrategyConfig` según esas dos variables. Identificación usada en todos los casos de integración: `0602119182` (cédula `0001`).

---

#### 🔵 Validaciones de Entrada (independientes del datasource)

| ID | Caso | Entrada | Resultado esperado | Estado |
|----|------|---------|-------------------|--------|
| TC-01 | `identificacion` vacía | `<identificacion></identificacion>` | HTTP 200 — `<codigo>1</codigo>` `<mensaje>Valor del campo identificacion vacio o invalido</mensaje>` en `<error>` (comportamiento heredado IIB, NO es SOAP Fault) | ✅ Verificado |
| TC-02 | `tipoIdentificacion` vacío u omitido | `<tipoIdentificacion></tipoIdentificacion>` o ausente | **NO genera error** — campo OPCIONAL según IIB (corrección 29-mar-2026) | ✅ Verificado |
| TC-03 | Normalización de ceros a la izquierda | `<identificacion>000000602119182</identificacion>` (15 dígitos, inicia con `000`) | Identificación normalizada a `0602119182` antes de consultar el servicio externo (log: `Normalizando identificación de 000000602119182 a 0602119182`) | ✅ Verificado |

---

#### 🟢 Estrategia 1 — `CCC_CUSTOMER_DATASOURCE=OCP` + `CCC_CUSTOMER_FAILOVER_ENABLED=true` → `OcpWithBancsFailoverStrategy` (predeterminada)

| ID | Caso | Condición | Resultado esperado | Mensaje `<error>` | Estado |
|----|------|-----------|--------------------|-------------------|--------|
| TC-04 | Stratio disponible | Stratio responde OK | HTTP 200 con datos del cliente. `dataSource=STRATIO` | `<codigo>0</codigo>` `<mensaje>OK-OCP</mensaje>` | ✅ Verificado (24-mar-2026) |
| TC-05 | Stratio falla → failover Bancs OK | URL de Stratio inválida o timeout | HTTP 200 con datos desde Bancs. `onErrorResume` activado. Log: `activando FAILOVER a Bancs TX060480` | `<codigo>0</codigo>` `<mensaje>OK</mensaje>` | ✅ Verificado (24-mar-2026) |
| TC-06 | Stratio falla → Bancs falla | URL de Stratio **y** Bancs inválidas | SOAP Fault HTTP 500. Log: `AMBOS SERVICIOS FALLARON`. Mensaje de error: **solo mensaje de Bancs** (último consultado) — compatibilidad IIB (corrección 29-mar-2026) | N/A — SOAP Fault | ✅ Verificado |

---

#### 🟡 Estrategia 2 — `CCC_CUSTOMER_DATASOURCE=OCP` + `CCC_CUSTOMER_FAILOVER_ENABLED=false` → `OcpOnlyStrategy`

| ID | Caso | Condición | Resultado esperado | Mensaje `<error>` | Estado |
|----|------|-----------|--------------------|-------------------|--------|
| TC-07 | Stratio disponible | Stratio responde OK | HTTP 200 con datos del cliente. `dataSource=STRATIO` | `<codigo>0</codigo>` `<mensaje>OK-OCP</mensaje>` | ✅ Verificado |
| TC-08 | Stratio falla (sin failover) | URL de Stratio inválida o timeout | HTTP 200 con código y mensaje de error de Stratio en `<error>`. No se intenta Bancs — compatibilidad IIB (corrección 30-mar-2026) | `<codigo>{código Stratio}</codigo>` `<mensaje>{mensaje Stratio}</mensaje>` | ⚠️ Requiere actualización de tests |

---

#### 🟠 Estrategia 3 — `CCC_CUSTOMER_DATASOURCE=BANCS` + `CCC_CUSTOMER_FAILOVER_ENABLED=true` → `BancsWithOcpFailoverStrategy`

| ID | Caso | Condición | Resultado esperado | Mensaje `<error>` | Estado |
|----|------|-----------|--------------------|-------------------|--------|
| TC-09 | Bancs disponible | Bancs TX060480 responde OK | HTTP 200 con datos del cliente. `dataSource=BANCS` | `<codigo>0</codigo>` `<mensaje>OK</mensaje>` | ✅ Verificado |
| TC-10 | Bancs falla → failover Stratio OK | URL de Bancs inválida o timeout | HTTP 200 con datos desde Stratio. `onErrorResume` activado. Log: `activando FAILOVER a Stratio` | `<codigo>0</codigo>` `<mensaje>OK-OCP</mensaje>` | ✅ Verificado |
| TC-11 | Bancs falla → Stratio falla | URL de Bancs **y** Stratio inválidas | HTTP 200 con código y mensaje de error de Stratio en `<error>` (último consultado). Log: `AMBOS SERVICIOS FALLARON` — compatibilidad IIB (corrección 30-mar-2026) | `<codigo>{código Stratio}</codigo>` `<mensaje>{mensaje Stratio}</mensaje>` | ⚠️ Requiere actualización de tests |

---

#### 🔴 Estrategia 4 — `CCC_CUSTOMER_DATASOURCE=BANCS` + `CCC_CUSTOMER_FAILOVER_ENABLED=false` → `BancsOnlyStrategy`

| ID | Caso | Condición | Resultado esperado | Mensaje `<error>` | Estado |
|----|------|-----------|--------------------|-------------------|--------|
| TC-12 | Bancs disponible | Bancs TX060480 responde OK | HTTP 200 con datos del cliente. `dataSource=BANCS` | `<codigo>0</codigo>` `<mensaje>OK</mensaje>` | ✅ Verificado |
| TC-13 | Bancs falla (sin failover) | URL de Bancs inválida o timeout | HTTP 200 con código y mensaje de error de Bancs en `<error>`. No se intenta Stratio — compatibilidad IIB (corrección 30-mar-2026) | `<codigo>{código Bancs}</codigo>` `<mensaje>{mensaje Bancs}</mensaje>` | ⚠️ Requiere actualización de tests |

---

#### Resumen de Combinaciones

| `CCC_CUSTOMER_DATASOURCE`                 | `CCC_CUSTOMER_FAILOVER_ENABLED` | Estrategia activa | Primario | Fallback |
|-------------------------------------------|--------------------------------|-------------------|----------|---------|
| `OCP` (o cualquier valor ≠ BANCS) | `true` | `OcpWithBancsFailoverStrategy` | Stratio → `OK-OCP` | Bancs TX060480 → `OK` |
| `OCP` (o cualquier valor ≠ BANCS) | `false` | `OcpOnlyStrategy` | Stratio → `OK-OCP` | — (sin fallback) |
| `BANCS` | `true` | `BancsWithOcpFailoverStrategy` | Bancs TX060480 → `OK` | Stratio → `OK-OCP` |
| `BANCS` | `false` | `BancsOnlyStrategy` | Bancs TX060480 → `OK` | — (sin fallback) |

---

### Resultado de la prueba de Carga

Pendiente de ejecución en ambiente de test.

### Resultado de la prueba de Rendimiento - Estrés

Pendiente de ejecución en ambiente de test.

---

## Ambientes en Openshift

El microservicio se despliega en el ambiente **OpenShift Container Platform (OCP)** del Banco Pichincha.

| Ambiente | Replicas | CPU Request | CPU Limit | Memoria Request | Memoria Limit |
|----------|----------|-------------|-----------|-----------------|---------------|
| DEV      | 1–1      | 100m        | 200m      | 350Mi           | 500Mi         |
| QA       | —        | —           | —         | —               | —             |
| PRD      | —        | —           | —         | —               | —             |


### Pipeline CI/CD

La integración continua se gestiona mediante **Azure Pipelines** (`azure-pipelines.yml`). Las imágenes Docker se construyen con el `Dockerfile` incluido en el repositorio y se publican en el registro de contenedores configurado en Helm.

