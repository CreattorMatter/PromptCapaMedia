package com.pichincha.sp.infrastructure.output.adapter.strategy;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevel;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import com.pichincha.sp.application.output.port.BancsCustomerPort;
import com.pichincha.sp.application.output.port.StratioCustomerPort;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class BancsWithOcpFailoverStrategyTest {

    @Mock
    private BancsCustomerPort bancsPort;

    @Mock
    private StratioCustomerPort stratioPort;

    @Mock
    private CustomLogLevelHandler customLogLevelHandler;

    private BancsWithOcpFailoverStrategy strategy;

    private CustomerRequest validRequest;

    @BeforeEach
    void setUp() {
        strategy = new BancsWithOcpFailoverStrategy(bancsPort, stratioPort, customLogLevelHandler);
        validRequest = new CustomerRequest("0602119182", "0001");
    }

    private Customer buildBancsCustomer() {
        return Customer.builder()
                .cif("3860119")
                .identificacion("0602119182")
                .nombre("CAISATASIG TORANZO")
                .estado("000")
                .dataSource(DataSourceTypeEnum.BANCS)
                .build();
    }

    private Customer buildStratioCustomer() {
        return Customer.builder()
                .cif("0000000003860119")
                .identificacion("0602119182")
                .nombre("CAISATASIG TORANZO CIURLIZA")
                .estado("000")
                .dataSource(null)
                .build();
    }

    @Test
    void givenBancsReturnsCustomer_whenQuery_thenReturnsCustomerAndStratioIsNeverInvoked() {
        // Given
        when(bancsPort.getCustomerInfo(any())).thenReturn(Mono.just(buildBancsCustomer()));

        // When
        Mono<Customer> result = strategy.query(validRequest, null);

        // Then
        StepVerifier.create(result)
                .assertNext(customer -> {
                    assertThat(customer.cif()).isEqualTo("3860119");
                    assertThat(customer.dataSource()).isEqualTo(DataSourceTypeEnum.BANCS);
                })
                .verifyComplete();

        verify(stratioPort, never()).getCustomerInfo(any(), any(), any());
        verify(customLogLevelHandler, never()).log(any(), any(), any(), any(Object.class));
    }

    @Test
    void givenBancsFailsWithMessage_andStratioAvailable_whenQuery_thenReturnsStratioCustomerAndLogsWarn() {
        // Given
        SoapRequestContext requestContext = SoapRequestContext.of("USINTERT", "02", "DEVICE-001");
        when(bancsPort.getCustomerInfo(any()))
                .thenReturn(Mono.error(new RuntimeException("Bancs unreachable")));
        when(stratioPort.getCustomerInfo(any(), isNull(), any()))
                .thenReturn(Mono.just(buildStratioCustomer()));

        // When
        Mono<Customer> result = strategy.query(validRequest, requestContext);

        // Then
        StepVerifier.create(result)
                .assertNext(customer -> {
                    assertThat(customer.cif()).isEqualTo("0000000003860119");
                    assertThat(customer.dataSource()).isEqualTo(DataSourceTypeEnum.STRATIO);
                })
                .verifyComplete();

        verify(stratioPort, times(1)).getCustomerInfo(validRequest, null, requestContext);
        verify(customLogLevelHandler, times(1))
                .log(eq(CustomLogLevel.WARN), any(), any(), any());
    }

    @Test
    void givenBancsFailsWithNullMessage_andStratioAvailable_whenQuery_thenLogsWithEmptyString() {
        // Given
        when(bancsPort.getCustomerInfo(any())).thenReturn(Mono.error(new RuntimeException()));
        when(stratioPort.getCustomerInfo(any(), isNull(), any()))
                .thenReturn(Mono.just(buildStratioCustomer()));

        // When
        Mono<Customer> result = strategy.query(validRequest, null);

        // Then
        StepVerifier.create(result)
                .expectNextCount(1)
                .verifyComplete();

        verify(customLogLevelHandler, times(1))
                .log(eq(CustomLogLevel.WARN), any(), any(), any());
    }

    @Test
    void givenBancsFails_andStratioFailsWithRuntimeException_whenQuery_thenWrapsInGlobalErrorExceptionFailover() {
        // Given
        when(bancsPort.getCustomerInfo(any()))
                .thenReturn(Mono.error(new RuntimeException("Bancs down")));
        when(stratioPort.getCustomerInfo(any(), isNull(), any()))
                .thenReturn(Mono.error(new RuntimeException("Stratio down")));

        // When
        Mono<Customer> result = strategy.query(validRequest, null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> {
                    assertThat(throwable).isInstanceOf(GlobalErrorException.class);
                    GlobalErrorException ex = (GlobalErrorException) throwable;
                    assertThat(ex.getErrorCode()).isEqualTo("999");
                    assertThat(ex.getMessage()).isEqualTo("Stratio down");
                    assertThat(ex.getComponent()).isEqualTo("FAILOVER");
                    return true;
                })
                .verify();

        verify(customLogLevelHandler, times(1))
                .log(eq(CustomLogLevel.WARN), any(), any(), any());
        verify(customLogLevelHandler, times(1))
                .log(eq(CustomLogLevel.ERROR), any(), any(), any());
    }

    @Test
    void givenBancsFails_andStratioFailsWithGlobalErrorException_whenQuery_thenPropagatesOriginalException() {
        // Given
        GlobalErrorException originalStratioError =
                new GlobalErrorException("E001", "Cliente no encontrado", "STRATIO");
        when(bancsPort.getCustomerInfo(any()))
                .thenReturn(Mono.error(new RuntimeException("Bancs down")));
        when(stratioPort.getCustomerInfo(any(), isNull(), any()))
                .thenReturn(Mono.error(originalStratioError));

        // When
        Mono<Customer> result = strategy.query(validRequest, null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> {
                    assertThat(throwable).isSameAs(originalStratioError);
                    GlobalErrorException ex = (GlobalErrorException) throwable;
                    assertThat(ex.getErrorCode()).isEqualTo("E001");
                    assertThat(ex.getMessage()).isEqualTo("Cliente no encontrado");
                    assertThat(ex.getComponent()).isEqualTo("STRATIO");
                    return true;
                })
                .verify();
    }

    @Test
    void givenBancsFailsWithNullMessage_andStratioFailsWithNullMessage_whenQuery_thenLogsWithEmptyStrings() {
        // Given
        when(bancsPort.getCustomerInfo(any())).thenReturn(Mono.error(new RuntimeException()));
        when(stratioPort.getCustomerInfo(any(), isNull(), any()))
                .thenReturn(Mono.error(new RuntimeException()));

        // When
        Mono<Customer> result = strategy.query(validRequest, null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> {
                    assertThat(throwable).isInstanceOf(GlobalErrorException.class);
                    GlobalErrorException ex = (GlobalErrorException) throwable;
                    assertThat(ex.getErrorCode()).isEqualTo("999");
                    assertThat(ex.getComponent()).isEqualTo("FAILOVER");
                    return true;
                })
                .verify();

        verify(customLogLevelHandler, times(1))
                .log(eq(CustomLogLevel.ERROR), any(), any(), any());
    }
}
