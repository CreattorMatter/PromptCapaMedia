package com.pichincha.sp.infrastructure.output.adapter.stratio.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.infrastructure.output.adapter.stratio.dto.StratioCustomerRequestDto;
import com.pichincha.sp.infrastructure.output.adapter.stratio.dto.StratioCustomerResponseDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

class StratioCustomerMapperTest {

    private StratioMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = Mappers.getMapper(StratioMapper.class);
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private StratioCustomerResponseDto.BodyOut buildBodyOut(
            String cif, String identification, String typeOfId,
            String name, String address, String custType, String status) {
        return StratioCustomerResponseDto.BodyOut.builder()
                .cif(cif)
                .identification(identification)
                .typeOfIdentification(typeOfId)
                .name(name)
                .address(address)
                .customerType(custType)
                .status(status)
                .build();
    }

    // ─── toCustomer tests ────────────────────────────────────────────────────

    @Test
    void givenBodyOutWithAllFields_whenToCustomer_thenMapsCorrectly() {
        // Given
        StratioCustomerResponseDto.BodyOut bodyOut = buildBodyOut(
                "0000000003860119", "0602119182", "0001",
                "JUAN PEREZ", "Av. Principal 123", "01", "000");
        CustomerRequest request = new CustomerRequest("0602119182", "0001");

        // When
        Customer result = mapper.toCustomer(bodyOut, request, "fallback-cif");

        // Then
        assertThat(result.cif()).isEqualTo("0000000003860119");
        assertThat(result.identificacion()).isEqualTo("0602119182");
        assertThat(result.tipoIdentificacion()).isEqualTo("0001");
        assertThat(result.nombre()).isEqualTo("JUAN PEREZ");
        assertThat(result.direccion()).isEqualTo("Av. Principal 123");
        assertThat(result.tipoCliente()).isEqualTo("01");
        assertThat(result.estado()).isEqualTo("000");
        assertThat(result.dataSource()).isEqualTo(DataSourceTypeEnum.STRATIO);
    }

    @Test
    void givenBodyOutWithNullCif_whenToCustomer_thenUsesFallbackCif() {
        // Given
        StratioCustomerResponseDto.BodyOut bodyOut = buildBodyOut(
                null, "0602119182", "0001",
                "JUAN PEREZ", null, "01", "000");
        CustomerRequest request = new CustomerRequest("0602119182", "0001");

        // When
        Customer result = mapper.toCustomer(bodyOut, request, "BANCS_CIF_999");

        // Then
        assertThat(result.cif()).isEqualTo("BANCS_CIF_999");
        assertThat(result.identificacion()).isEqualTo("0602119182");
        assertThat(result.tipoIdentificacion()).isEqualTo("0001");
        assertThat(result.nombre()).isEqualTo("JUAN PEREZ");
    }

    @Test
    void givenBodyOutWithNullIdentification_whenToCustomer_thenUsesIdentificationFromRequest() {
        // Given
        StratioCustomerResponseDto.BodyOut bodyOut = buildBodyOut(
                "123456", null, null,
                "JUAN PEREZ", null, null, null);
        CustomerRequest request = new CustomerRequest("0500563358", "0003");

        // When
        Customer result = mapper.toCustomer(bodyOut, request, "123456");

        // Then
        assertThat(result.cif()).isEqualTo("123456");
        assertThat(result.identificacion()).isEqualTo("0500563358");
        assertThat(result.tipoIdentificacion()).isEqualTo("0003");
        assertThat(result.nombre()).isEqualTo("JUAN PEREZ");
    }

    @Test
    void givenBodyOutWithData_whenToCustomer_thenApellidosAndNombresAreEmptyStrings() {
        // Given
        StratioCustomerResponseDto.BodyOut bodyOut = buildBodyOut(
                "123", "0602119182", "0001",
                "NOMBRE COMPLETO", null, "01", "000");
        CustomerRequest request = new CustomerRequest("0602119182", "0001");

        // When
        Customer result = mapper.toCustomer(bodyOut, request, "123");

        // Then
        assertThat(result.apellidos()).isEmpty();
        assertThat(result.nombres()).isEmpty();
    }

    @Test
    void givenRealServiceData_whenToCustomer_thenMapsCorrectly() {
        // Given
        StratioCustomerResponseDto.BodyOut bodyOut = buildBodyOut(
                "0000000003860119", "0602119182", "0001",
                "CAISATASIG TORANZO  CIURLIZA ESCALERA DE CARCHIPULLA",
                "MEDARDO ANGEL SILVA", "01", "000");
        CustomerRequest request = new CustomerRequest("0602119182", "0001");

        // When
        Customer result = mapper.toCustomer(bodyOut, request, null);

        // Then
        assertThat(result.cif()).isEqualTo("0000000003860119");
        assertThat(result.nombre()).isEqualTo("CAISATASIG TORANZO  CIURLIZA ESCALERA DE CARCHIPULLA");
        assertThat(result.direccion()).isEqualTo("MEDARDO ANGEL SILVA");
        assertThat(result.estado()).isEqualTo("000");
        assertThat(result.dataSource()).isEqualTo(DataSourceTypeEnum.STRATIO);
    }

    // ─── toSoapRequest tests ─────────────────────────────────────────────────

    @Test
    void givenValidCustomerRequest_whenToSoapRequest_thenBuildsCorrectEnvelope() {
        // Given
        CustomerRequest request = new CustomerRequest("0602119182", "0001");

        // When
        StratioCustomerRequestDto result = mapper.toSoapRequest(
                request, "http://example.com/wsdl/ExampleService", "CustomerRequest");

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getHeader()).isNotNull();
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getCustomerRequest()).isNotNull();
        assertThat(result.getBody().getCustomerRequest().getIdentificationId()).isEqualTo("0602119182");
        assertThat(result.getBody().getCustomerRequest().getIdentificationTypeId()).isEqualTo("0001");
    }

    @Test
    void givenDifferentValues_whenToSoapRequest_thenUsesRequestValues() {
        // Given
        CustomerRequest request = new CustomerRequest("1712485630", "0002");

        // When
        StratioCustomerRequestDto result = mapper.toSoapRequest(
                request, "http://other.namespace", "OtherOperation");

        // Then
        assertThat(result.getBody().getCustomerRequest().getIdentificationId()).isEqualTo("1712485630");
        assertThat(result.getBody().getCustomerRequest().getIdentificationTypeId()).isEqualTo("0002");
    }

    // ─── Validation helper tests ─────────────────────────────────────────────

    @Test
    void givenSuccessError_whenIsSuccessResponse_thenReturnsTrue() {
        // Given
        StratioCustomerResponseDto.Error error = StratioCustomerResponseDto.Error.builder()
                .codError("0")
                .descError("OK")
                .build();

        // When / Then
        assertThat(mapper.isSuccessResponse(error)).isTrue();
    }

    @Test
    void givenNonZeroError_whenIsSuccessResponse_thenReturnsFalse() {
        // Given
        StratioCustomerResponseDto.Error error = StratioCustomerResponseDto.Error.builder()
                .codError("E001")
                .descError("Cliente no encontrado")
                .build();

        // When / Then
        assertThat(mapper.isSuccessResponse(error)).isFalse();
    }

    @Test
    void givenNullError_whenIsSuccessResponse_thenReturnsFalse() {
        // When / Then
        assertThat(mapper.isSuccessResponse(null)).isFalse();
    }

    @Test
    void givenError_whenGetErrorCode_thenReturnsCode() {
        // Given
        StratioCustomerResponseDto.Error error = StratioCustomerResponseDto.Error.builder()
                .codError("E001")
                .build();

        // When / Then
        assertThat(mapper.getErrorCode(error)).isEqualTo("E001");
    }

    @Test
    void givenNullError_whenGetErrorCode_thenReturnsUnknown() {
        // When / Then
        assertThat(mapper.getErrorCode(null)).isEqualTo("UNKNOWN");
    }

    @Test
    void givenError_whenGetErrorDescription_thenReturnsDescription() {
        // Given
        StratioCustomerResponseDto.Error error = StratioCustomerResponseDto.Error.builder()
                .descError("Cliente no encontrado")
                .build();

        // When / Then
        assertThat(mapper.getErrorDescription(error)).isEqualTo("Cliente no encontrado");
    }

    @Test
    void givenNullError_whenGetErrorDescription_thenReturnsDefault() {
        // When / Then
        assertThat(mapper.getErrorDescription(null)).isEqualTo("Error en servicio Stratio");
    }
}
