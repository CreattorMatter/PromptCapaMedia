package com.pichincha.sp.infrastructure.output.adapter.strategy;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.sp.application.output.port.StratioCustomerPort;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class OcpOnlyStrategyTest {

    @Mock
    private StratioCustomerPort stratioPort;

    private OcpOnlyStrategy strategy;

    private CustomerRequest validRequest;

    @BeforeEach
    void setUp() {
        strategy = new OcpOnlyStrategy(stratioPort);
        validRequest = new CustomerRequest("0602119182", "0001");
    }

    private Customer buildCustomer() {
        return Customer.builder()
                .cif("0000000003860119")
                .identificacion("0602119182")
                .tipoIdentificacion("0001")
                .apellidos("TORANZO CIURLIZA")
                .nombres("CAISATASIG")
                .nombre("CAISATASIG TORANZO CIURLIZA")
                .direccion("MEDARDO ANGEL SILVA")
                .tipoCliente("01")
                .estado("000")
                .dataSource(null)
                .build();
    }

    @Test
    void givenStratioReturnsCustomer_whenQuery_thenReturnsCustomerWithStratioDataSource() {
        // Given
        Customer customerFromStratio = buildCustomer();
        when(stratioPort.getCustomerInfo(any(), isNull(), any()))
                .thenReturn(Mono.just(customerFromStratio));

        // When
        Mono<Customer> result = strategy.query(validRequest, null);

        // Then
        StepVerifier.create(result)
                .assertNext(customer -> {
                    assertThat(customer).isNotNull();
                    assertThat(customer.cif()).isEqualTo("0000000003860119");
                    assertThat(customer.identificacion()).isEqualTo("0602119182");
                    assertThat(customer.nombre()).isEqualTo("CAISATASIG TORANZO CIURLIZA");
                    assertThat(customer.dataSource()).isEqualTo(DataSourceTypeEnum.STRATIO);
                })
                .verifyComplete();

        verify(stratioPort, times(1)).getCustomerInfo(eq(validRequest), isNull(), isNull());
    }

    @Test
    void givenStratioReturnsCustomer_andRequestContextProvided_whenQuery_thenPropagatesContext() {
        // Given
        SoapRequestContext requestContext = SoapRequestContext.of("USINTERT", "02", "DEVICE-001");
        Customer customerFromStratio = buildCustomer();
        when(stratioPort.getCustomerInfo(any(), isNull(), any()))
                .thenReturn(Mono.just(customerFromStratio));

        // When
        Mono<Customer> result = strategy.query(validRequest, requestContext);

        // Then
        StepVerifier.create(result)
                .assertNext(customer -> {
                    assertThat(customer.cif()).isEqualTo("0000000003860119");
                    assertThat(customer.dataSource()).isEqualTo(DataSourceTypeEnum.STRATIO);
                })
                .verifyComplete();

        verify(stratioPort, times(1)).getCustomerInfo(validRequest, null, requestContext);
    }

    @Test
    void givenStratioFailsWithGlobalErrorException_whenQuery_thenPropagatesOriginalException() {
        // Given
        GlobalErrorException originalError =
                new GlobalErrorException("E001", "Cliente no encontrado", "STRATIO");
        when(stratioPort.getCustomerInfo(any(), isNull(), any()))
                .thenReturn(Mono.error(originalError));

        // When
        Mono<Customer> result = strategy.query(validRequest, null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> {
                    assertThat(throwable).isSameAs(originalError);
                    assertThat(throwable).isInstanceOf(GlobalErrorException.class);
                    GlobalErrorException ex = (GlobalErrorException) throwable;
                    assertThat(ex.getErrorCode()).isEqualTo("E001");
                    assertThat(ex.getMessage()).isEqualTo("Cliente no encontrado");
                    assertThat(ex.getComponent()).isEqualTo("STRATIO");
                    return true;
                })
                .verify();
    }

    @Test
    void givenStratioFailsWithRuntimeException_whenQuery_thenWrapsInGlobalErrorException() {
        // Given
        RuntimeException unexpectedError = new RuntimeException("Connection refused");
        when(stratioPort.getCustomerInfo(any(), isNull(), any()))
                .thenReturn(Mono.error(unexpectedError));

        // When
        Mono<Customer> result = strategy.query(validRequest, null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> {
                    assertThat(throwable).isInstanceOf(GlobalErrorException.class);
                    GlobalErrorException ex = (GlobalErrorException) throwable;
                    assertThat(ex.getErrorCode()).isEqualTo("999");
                    assertThat(ex.getMessage()).isEqualTo("Connection refused");
                    assertThat(ex.getComponent()).isEqualTo("STRATIO");
                    return true;
                })
                .verify();
    }
}
