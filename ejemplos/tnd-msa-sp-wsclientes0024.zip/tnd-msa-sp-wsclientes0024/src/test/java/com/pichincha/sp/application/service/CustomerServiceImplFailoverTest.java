package com.pichincha.sp.application.service;

import com.pichincha.sp.application.output.port.BancsCustomerPort;
import com.pichincha.sp.application.output.port.StratioCustomerPort;
import com.pichincha.sp.infrastructure.output.adapter.strategy.BancsOnlyStrategy;
import com.pichincha.sp.infrastructure.output.adapter.strategy.BancsWithOcpFailoverStrategy;
import com.pichincha.sp.infrastructure.output.adapter.strategy.OcpOnlyStrategy;
import com.pichincha.sp.infrastructure.output.adapter.strategy.OcpWithBancsFailoverStrategy;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Tests for the four CustomerQueryStrategy implementations.
 *
 * <ul>
 *   <li>{@link OcpWithBancsFailoverStrategy} — 3 scenarios (Stratio OK / FAILS / both FAIL)</li>
 *   <li>{@link OcpOnlyStrategy} — 2 scenarios (Stratio OK / FAILS without failover)</li>
 *   <li>{@link BancsWithOcpFailoverStrategy} — 3 scenarios (Bancs OK / FAILS / both FAIL)</li>
 *   <li>{@link BancsOnlyStrategy} — 2 scenarios (Bancs OK / FAILS without failover)</li>
 * </ul>
 *
 * @author Banco Pichincha
 * @version 2.0
 * @since 2026
 */
@ExtendWith(MockitoExtension.class)
class CustomerServiceImplFailoverTest {

    @Mock
    private StratioCustomerPort stratioCustomerPort;

    @Mock
    private BancsCustomerPort bancsCustomerPort;

    @Mock
    private CustomLogLevelHandler customLogLevelHandler;

    private CustomerRequest validRequest;
    private Customer customerFromStratio;
    private Customer customerFromBancs;

    @BeforeEach
    void setUp() {
        validRequest = new CustomerRequest("0602119182", "0001");

        customerFromStratio = Customer.builder()
                .cif("0000000003860119")
                .identificacion("0602119182")
                .tipoIdentificacion("0001")
                .nombre("CAISATASIG TORANZO CIURLIZA ESCALERA DE CARCHIPULLA")
                .direccion("MEDARDO ANGEL SILVA")
                .tipoCliente("01")
                .estado("000")
                .dataSource(DataSourceTypeEnum.STRATIO)
                .build();

        customerFromBancs = Customer.builder()
                .cif("3860119")
                .identificacion("0602119182")
                .tipoIdentificacion("0001")
                .nombre("CAISATASIG TORANZO DE CARCHIPULLA")
                .direccion("Amazonas 4545, Pereira,")
                .tipoCliente("01")
                .estado("000")
                .dataSource(DataSourceTypeEnum.BANCS)
                .build();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  OcpWithBancsFailoverStrategy
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    class OcpWithBancsFailoverStrategyTests {

        private OcpWithBancsFailoverStrategy strategy;

        @BeforeEach
        void setUpStrategy() {
            strategy = new OcpWithBancsFailoverStrategy(stratioCustomerPort, bancsCustomerPort, customLogLevelHandler);
        }

        @Test
        void givenStratioAvailable_whenQuery_thenReturnsCustomerWithDataSourceStratio() {
            // Given
            when(stratioCustomerPort.getCustomerInfo(any(), isNull(), any()))
                    .thenReturn(Mono.just(customerFromStratio));

            // When
            Mono<Customer> result = strategy.query(validRequest, null);

            // Then
            StepVerifier.create(result)
                    .expectNextMatches(customer -> {
                        assertNotNull(customer);
                        assertEquals("0000000003860119", customer.cif());
                        assertThat(customer.dataSource()).isEqualTo(DataSourceTypeEnum.STRATIO);
                        return true;
                    })
                    .verifyComplete();

            verify(bancsCustomerPort, never()).getCustomerInfo(any());
        }

        @Test
        void givenStratioFails_andBancsAvailable_whenQuery_thenReturnsCustomerWithDataSourceBancs() {
            // Given
            when(stratioCustomerPort.getCustomerInfo(any(), isNull(), any()))
                    .thenReturn(Mono.error(new RuntimeException("Stratio unreachable")));
            when(bancsCustomerPort.getCustomerInfo(any()))
                    .thenReturn(Mono.just(customerFromBancs));

            // When
            Mono<Customer> result = strategy.query(validRequest, null);

            // Then
            StepVerifier.create(result)
                    .expectNextMatches(customer -> {
                        assertEquals("3860119", customer.cif());
                        assertThat(customer.dataSource()).isEqualTo(DataSourceTypeEnum.BANCS);
                        return true;
                    })
                    .verifyComplete();

            verify(bancsCustomerPort, times(1)).getCustomerInfo(validRequest);
        }

        @Test
        void givenStratioFails_andBancsFails_whenQuery_thenThrowsGlobalErrorExceptionWithBancsMessage() {
            // Given
            String stratioMsg = "Stratio: Connection timeout";
            String bancsMsg = "Bancs TX060480: Host unreachable";

            when(stratioCustomerPort.getCustomerInfo(any(), isNull(), any()))
                    .thenReturn(Mono.error(new RuntimeException(stratioMsg)));
            when(bancsCustomerPort.getCustomerInfo(any()))
                    .thenReturn(Mono.error(new RuntimeException(bancsMsg)));

            // When
            Mono<Customer> result = strategy.query(validRequest, null);

            // Then
            StepVerifier.create(result)
                    .expectErrorMatches(throwable -> {
                        assertThat(throwable).isInstanceOf(GlobalErrorException.class);
                        GlobalErrorException ex = (GlobalErrorException) throwable;
                        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, ex.getStatusCode());
                        assertThat(throwable.getMessage()).isEqualTo(bancsMsg);
                        return true;
                    })
                    .verify();
        }

        @Test
        void givenStratioAvailable_whenQuery_thenBancsIsNeverInvoked() {
            // Given
            when(stratioCustomerPort.getCustomerInfo(any(), isNull(), any()))
                    .thenReturn(Mono.just(customerFromStratio));

            // When
            Mono<Customer> result = strategy.query(validRequest, null);

            // Then
            StepVerifier.create(result).expectNextCount(1).verifyComplete();
            verify(bancsCustomerPort, never()).getCustomerInfo(any());
        }

        @Test
        void givenStratioFails_whenQuery_thenBancsIsInvokedExactlyOnce() {
            // Given
            when(stratioCustomerPort.getCustomerInfo(any(), isNull(), any()))
                    .thenReturn(Mono.error(new RuntimeException("Stratio down")));
            when(bancsCustomerPort.getCustomerInfo(any()))
                    .thenReturn(Mono.just(customerFromBancs));

            // When
            Mono<Customer> result = strategy.query(validRequest, null);

            // Then
            StepVerifier.create(result).expectNextCount(1).verifyComplete();
            verify(bancsCustomerPort, times(1)).getCustomerInfo(any());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  OcpOnlyStrategy
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    class OcpOnlyStrategyTests {

        private OcpOnlyStrategy strategy;

        @BeforeEach
        void setUpStrategy() {
            strategy = new OcpOnlyStrategy(stratioCustomerPort);
        }

        @Test
        void givenStratioAvailable_whenQuery_thenReturnsCustomer() {
            // Given
            when(stratioCustomerPort.getCustomerInfo(any(), isNull(), any()))
                    .thenReturn(Mono.just(customerFromStratio));

            // When
            Mono<Customer> result = strategy.query(validRequest, null);

            // Then
            StepVerifier.create(result)
                    .expectNextMatches(c -> {
                        assertThat(c.dataSource()).isEqualTo(DataSourceTypeEnum.STRATIO);
                        assertEquals("0000000003860119", c.cif());
                        return true;
                    })
                    .verifyComplete();
        }

        @Test
        void givenStratioFails_whenQuery_thenThrowsGlobalErrorExceptionWithOriginalMessage() {
            // Given
            String errorMsg = "Stratio error";
            when(stratioCustomerPort.getCustomerInfo(any(), isNull(), any()))
                    .thenReturn(Mono.error(new RuntimeException(errorMsg)));

            // When
            Mono<Customer> result = strategy.query(validRequest, null);

            // Then
            StepVerifier.create(result)
                    .expectErrorMatches(throwable -> {
                        assertThat(throwable).isInstanceOf(GlobalErrorException.class);
                        assertThat(throwable.getMessage()).isEqualTo(errorMsg);
                        return true;
                    })
                    .verify();

            verify(bancsCustomerPort, never()).getCustomerInfo(any());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  BancsWithOcpFailoverStrategy
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    class BancsWithOcpFailoverStrategyTests {

        private BancsWithOcpFailoverStrategy strategy;

        @BeforeEach
        void setUpStrategy() {
            strategy = new BancsWithOcpFailoverStrategy(bancsCustomerPort, stratioCustomerPort, customLogLevelHandler);
        }

        @Test
        void givenBancsAvailable_whenQuery_thenReturnsCustomerWithDataSourceBancs() {
            // Given
            when(bancsCustomerPort.getCustomerInfo(any()))
                    .thenReturn(Mono.just(customerFromBancs));

            // When
            Mono<Customer> result = strategy.query(validRequest, null);

            // Then
            StepVerifier.create(result)
                    .expectNextMatches(customer -> {
                        assertEquals("3860119", customer.cif());
                        assertThat(customer.dataSource()).isEqualTo(DataSourceTypeEnum.BANCS);
                        return true;
                    })
                    .verifyComplete();

            verify(stratioCustomerPort, never()).getCustomerInfo(any(), any(), any());
        }

        @Test
        void givenBancsFails_andStratioAvailable_whenQuery_thenReturnsCustomerWithDataSourceStratio() {
            // Given
            when(bancsCustomerPort.getCustomerInfo(any()))
                    .thenReturn(Mono.error(new RuntimeException("Bancs unreachable")));
            when(stratioCustomerPort.getCustomerInfo(any(), isNull(), any()))
                    .thenReturn(Mono.just(customerFromStratio));

            // When
            Mono<Customer> result = strategy.query(validRequest, null);

            // Then
            StepVerifier.create(result)
                    .expectNextMatches(customer -> {
                        assertEquals("0000000003860119", customer.cif());
                        assertThat(customer.dataSource()).isEqualTo(DataSourceTypeEnum.STRATIO);
                        return true;
                    })
                    .verifyComplete();
        }

        @Test
        void givenBancsFails_andStratioFails_whenQuery_thenThrowsGlobalErrorExceptionWithStratioMessage() {
            // Given
            String bancsMsg = "Bancs: Connection pool exhausted";
            String stratioMsg = "Stratio: Read timeout";

            when(bancsCustomerPort.getCustomerInfo(any()))
                    .thenReturn(Mono.error(new RuntimeException(bancsMsg)));
            when(stratioCustomerPort.getCustomerInfo(any(), isNull(), any()))
                    .thenReturn(Mono.error(new RuntimeException(stratioMsg)));

            // When
            Mono<Customer> result = strategy.query(validRequest, null);

            // Then
            StepVerifier.create(result)
                    .expectErrorMatches(throwable -> {
                        assertTrue(throwable instanceof GlobalErrorException);
                        assertThat(throwable.getMessage()).isEqualTo(stratioMsg);
                        return true;
                    })
                    .verify();
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  BancsOnlyStrategy
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    class BancsOnlyStrategyTests {

        private BancsOnlyStrategy strategy;

        @BeforeEach
        void setUpStrategy() {
            strategy = new BancsOnlyStrategy(bancsCustomerPort);
        }

        @Test
        void givenBancsAvailable_whenQuery_thenReturnsCustomer() {
            // Given
            when(bancsCustomerPort.getCustomerInfo(any()))
                    .thenReturn(Mono.just(customerFromBancs));

            // When
            Mono<Customer> result = strategy.query(validRequest, null);

            // Then
            StepVerifier.create(result)
                    .expectNextMatches(c -> {
                        assertThat(c.dataSource()).isEqualTo(DataSourceTypeEnum.BANCS);
                        assertEquals("3860119", c.cif());
                        return true;
                    })
                    .verifyComplete();
        }

        @Test
        void givenBancsFails_whenQuery_thenThrowsGlobalErrorExceptionWithOriginalMessage() {
            // Given
            String errorMsg = "Bancs error";
            when(bancsCustomerPort.getCustomerInfo(any()))
                    .thenReturn(Mono.error(new RuntimeException(errorMsg)));

            // When
            Mono<Customer> result = strategy.query(validRequest, null);

            // Then
            StepVerifier.create(result)
                    .expectErrorMatches(throwable -> {
                        assertThat(throwable).isInstanceOf(GlobalErrorException.class);
                        assertThat(throwable.getMessage()).isEqualTo(errorMsg);
                        return true;
                    })
                    .verify();

            verify(stratioCustomerPort, never()).getCustomerInfo(any(), any(), any());
        }
    }
}
