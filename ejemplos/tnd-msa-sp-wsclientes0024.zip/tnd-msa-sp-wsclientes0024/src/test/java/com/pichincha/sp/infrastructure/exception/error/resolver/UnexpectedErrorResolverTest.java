package com.pichincha.sp.infrastructure.exception.error.resolver;

import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultEnvelopeDto;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.server.ServerWebExchange;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for UnexpectedErrorResolver.
 *
 * @author Banco Pichincha
 * @version 1.0.0
 * @since 2026-03-20
 */
@ExtendWith(MockitoExtension.class)
class UnexpectedErrorResolverTest {

    @Mock
    private CustomLogLevelHandler customLogLevelHandler;

    private UnexpectedErrorResolver resolver;

    @BeforeEach
    void setUp() {
        resolver = new UnexpectedErrorResolver(customLogLevelHandler);
    }

    @Test
    void givenUnexpectedRuntimeException_whenBuildError_thenBuildsEnvelopeWithUnexpectedError() {
        // Given
        ServerHttpResponse response = mock(ServerHttpResponse.class);
        Throwable throwable = new RuntimeException("Unexpected test error");

        // When
        SoapFaultEnvelopeDto result = resolver.buildError(response, "/services/test", throwable);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getFault()).isNotNull();
        assertThat(result.getBody().getFault().getFaultCode()).isEqualTo("soapenv:Client");
        assertThat(result.getBody().getFault().getFaultString()).isEqualTo("Unexpected error");
        assertThat(result.getBody().getFault().getDetail()).contains("An unexpected error has occurred");
    }

    @Test
    void givenNullPointerException_whenBuildError_thenSetsHttp500InResponse() {
        // Given
        ServerHttpResponse response = mock(ServerHttpResponse.class);
        Throwable throwable = new NullPointerException("Test NPE");

        // When
        resolver.buildError(response, "/services/test", throwable);

        // Then
        verify(response).setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Test
    void givenIllegalStateExceptionAndExchange_whenApply_thenReturnsValidEnvelopeWithUnexpectedError() {
        // Given
        ServerWebExchange exchange = mock(ServerWebExchange.class);
        ServerHttpResponse response = mock(ServerHttpResponse.class);
        org.springframework.http.server.reactive.ServerHttpRequest request =
                mock(org.springframework.http.server.reactive.ServerHttpRequest.class);
        org.springframework.http.server.RequestPath requestPath =
                mock(org.springframework.http.server.RequestPath.class);

        when(exchange.getResponse()).thenReturn(response);
        when(exchange.getRequest()).thenReturn(request);
        when(request.getPath()).thenReturn(requestPath);
        when(requestPath.toString()).thenReturn("/services/test");

        Throwable throwable = new IllegalStateException("Illegal state");

        // When
        SoapFaultEnvelopeDto result = resolver.apply(exchange, throwable);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getFault()).isNotNull();
        assertThat(result.getBody().getFault().getFaultString()).isEqualTo("Unexpected error");
    }
}
