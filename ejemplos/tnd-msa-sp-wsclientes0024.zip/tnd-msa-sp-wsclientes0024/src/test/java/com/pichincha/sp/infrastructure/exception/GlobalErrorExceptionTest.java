package com.pichincha.sp.infrastructure.exception;

import com.pichincha.sp.domain.exception.GlobalErrorException;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for GlobalErrorException (domain).
 *
 * @author Banco Pichincha
 * @version 2.0
 * @since 2026
 */
class GlobalErrorExceptionTest {

    @Test
    void givenMessageComponentAndStatus_whenConstructor_thenCreatesExceptionWithCorrectData() {
        // Given
        String message = "Test error";
        String component = "TestComponent";
        HttpStatus status = HttpStatus.BAD_REQUEST;

        // When
        GlobalErrorException ex = new GlobalErrorException(message, component, status);

        // Then
        assertThat(ex.getMessage()).isEqualTo(message);
        assertThat(ex.getComponent()).isEqualTo(component);
        assertThat(ex.getStatusCode()).isEqualTo(status);
    }

    @Test
    void givenOnlyMessage_whenSimplifiedConstructor_thenStatusIs500AndComponentIsUnknown() {
        // Given
        String message = "Simple error";

        // When
        GlobalErrorException ex = new GlobalErrorException(message);

        // Then
        assertThat(ex.getMessage()).isEqualTo(message);
        assertThat(ex.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(ex.getComponent()).isEqualTo("UNKNOWN");
    }

    @Test
    void givenMessageAndCause_whenConstructor_thenCreatesExceptionWithCauseAndStatus500() {
        // Given
        String message = "Error with cause";
        Throwable cause = new RuntimeException("Original cause");

        // When
        GlobalErrorException ex = new GlobalErrorException(message, cause);

        // Then
        assertThat(ex.getMessage()).isEqualTo(message);
        assertThat(ex.getCause()).isEqualTo(cause);
        assertThat(ex.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(ex.getComponent()).isEqualTo("UNKNOWN");
    }

    @Test
    void givenMessageAndComponent_whenConstructor_thenStatusIs500() {
        // Given
        String message = "Error with component";
        String component = "MiComponente";

        // When
        GlobalErrorException ex = new GlobalErrorException(message, component);

        // Then
        assertThat(ex.getMessage()).isEqualTo(message);
        assertThat(ex.getComponent()).isEqualTo(component);
        assertThat(ex.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Test
    void givenCreatedInstance_whenInstanceof_thenIsRuntimeException() {
        // When
        GlobalErrorException ex = new GlobalErrorException("test");

        // Then
        assertThat(ex).isInstanceOf(RuntimeException.class);
    }
}
