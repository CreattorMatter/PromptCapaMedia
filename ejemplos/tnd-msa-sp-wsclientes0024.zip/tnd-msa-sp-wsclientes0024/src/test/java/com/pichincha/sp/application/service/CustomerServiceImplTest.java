package com.pichincha.sp.application.service;

import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import com.pichincha.sp.application.output.port.CustomerQueryStrategyPort;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.domain.exception.BusinessValidationException;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


/**
 * Unit tests for CustomerServiceImpl.
 *
 * Verifies the exclusive responsibilities of the service:
 * - Business validation inherited from IIB (error code "1")
 * - Identification normalization
 * - Correct delegation to CustomerQueryStrategyPort
 *
 * @author Banco Pichincha
 * @version 2.0
 * @since 2026
 */
@ExtendWith(MockitoExtension.class)
class CustomerServiceImplTest {

    @Mock
    private CustomerQueryStrategyPort customerQueryStrategy;

    @Mock
    private CustomLogLevelHandler customLogLevelHandler;

    @InjectMocks
    private CustomerServiceImpl customerService;

    private CustomerRequest validRequest;
    private Customer mockCustomer;

    @BeforeEach
    void setUp() {
        validRequest = new CustomerRequest("0500563358", "0001");

        mockCustomer = Customer.builder()
                .cif("115678")
                .identificacion("0500563358")
                .tipoIdentificacion("0001")
                .apellidos("PEREZ")
                .nombres("JUAN")
                .nombre("JUAN PEREZ")
                .direccion("QUITO, AV. AMAZONAS")
                .tipoCliente("01")
                .estado("000")
                .dataSource(DataSourceTypeEnum.STRATIO)
                .build();
    }

    // ─────────────────────────────────────────────────────────────────
    //  Business validations
    // ─────────────────────────────────────────────────────────────────

    @Test
    void givenNullIdentification_whenGetCustomerByIdentification_thenThrowsBusinessValidationExceptionCodeOne() {
        // Given
        CustomerRequest requestWithNullId = new CustomerRequest(null, "0001");

        // When
        Mono<?> result = customerService.getCustomerByIdentification(requestWithNullId, null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> {
                    assertThat(throwable).isInstanceOf(BusinessValidationException.class);
                    BusinessValidationException ex = (BusinessValidationException) throwable;
                    assertThat(ex.getErrorCode()).isEqualTo("1");
                    assertThat(ex.getErrorMessage()).isEqualTo("Valor del campo identificacion vacio o invalido");
                    return true;
                })
                .verify();

        verify(customerQueryStrategy, never()).query(any(), any());
    }

    @Test
    void givenEmptyIdentification_whenGetCustomerByIdentification_thenThrowsBusinessValidationExceptionCodeOne() {
        // Given
        CustomerRequest requestWithEmptyId = new CustomerRequest("", "0001");

        // When
        Mono<?> result = customerService.getCustomerByIdentification(requestWithEmptyId, null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> {
                    assertThat(throwable).isInstanceOf(BusinessValidationException.class);
                    BusinessValidationException ex = (BusinessValidationException) throwable;
                    assertThat(ex.getErrorCode()).isEqualTo("1");
                    assertThat(ex.getErrorMessage()).isEqualTo("Valor del campo identificacion vacio o invalido");
                    return true;
                })
                .verify();

        verify(customerQueryStrategy, never()).query(any(), any());
    }

    @Test
    void givenIdentificationOnlySpaces_whenGetCustomerByIdentification_thenThrowsBusinessValidationExceptionCodeOne() {
        // Given
        CustomerRequest requestWithSpaces = new CustomerRequest("   ", "0001");

        // When
        Mono<?> result = customerService.getCustomerByIdentification(requestWithSpaces, null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> {
                    assertThat(throwable).isInstanceOf(BusinessValidationException.class);
                    BusinessValidationException ex = (BusinessValidationException) throwable;
                    assertThat(ex.getErrorCode()).isEqualTo("1");
                    return true;
                })
                .verify();

        verify(customerQueryStrategy, never()).query(any(), any());
    }

    @Test
    void givenNullRequest_whenGetCustomerByIdentification_thenThrowsIllegalArgumentException() {
        // When
        Mono<?> result = customerService.getCustomerByIdentification(null, null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> {
                    assertThat(throwable).isInstanceOf(IllegalArgumentException.class);
                    assertThat(throwable.getMessage()).isEqualTo("El request no puede ser nulo");
                    return true;
                })
                .verify();

        verify(customerQueryStrategy, never()).query(any(), any());
    }

    // ─────────────────────────────────────────────────────────────────
    //  Delegation to strategy
    // ─────────────────────────────────────────────────────────────────

    @Test
    void givenValidRequest_whenGetCustomerByIdentification_thenDelegatesAndReturnsCustomer() {
        // Given
        when(customerQueryStrategy.query(any(), any())).thenReturn(Mono.just(mockCustomer));

        // When
        Mono<Customer> result = customerService.getCustomerByIdentification(validRequest, null);

        // Then
        StepVerifier.create(result)
                .expectNextMatches(customer -> {
                    assertNotNull(customer);
                    assertEquals("115678", customer.cif());
                    assertEquals("0500563358", customer.identificacion());
                    assertEquals("JUAN PEREZ", customer.nombre());
                    assertThat(customer.dataSource()).isEqualTo(DataSourceTypeEnum.STRATIO);
                    return true;
                })
                .verifyComplete();

        verify(customerQueryStrategy).query(any(), any());
    }

    @Test
    void givenValidRequest_whenGetCustomerByIdentification_thenStrategyIsCalledExactlyOnce() {
        // Given
        when(customerQueryStrategy.query(any(), any())).thenReturn(Mono.just(mockCustomer));

        // When
        Mono<Customer> result = customerService.getCustomerByIdentification(validRequest, null);

        // Then
        StepVerifier.create(result)
                .expectNextCount(1)
                .verifyComplete();

        verify(customerQueryStrategy).query(any(), any());
    }

    @Test
    void givenStrategyFails_whenGetCustomerByIdentification_thenPropagatesGlobalErrorException() {
        // Given
        when(customerQueryStrategy.query(any(), any()))
                .thenReturn(Mono.error(new GlobalErrorException("Service unavailable")));

        // When
        Mono<Customer> result = customerService.getCustomerByIdentification(validRequest, null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> {
                    assertThat(throwable).isInstanceOf(GlobalErrorException.class);
                    assertThat(throwable.getMessage()).contains("Service unavailable");
                    return true;
                })
                .verify();
    }

    // ─────────────────────────────────────────────────────────────────
    //  Identification normalization
    // ─────────────────────────────────────────────────────────────────

    @Test
    void givenIdentificationWithLeadingZeros_whenGetCustomerByIdentification_thenNormalizesToLast10Digits() {
        // Given
        CustomerRequest requestWithLeadingZeros = new CustomerRequest("00000602119182", "0001");
        ArgumentCaptor<CustomerRequest> requestCaptor = ArgumentCaptor.forClass(CustomerRequest.class);
        when(customerQueryStrategy.query(any(), any())).thenReturn(Mono.just(mockCustomer));

        // When
        Mono<Customer> result = customerService.getCustomerByIdentification(requestWithLeadingZeros, null);

        // Then
        StepVerifier.create(result)
                .expectNextCount(1)
                .verifyComplete();

        verify(customerQueryStrategy).query(requestCaptor.capture(), any());
        assertThat(requestCaptor.getValue().identificacion()).isEqualTo("0602119182");
    }

    @Test
    void givenNormal10DigitIdentification_whenGetCustomerByIdentification_thenIsNotModified() {
        // Given
        ArgumentCaptor<CustomerRequest> requestCaptor = ArgumentCaptor.forClass(CustomerRequest.class);
        when(customerQueryStrategy.query(any(), any())).thenReturn(Mono.just(mockCustomer));

        // When
        Mono<Customer> result = customerService.getCustomerByIdentification(validRequest, null);

        // Then
        StepVerifier.create(result)
                .expectNextCount(1)
                .verifyComplete();

        verify(customerQueryStrategy).query(requestCaptor.capture(), any());
        CustomerRequest capturedRequest = requestCaptor.getValue();
        assertThat(capturedRequest.identificacion())
                .as("The 10-digit identification should not be modified by normalization")
                .isEqualTo(validRequest.identificacion());
        assertThat(capturedRequest.tipoIdentificacion())
                .as("The tipoIdentificacion should remain intact after normalization")
                .isEqualTo(validRequest.tipoIdentificacion());
        assertThat(capturedRequest)
                .as("A new CustomerRequest object should not be created when there is no normalization")
                .isSameAs(validRequest);
    }
}
