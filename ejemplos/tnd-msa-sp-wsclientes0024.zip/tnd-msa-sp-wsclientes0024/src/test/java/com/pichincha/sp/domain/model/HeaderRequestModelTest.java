package com.pichincha.sp.domain.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class HeaderRequestModelTest {

    @Test
    void givenAllFields_whenBuild_thenCreatesModelWithAllAccessors() {
        // Given
        HeaderRequestModel model = HeaderRequestModel.builder()
                .dispositivo("DEVICE-001")
                .empresa("PICHINCHA")
                .canal("02")
                .medio("WEB")
                .aplicacion("WSCLIENTES")
                .agencia("MATRIZ")
                .tipoTransaccion("TX060480")
                .geolocalizacion("0.0,0.0")
                .usuario("USINTERT")
                .unicidad("U-123")
                .guid("GUID-001")
                .fechaHora("2026-04-13T10:00:00")
                .filler("FILLER")
                .idioma("ES")
                .sesion("SESSION-001")
                .ip("127.0.0.1")
                .idCliente("0602119182")
                .tipoIdCliente("0001")
                .build();

        // When / Then
        assertThat(model.dispositivo()).isEqualTo("DEVICE-001");
        assertThat(model.empresa()).isEqualTo("PICHINCHA");
        assertThat(model.canal()).isEqualTo("02");
        assertThat(model.medio()).isEqualTo("WEB");
        assertThat(model.aplicacion()).isEqualTo("WSCLIENTES");
        assertThat(model.agencia()).isEqualTo("MATRIZ");
        assertThat(model.tipoTransaccion()).isEqualTo("TX060480");
        assertThat(model.geolocalizacion()).isEqualTo("0.0,0.0");
        assertThat(model.usuario()).isEqualTo("USINTERT");
        assertThat(model.unicidad()).isEqualTo("U-123");
        assertThat(model.guid()).isEqualTo("GUID-001");
        assertThat(model.fechaHora()).isEqualTo("2026-04-13T10:00:00");
        assertThat(model.filler()).isEqualTo("FILLER");
        assertThat(model.idioma()).isEqualTo("ES");
        assertThat(model.sesion()).isEqualTo("SESSION-001");
        assertThat(model.ip()).isEqualTo("127.0.0.1");
        assertThat(model.idCliente()).isEqualTo("0602119182");
        assertThat(model.tipoIdCliente()).isEqualTo("0001");
    }

    @Test
    void givenNullFields_whenBuild_thenCreatesModelWithNullValues() {
        // Given
        HeaderRequestModel model = HeaderRequestModel.builder().build();

        // When / Then
        assertThat(model.dispositivo()).isNull();
        assertThat(model.empresa()).isNull();
        assertThat(model.canal()).isNull();
        assertThat(model.medio()).isNull();
        assertThat(model.aplicacion()).isNull();
        assertThat(model.agencia()).isNull();
        assertThat(model.tipoTransaccion()).isNull();
        assertThat(model.geolocalizacion()).isNull();
        assertThat(model.usuario()).isNull();
        assertThat(model.unicidad()).isNull();
        assertThat(model.guid()).isNull();
        assertThat(model.fechaHora()).isNull();
        assertThat(model.filler()).isNull();
        assertThat(model.idioma()).isNull();
        assertThat(model.sesion()).isNull();
        assertThat(model.ip()).isNull();
        assertThat(model.idCliente()).isNull();
        assertThat(model.tipoIdCliente()).isNull();
    }

    @Test
    void givenSameFields_whenEquals_thenReturnsTrue() {
        // Given
        HeaderRequestModel first = HeaderRequestModel.builder()
                .usuario("USINTERT")
                .canal("02")
                .build();
        HeaderRequestModel second = HeaderRequestModel.builder()
                .usuario("USINTERT")
                .canal("02")
                .build();

        // When / Then
        assertThat(first).isEqualTo(second);
        assertThat(first).hasSameHashCodeAs(second);
        assertThat(first).hasToString(second.toString());
    }

    @Test
    void givenDifferentFields_whenEquals_thenReturnsFalse() {
        // Given
        HeaderRequestModel first = HeaderRequestModel.builder().usuario("USER-A").build();
        HeaderRequestModel second = HeaderRequestModel.builder().usuario("USER-B").build();

        // When / Then
        assertThat(first).isNotEqualTo(second);
    }
}
