package com.pichincha.sp.infrastructure.input.adapter.rest.impl;

import com.pichincha.sp.application.input.port.CustomerServicePort;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.domain.exception.BusinessValidationException;
import com.pichincha.sp.infrastructure.exception.CatalogExceptionConstants;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapBodyRequestDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapEnvelopeRequestDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapEnvelopeResponseDto;
import com.pichincha.sp.generated.ConsultarIdentificacion01;
import com.pichincha.sp.generated.ConsultarIdentificacion01Response;
import com.pichincha.sp.generated.DatosClienteEntrada;
import com.pichincha.sp.generated.DatosClienteSalida;
import com.pichincha.sp.generated.GenericError;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.infrastructure.soap.mapper.SoapCustomerMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for WSClientes0024Controller.
 *
 * <p>Verifies the behavior of the REST input adapter in all scenarios:</p>
 * <ul>
 *   <li>Successful response from Stratio -> message "OK-OCP"</li>
 *   <li>Successful response from Bancs -> message "OK"</li>
 *   <li>{@link BusinessValidationException} -> HTTP 200 with error code in GenericError</li>
 *   <li>Service errors -> propagated to {@code ErrorResolverHandler}</li>
 *   <li>Correct construction of headerOut, bodyOut and GenericError</li>
 * </ul>
 *
 * @author Banco Pichincha
 * @version 1.0
 * @since 2026
 */
@ExtendWith(MockitoExtension.class)
class WSClientes0024ControllerTest {

    @Mock
    private CustomerServicePort customerService;

    @Mock
    private SoapCustomerMapper soapMapper;

    @InjectMocks
    private WSClientes0024Controller controller;

    // ── Fixtures ──────────────────────────────────────────────────────────────

    private SoapEnvelopeRequestDto soapEnvelope;
    private ConsultarIdentificacion01 soapRequest;
    private GenericHeaderIn headerIn;
    private CustomerRequest domainRequest;
    private Customer customerStratio;
    private Customer customerBancs;
    private DatosClienteSalida customerOutputData;

    @BeforeEach
    void setUp() {
        // HeaderIn with real test data (test case Bancs/Stratio 24-mar-2026)
        headerIn = new GenericHeaderIn();
        headerIn.setDispositivo("5CiD3iOF8whuBQEqbct1tlD2mAuclrM=");
        headerIn.setEmpresa("0010");
        headerIn.setCanal("02");
        headerIn.setMedio("020002");
        headerIn.setAplicacion("00270");
        headerIn.setAgencia("00012");
        headerIn.setTipoTransaccion("304100111");
        headerIn.setGeolocalizacion("6588542");
        headerIn.setUsuario("USINTERT");
        headerIn.setUnicidad("UZhDOa2GXtkAK2/QovFagnnS+nQSGAF/SKyTIIv1axc=");
        headerIn.setGuid("550e8400e29b41d4a716446655440000");
        headerIn.setFechaHora("201608161239203000");
        headerIn.setFiller("00000000000000000000000000000000000000000000000000");
        headerIn.setIdioma("es");
        headerIn.setSesion("ASDASD77R01YH");
        headerIn.setIp("192.168.123.111");
        headerIn.setIdCliente("1711089364");
        headerIn.setTipoIdCliente("0001");

        // BodyIn
        DatosClienteEntrada bodyIn = new DatosClienteEntrada();
        bodyIn.setIdentificacion("0602119182");
        bodyIn.setTipoIdentificacion("0001");

        // ConsultarIdentificacion01 (root SOAP object)
        soapRequest = new ConsultarIdentificacion01();
        soapRequest.setHeaderIn(headerIn);
        soapRequest.setBodyIn(bodyIn);

        // Complete SoapEnvelope
        SoapBodyRequestDto bodyDto = new SoapBodyRequestDto();
        bodyDto.setConsultarIdentificacion01(soapRequest);
        soapEnvelope = new SoapEnvelopeRequestDto();
        soapEnvelope.setBody(bodyDto);

        // Domain CustomerRequest
        domainRequest = new CustomerRequest("0602119182", "0001");

        // Customer from Stratio
        customerStratio = Customer.builder()
                .cif("0000000003860119")
                .identificacion("0602119182")
                .tipoIdentificacion("0001")
                .nombre("CAISATASIG TORANZO DE CARCHIPULLA")
                .direccion("MEDARDO ANGEL SILVA")
                .tipoCliente("01")
                .estado("000")
                .dataSource(DataSourceTypeEnum.STRATIO)
                .build();

        // Customer from Bancs
        customerBancs = Customer.builder()
                .cif("3860119")
                .identificacion("0602119182")
                .tipoIdentificacion("0001")
                .nombre("CAISATASIG TORANZO DE CARCHIPULLA")
                .direccion("Amazonas 4545, Pereira,")
                .tipoCliente("01")
                .estado("000")
                .dataSource(DataSourceTypeEnum.BANCS)
                .build();

        // DatosClienteSalida for soapMapper.toSoap() mock
        customerOutputData = new DatosClienteSalida();
        customerOutputData.setCIF("0000000003860119");
        customerOutputData.setIdentificacion("0602119182");
        customerOutputData.setTipoIdentificacion("0001");
        customerOutputData.setNombre("CAISATASIG TORANZO DE CARCHIPULLA");
        customerOutputData.setDireccion("MEDARDO ANGEL SILVA");
        customerOutputData.setTipoCliente("01");
        customerOutputData.setEstado("000");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Happy Path scenarios
    // ─────────────────────────────────────────────────────────────────────────

    @Nested
    class SuccessfulResponseTests {

        @Test
        void givenCustomerFromStratio_whenConsultarIdentificacion01_thenMessageOkOcp() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.just(customerStratio));
            when(soapMapper.toSoap(customerStratio)).thenReturn(customerOutputData);

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> {
                        ConsultarIdentificacion01Response response = getResponse(envelope);
                        GenericError error = response.getError();
                        assertThat(error.getCodigo()).isEqualTo(CatalogExceptionConstants.SUCCESS_CODE);
                        assertThat(error.getMensaje()).isEqualTo(CatalogExceptionConstants.SUCCESS_MESSAGE_OCP);
                    })
                    .verifyComplete();
        }

        @Test
        void givenCustomerFromBancs_whenConsultarIdentificacion01_thenMessageOk() {
            // Given
            DatosClienteSalida bancsData = new DatosClienteSalida();
            bancsData.setCIF("3860119");
            bancsData.setIdentificacion("0602119182");

            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.just(customerBancs));
            when(soapMapper.toSoap(customerBancs)).thenReturn(bancsData);

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> {
                        ConsultarIdentificacion01Response response = getResponse(envelope);
                        GenericError error = response.getError();
                        assertThat(error.getCodigo()).isEqualTo(CatalogExceptionConstants.SUCCESS_CODE);
                        assertThat(error.getMensaje()).isEqualTo(CatalogExceptionConstants.SUCCESS_MESSAGE_BANCS);
                    })
                    .verifyComplete();
        }

        @Test
        void givenSuccessfulResponse_whenConsultarIdentificacion01_thenBodyOutIsCorrect() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.just(customerStratio));
            when(soapMapper.toSoap(customerStratio)).thenReturn(customerOutputData);

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> {
                        ConsultarIdentificacion01Response response = getResponse(envelope);
                        assertThat(response.getBodyOut()).isNotNull();
                        assertThat(response.getBodyOut().getCIF()).isEqualTo("0000000003860119");
                        assertThat(response.getBodyOut().getIdentificacion()).isEqualTo("0602119182");
                    })
                    .verifyComplete();
        }

        @Test
        void givenSuccessfulResponse_whenConsultarIdentificacion01_thenGenericErrorIsComplete() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.just(customerStratio));
            when(soapMapper.toSoap(any())).thenReturn(customerOutputData);

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> {
                        GenericError error = getResponse(envelope).getError();
                        assertThat(error.getCodigo()).isEqualTo("0");
                        assertThat(error.getMensajeNegocio()).isEqualTo(CatalogExceptionConstants.SUCCESS_MENSAJE_NEGOCIO);
                        assertThat(error.getTipo()).isEqualTo(CatalogExceptionConstants.ERROR_TYPE_INFO);
                        assertThat(error.getRecurso()).isEqualTo(CatalogExceptionConstants.WS_RECURSO);
                        assertThat(error.getComponente()).isEqualTo(CatalogExceptionConstants.WS_COMPONENTE);
                        assertThat(error.getBackend()).isEqualTo(CatalogExceptionConstants.BACKEND_CODE);
                    })
                    .verifyComplete();
        }

        @Test
        void givenSuccessfulResponse_whenConsultarIdentificacion01_thenHeaderOutReflectsHeaderIn() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.just(customerStratio));
            when(soapMapper.toSoap(any())).thenReturn(customerOutputData);

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> {
                        var hOut = getResponse(envelope).getHeaderOut();
                        assertThat(hOut).isNotNull();
                        assertThat(hOut.getDispositivo()).isEqualTo(headerIn.getDispositivo());
                        assertThat(hOut.getEmpresa()).isEqualTo(headerIn.getEmpresa());
                        assertThat(hOut.getCanal()).isEqualTo(headerIn.getCanal());
                        assertThat(hOut.getMedio()).isEqualTo(headerIn.getMedio());
                        assertThat(hOut.getGuid()).isEqualTo(headerIn.getGuid());
                        assertThat(hOut.getUsuario()).isEqualTo(headerIn.getUsuario());
                        assertThat(hOut.getSesion()).isEqualTo(headerIn.getSesion());
                        assertThat(hOut.getIp()).isEqualTo(headerIn.getIp());
                    })
                    .verifyComplete();
        }

        @Test
        void givenSuccessfulResponse_whenConsultarIdentificacion01_thenDocumentoWithoutHardcode() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.just(customerStratio));
            when(soapMapper.toSoap(any())).thenReturn(customerOutputData);

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> {
                        var documento = getResponse(envelope).getHeaderOut().getDocumento();
                        assertThat(documento).isNotNull();
                        assertThat(documento.getFechaContable()).isNull();
                        assertThat(documento.getNumeroDocumento()).isNull();
                    })
                    .verifyComplete();
        }

        @Test
        void givenSuccessfulResponse_whenConsultarIdentificacion01_thenEnvelopeWithBody() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.just(customerStratio));
            when(soapMapper.toSoap(any())).thenReturn(customerOutputData);

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> {
                        assertThat(envelope).isNotNull();
                        assertThat(envelope.getBody()).isNotNull();
                        assertThat(envelope.getBody().getConsultarIdentificacion01Response()).isNotNull();
                    })
                    .verifyComplete();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Business errors (BusinessValidationException -> HTTP 200)
    // ─────────────────────────────────────────────────────────────────────────

    @Nested
    class BusinessValidationExceptionTests {

        @Test
        void givenBusinessValidationExceptionCodeOne_whenConsultarIdentificacion01_thenGenericErrorCodeOne() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.error(
                            new BusinessValidationException("1",
                                    "Valor del campo identificacion vacio o invalido",
                                    "ERROR")));

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> {
                        GenericError error = getResponse(envelope).getError();
                        assertThat(error.getCodigo()).isEqualTo("1");
                        assertThat(error.getMensaje())
                                .isEqualTo("Valor del campo identificacion vacio o invalido");
                    })
                    .verifyComplete();
        }

        @Test
        void givenBusinessValidationException_whenConsultarIdentificacion01_thenBodyOutIsNull() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.error(new BusinessValidationException("1", "Invalid ID")));

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> {
                        ConsultarIdentificacion01Response response = getResponse(envelope);
                        assertThat(response.getBodyOut()).isNull();
                    })
                    .verifyComplete();
        }

        @Test
        void givenBusinessValidationException_whenConsultarIdentificacion01_thenHeaderOutIsPresent() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.error(new BusinessValidationException("1", "Invalid ID")));

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> {
                        assertThat(getResponse(envelope).getHeaderOut()).isNotNull();
                        assertThat(getResponse(envelope).getHeaderOut().getGuid())
                                .isEqualTo(headerIn.getGuid());
                    })
                    .verifyComplete();
        }

        @Test
        void givenBusinessValidationException_whenConsultarIdentificacion01_thenMensajeNegocioEqualsMessage() {
            // Given
            String errorMessage = "Valor del campo identificacion vacio o invalido";
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.error(new BusinessValidationException("1", errorMessage)));

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> {
                        GenericError error = getResponse(envelope).getError();
                        assertThat(error.getMensaje()).isEqualTo(errorMessage);
                        assertThat(error.getMensajeNegocio()).isEqualTo(errorMessage);
                    })
                    .verifyComplete();
        }

        @Test
        void givenBusinessValidationException_whenConsultarIdentificacion01_thenToSoapNeverInvoked() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.error(new BusinessValidationException("1", "Invalid ID")));

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> assertThat(envelope).isNotNull())
                    .verifyComplete();

            verify(soapMapper, never()).toSoap(any());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Service errors (propagated to ErrorResolverHandler)
    // ─────────────────────────────────────────────────────────────────────────

    @Nested
    class ServiceErrorTests {

        @Test
        void givenGlobalErrorException_whenConsultarIdentificacion01_thenReturnsHttp200WithError() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.error(
                            new GlobalErrorException("503", "Service unavailable: both sources failed", "STRATIO")));

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(response -> {
                        ConsultarIdentificacion01Response soapResponse = response.getBody().getConsultarIdentificacion01Response();
                        GenericError error = soapResponse.getError();

                        assertThat(error).isNotNull();
                        assertThat(error.getCodigo()).isEqualTo("503");
                        assertThat(error.getMensaje()).contains("Service unavailable");
                        assertThat(error.getTipo()).isEqualTo(CatalogExceptionConstants.ERROR_TYPE_ERROR);
                        assertThat(soapResponse.getBodyOut()).isNull();
                    })
                    .verifyComplete();
        }

        @Test
        void givenRuntimeException_whenConsultarIdentificacion01_thenErrorPropagated() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.error(new RuntimeException("Unexpected system error")));

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .expectErrorMatches(ex -> ex instanceof RuntimeException
                            && ex.getMessage().equals("Unexpected system error"))
                    .verify();
        }

        @Test
        void givenServiceError_whenConsultarIdentificacion01_thenToSoapNeverInvoked() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.error(new RuntimeException("Error")));

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .expectError(RuntimeException.class)
                    .verify();

            verify(soapMapper, never()).toSoap(any());
        }

        @Test
        void givenGlobalErrorExceptionWithNullErrorCode_whenConsultarIdentificacion01_thenUsesGenericErrorCode() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.error(new GlobalErrorException("Service down")));

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> {
                        GenericError error = getResponse(envelope).getError();
                        assertThat(error.getCodigo()).isEqualTo(CatalogExceptionConstants.ERROR_CODE_GENERIC);
                        assertThat(error.getMensaje()).isEqualTo("Service down");
                        assertThat(error.getTipo()).isEqualTo(CatalogExceptionConstants.ERROR_TYPE_ERROR);
                    })
                    .verifyComplete();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // HeaderRequestValidator integration (validation failures throw BusinessValidationException("1", ...))
    // ─────────────────────────────────────────────────────────────────────────

    @Nested
    class HeaderValidationTests {

        @Test
        void givenHeaderWithInvalidCanal_whenConsultarIdentificacion01_thenThrowsBusinessValidationExceptionWithCodeOne() {
            // Given
            headerIn.setCanal("AB");

            // When / Then
            assertThatThrownBy(() -> controller.consultarIdentificacion01(soapEnvelope))
                    .isInstanceOf(BusinessValidationException.class)
                    .hasFieldOrPropertyWithValue("errorCode", "1")
                    .hasMessageContaining("canal");

            verify(customerService, never()).getCustomerByIdentification(any(), any());
            verify(soapMapper, never()).toDomain(any());
        }

        @Test
        void givenHeaderWithFieldExceedingMaxLength_whenConsultarIdentificacion01_thenThrowsBusinessValidationException() {
            // Given
            headerIn.setUsuario("USUARIO_MUY_LARGO_QUE_EXCEDE");

            // When / Then
            assertThatThrownBy(() -> controller.consultarIdentificacion01(soapEnvelope))
                    .isInstanceOf(BusinessValidationException.class)
                    .hasFieldOrPropertyWithValue("errorCode", "1")
                    .hasMessageContaining("usuario")
                    .hasMessageContaining("excede");

            verify(customerService, never()).getCustomerByIdentification(any(), any());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Delegation verification to dependencies
    // ─────────────────────────────────────────────────────────────────────────

    @Nested
    class DelegationTests {

        @Test
        void givenValidSoapEnvelope_whenConsultarIdentificacion01_thenToDomainCalledWithCorrectSoapRequest() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.just(customerStratio));
            when(soapMapper.toSoap(any())).thenReturn(customerOutputData);

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> assertThat(envelope).isNotNull())
                    .verifyComplete();

            verify(soapMapper).toDomain(soapRequest);
        }

        @Test
        void givenValidSoapEnvelope_whenConsultarIdentificacion01_thenCustomerServiceCalledOnce() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.just(customerStratio));
            when(soapMapper.toSoap(any())).thenReturn(customerOutputData);

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> assertThat(envelope).isNotNull())
                    .verifyComplete();

            verify(customerService).getCustomerByIdentification(eq(domainRequest), any(SoapRequestContext.class));
        }

        @Test
        void givenDomainCustomerAvailable_whenConsultarIdentificacion01_thenToSoapCalledWithCorrectCustomer() {
            // Given
            when(soapMapper.toDomain(any())).thenReturn(domainRequest);
            when(customerService.getCustomerByIdentification(any(), any()))
                    .thenReturn(Mono.just(customerStratio));
            when(soapMapper.toSoap(customerStratio)).thenReturn(customerOutputData);

            // When
            Mono<SoapEnvelopeResponseDto> result = controller.consultarIdentificacion01(soapEnvelope);

            // Then
            StepVerifier.create(result)
                    .assertNext(envelope -> assertThat(envelope).isNotNull())
                    .verifyComplete();

            verify(soapMapper).toSoap(customerStratio);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Extracts the {@link ConsultarIdentificacion01Response} from the response envelope.
     */
    private ConsultarIdentificacion01Response getResponse(SoapEnvelopeResponseDto envelope) {
        assertThat(envelope).isNotNull();
        assertThat(envelope.getBody()).isNotNull();
        ConsultarIdentificacion01Response response =
                envelope.getBody().getConsultarIdentificacion01Response();
        assertThat(response).isNotNull();
        return response;
    }
}
