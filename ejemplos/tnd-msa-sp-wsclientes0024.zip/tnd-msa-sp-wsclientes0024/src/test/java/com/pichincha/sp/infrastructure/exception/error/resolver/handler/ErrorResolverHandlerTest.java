package com.pichincha.sp.infrastructure.exception.error.resolver.handler;

import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.sp.infrastructure.exception.error.resolver.GlobalErrorExceptionResolver;
import com.pichincha.sp.infrastructure.exception.error.resolver.ResponseStatusExceptionResolver;
import com.pichincha.sp.infrastructure.exception.error.resolver.UnexpectedErrorResolver;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.ResponseStatusException;
import reactor.test.StepVerifier;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for ErrorResolverHandler.
 *
 * @author Banco Pichincha
 * @version 1.0
 * @since 2026
 */
@ExtendWith(MockitoExtension.class)
@SuppressWarnings({"unchecked", "rawtypes"})
class ErrorResolverHandlerTest {

    @Mock
    private CustomLogLevelHandler customLogLevelHandler;

    private UnexpectedErrorResolver unexpectedErrorResolver;
    private GlobalErrorExceptionResolver globalErrorExceptionResolver;
    private ResponseStatusExceptionResolver responseStatusExceptionResolver;

    @BeforeEach
    void setUp() {
        unexpectedErrorResolver = new UnexpectedErrorResolver(customLogLevelHandler);
        globalErrorExceptionResolver = new GlobalErrorExceptionResolver(customLogLevelHandler);
        responseStatusExceptionResolver = new ResponseStatusExceptionResolver(customLogLevelHandler);
    }

    @Test
    void givenRuntimeExceptionSinResolver_whenHandle_thenUsaUnexpectedResolverYContentTypeEsXml() {
        // Given
        Map resolverMap = new HashMap();
        ErrorResolverHandler handler = new ErrorResolverHandler(resolverMap, unexpectedErrorResolver);

        MockServerHttpRequest request = MockServerHttpRequest.get("/services/test").build();
        MockServerWebExchange exchange = MockServerWebExchange.from(request);

        // When
        var result = handler.handle(exchange, new RuntimeException("Generic error"));

        // Then
        StepVerifier.create(result).verifyComplete();
        assertThat(exchange.getResponse().getHeaders().getContentType()).isEqualTo(MediaType.APPLICATION_XML);
    }

    @Test
    void givenGlobalErrorExceptionConResolver_whenHandle_thenUsaGlobalResolverYStatusEsBadRequest() {
        // Given
        Map resolverMap = new HashMap();
        resolverMap.put(GlobalErrorException.class, globalErrorExceptionResolver);
        ErrorResolverHandler handler = new ErrorResolverHandler(resolverMap, unexpectedErrorResolver);

        MockServerHttpRequest request = MockServerHttpRequest.get("/services/test").build();
        MockServerWebExchange exchange = MockServerWebExchange.from(request);

        GlobalErrorException ex = new GlobalErrorException("Business error", "Component", HttpStatus.BAD_REQUEST);

        // When
        var result = handler.handle(exchange, ex);

        // Then
        StepVerifier.create(result).verifyComplete();
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(exchange.getResponse().getHeaders().getContentType()).isEqualTo(MediaType.APPLICATION_XML);
    }

    @Test
    void givenResponseStatusExceptionConResolver_whenHandle_thenUsaResponseStatusResolverYStatusEsNotFound() {
        // Given
        Map resolverMap = new HashMap();
        resolverMap.put(ResponseStatusException.class, responseStatusExceptionResolver);
        ErrorResolverHandler handler = new ErrorResolverHandler(resolverMap, unexpectedErrorResolver);

        MockServerHttpRequest request = MockServerHttpRequest.get("/services/unknown").build();
        MockServerWebExchange exchange = MockServerWebExchange.from(request);

        ResponseStatusException ex = new ResponseStatusException(HttpStatus.NOT_FOUND, "Resource not found");

        // When
        var result = handler.handle(exchange, ex);

        // Then
        StepVerifier.create(result).verifyComplete();
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    void givenNullPointerExceptionSinResolver_whenHandle_thenUsaFallbackUnexpectedResolverCon500() {
        // Given
        Map resolverMap = new HashMap();
        resolverMap.put(GlobalErrorException.class, globalErrorExceptionResolver);
        ErrorResolverHandler handler = new ErrorResolverHandler(resolverMap, unexpectedErrorResolver);

        MockServerHttpRequest request = MockServerHttpRequest.get("/services/test").build();
        MockServerWebExchange exchange = MockServerWebExchange.from(request);

        // When
        var result = handler.handle(exchange, new NullPointerException("NPE"));

        // Then
        StepVerifier.create(result).verifyComplete();
        assertThat(exchange.getResponse().getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Test
    void givenIllegalStateExceptionInesperada_whenHandle_thenCompletaCorrectamenteConContentTypeXml() {
        // Given
        Map resolverMap = new HashMap();
        ErrorResolverHandler handler = new ErrorResolverHandler(resolverMap, unexpectedErrorResolver);

        MockServerHttpRequest request = MockServerHttpRequest.post("/IntegrationBus/soap/WSClientes0024").build();
        MockServerWebExchange exchange = MockServerWebExchange.from(request);

        // When
        var result = handler.handle(exchange, new IllegalStateException("Invalid state"));

        // Then
        StepVerifier.create(result).verifyComplete();
        assertThat(exchange.getResponse().getHeaders().getContentType()).isEqualTo(MediaType.APPLICATION_XML);
    }
}
