package com.pichincha.sp.infrastructure.config;

import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import com.pichincha.sp.infrastructure.output.adapter.config.StratioWebClientConfig;
import com.pichincha.sp.infrastructure.output.adapter.properties.WebClientProperties;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.reactive.function.client.WebClient;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Integration tests for StratioWebClientConfig.
 *
 * @author Banco Pichincha
 * @version 2.0
 * @since 2026
 */
@SuppressWarnings("java:S2187") // tests live in @Nested classes
class StratioWebClientConfigTest {

    @Nested
    @SpringBootTest(
            classes = {StratioWebClientConfig.class},
            webEnvironment = SpringBootTest.WebEnvironment.NONE
    )
    @EnableConfigurationProperties(WebClientProperties.class)
    @ActiveProfiles("test")
    @TestPropertySource(properties = {
            "webclient.stratio-customer.uri=http://localhost:9998/services/CustomerService",
            "webclient.stratio-customer.connection-timeout=5000",
            "webclient.stratio-customer.read-timeout=10s",
            "webclient.stratio-customer.max-connections=50",
            "webclient.stratio-customer.max-idle-time=30s",
            "webclient.stratio-customer.pending-acquire-max-count=100",
            "webclient.stratio-customer.pending-acquire-timeout=45s"
    })
    class StandardConfigurationTests {

        @MockBean
        private CustomLogLevelHandler customLogLevelHandler;

        @Autowired
        private WebClient stratioCustomerWebClient;

        @Test
        void givenStandardConfiguration_whenContextLoads_thenWebClientBeanIsCreatedWithoutErrors() {
            // When / Then
            assertThat(stratioCustomerWebClient).isNotNull();
        }
    }

    @Nested
    @SpringBootTest(
            classes = {StratioWebClientConfig.class},
            webEnvironment = SpringBootTest.WebEnvironment.NONE
    )
    @EnableConfigurationProperties(WebClientProperties.class)
    @ActiveProfiles("test")
    @TestPropertySource(properties = {
            "webclient.stratio-customer.uri=http://stratio-host:8080/api/customer",
            "webclient.stratio-customer.connection-timeout=3000",
            "webclient.stratio-customer.read-timeout=7s",
            "webclient.stratio-customer.max-connections=10",
            "webclient.stratio-customer.max-idle-time=20s",
            "webclient.stratio-customer.pending-acquire-max-count=50",
            "webclient.stratio-customer.pending-acquire-timeout=30s"
    })
    class CustomTimeoutsTests {

        @MockBean
        private CustomLogLevelHandler customLogLevelHandler;

        @Autowired
        private WebClient stratioCustomerWebClient;

        @Test
        void givenCustomConfiguration_whenContextLoads_thenWebClientBeanIsCreated() {
            // When / Then
            assertThat(stratioCustomerWebClient).isNotNull();
        }
    }

    @Nested
    @SpringBootTest(
            classes = {StratioWebClientConfig.class},
            webEnvironment = SpringBootTest.WebEnvironment.NONE
    )
    @EnableConfigurationProperties(WebClientProperties.class)
    @ActiveProfiles("test")
    @TestPropertySource(properties = {
            "webclient.stratio-customer.uri=http://stratio-host:9999/retrieve",
            "webclient.stratio-customer.connection-timeout=1000",
            "webclient.stratio-customer.read-timeout=2s",
            "webclient.stratio-customer.max-connections=5",
            "webclient.stratio-customer.max-idle-time=10s",
            "webclient.stratio-customer.pending-acquire-max-count=20",
            "webclient.stratio-customer.pending-acquire-timeout=15s"
    })
    class MinimalConfigurationTests {

        @MockBean
        private CustomLogLevelHandler customLogLevelHandler;

        @Autowired
        private WebClient stratioCustomerWebClient;

        @Test
        void givenMinimalConfiguration_whenContextLoads_thenWebClientBeanIsCreated() {
            // When / Then
            assertThat(stratioCustomerWebClient).isNotNull();
        }
    }
}
