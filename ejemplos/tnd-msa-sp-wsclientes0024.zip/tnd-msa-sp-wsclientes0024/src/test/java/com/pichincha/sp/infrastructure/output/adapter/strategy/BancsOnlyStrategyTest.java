package com.pichincha.sp.infrastructure.output.adapter.strategy;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.sp.application.output.port.BancsCustomerPort;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.sp.domain.request.CustomerRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class BancsOnlyStrategyTest {

    @Mock
    private BancsCustomerPort bancsPort;

    private BancsOnlyStrategy strategy;

    private CustomerRequest validRequest;

    @BeforeEach
    void setUp() {
        strategy = new BancsOnlyStrategy(bancsPort);
        validRequest = new CustomerRequest("0602119182", "0001");
    }

    private Customer buildBancsCustomer() {
        return Customer.builder()
                .cif("3860119")
                .identificacion("0602119182")
                .tipoIdentificacion("0001")
                .nombre("CAISATASIG TORANZO")
                .estado("000")
                .dataSource(DataSourceTypeEnum.BANCS)
                .build();
    }

    @Test
    void givenBancsReturnsCustomer_whenQuery_thenReturnsCustomer() {
        // Given
        Customer customerFromBancs = buildBancsCustomer();
        when(bancsPort.getCustomerInfo(any())).thenReturn(Mono.just(customerFromBancs));

        // When
        Mono<Customer> result = strategy.query(validRequest, null);

        // Then
        StepVerifier.create(result)
                .assertNext(customer -> {
                    assertThat(customer).isNotNull();
                    assertThat(customer.cif()).isEqualTo("3860119");
                    assertThat(customer.identificacion()).isEqualTo("0602119182");
                    assertThat(customer.dataSource()).isEqualTo(DataSourceTypeEnum.BANCS);
                })
                .verifyComplete();

        verify(bancsPort, times(1)).getCustomerInfo(eq(validRequest));
    }

    @Test
    void givenBancsFailsWithGlobalErrorException_whenQuery_thenPropagatesOriginalException() {
        // Given
        GlobalErrorException originalError =
                new GlobalErrorException("E001", "Cliente no encontrado", "BANCS");
        when(bancsPort.getCustomerInfo(any())).thenReturn(Mono.error(originalError));

        // When
        Mono<Customer> result = strategy.query(validRequest, null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> {
                    assertThat(throwable).isSameAs(originalError);
                    GlobalErrorException ex = (GlobalErrorException) throwable;
                    assertThat(ex.getErrorCode()).isEqualTo("E001");
                    assertThat(ex.getMessage()).isEqualTo("Cliente no encontrado");
                    assertThat(ex.getComponent()).isEqualTo("BANCS");
                    return true;
                })
                .verify();
    }

    @Test
    void givenBancsFailsWithRuntimeException_whenQuery_thenWrapsInGlobalErrorException() {
        // Given
        RuntimeException unexpectedError = new RuntimeException("Connection refused");
        when(bancsPort.getCustomerInfo(any())).thenReturn(Mono.error(unexpectedError));

        // When
        Mono<Customer> result = strategy.query(validRequest, null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(throwable -> {
                    assertThat(throwable).isInstanceOf(GlobalErrorException.class);
                    GlobalErrorException ex = (GlobalErrorException) throwable;
                    assertThat(ex.getErrorCode()).isEqualTo("999");
                    assertThat(ex.getMessage()).isEqualTo("Connection refused");
                    assertThat(ex.getComponent()).isEqualTo("BANCS");
                    return true;
                })
                .verify();
    }
}
