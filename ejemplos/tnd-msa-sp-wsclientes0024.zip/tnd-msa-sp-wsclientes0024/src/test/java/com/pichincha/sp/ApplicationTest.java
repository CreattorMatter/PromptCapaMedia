package com.pichincha.sp;

import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import com.pichincha.sp.application.output.port.BancsCustomerPort;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;

/**
 * Tests for Application.java — application entry point.
 *
 * <p>The actual test methods live in the nested classes {@link ContextLoadTests} and
 * {@link MainMethodTests}; this outer class only acts as a logical grouping.
 *
 * @author Banco Pichincha
 * @version 1.0
 * @since 2026
 */
@SuppressWarnings("java:S2187") // tests live in @Nested classes
class ApplicationTest {

    @Nested
    @SpringBootTest(
            webEnvironment = SpringBootTest.WebEnvironment.NONE,
            properties = {
                    "spring.autoconfigure.exclude=com.pichincha.bnc.apiclient.autoconfigure.BancsClientAutoConfiguration,com.pichincha.bnc.apiclient.autoconfigure.BancsCircuitBreakerAutoConfiguration"
            }
    )
    @ActiveProfiles("test")
    class ContextLoadTests {

        @MockBean
        private CustomLogLevelHandler customLogLevelHandler;

        @MockBean
        private BancsCustomerPort bancsCustomerPort;

        @Autowired
        private ApplicationContext applicationContext;

        @Test
        void givenTestConfiguration_whenSpringContextStarts_thenApplicationContextIsNotNull() {
            // When / Then
            assertThat(applicationContext).isNotNull();
        }

        @Test
        void givenStartedContext_whenLookingUpMainBean_thenApplicationBeanIsRegistered() {
            // When / Then
            assertThat(applicationContext.containsBean("application")).isTrue();
        }

        @Test
        void givenStartedContext_whenReadingApplicationName_thenNameIsNotNullOrEmpty() {
            // When
            String appName = applicationContext.getEnvironment().getProperty("spring.application.name");

            // Then
            assertThat(appName).isNotNull().isNotBlank();
        }
    }

    @Nested
    class MainMethodTests {

        @Test
        void givenMockedSpringApplication_whenMainIsInvoked_thenDelegatesToSpringApplicationRunWithoutExceptions() {
            // Given
            try (MockedStatic<SpringApplication> springAppMock = mockStatic(SpringApplication.class)) {
                ConfigurableApplicationContext ctxMock = mock(ConfigurableApplicationContext.class);
                springAppMock
                        .when(() -> SpringApplication.run(any(Class.class), any(String[].class)))
                        .thenReturn(ctxMock);

                // When / Then
                assertThatCode(() -> Application.main(new String[]{}))
                        .doesNotThrowAnyException();

                springAppMock.verify(
                        () -> SpringApplication.run(Application.class, new String[]{}));
            }
        }
    }
}
