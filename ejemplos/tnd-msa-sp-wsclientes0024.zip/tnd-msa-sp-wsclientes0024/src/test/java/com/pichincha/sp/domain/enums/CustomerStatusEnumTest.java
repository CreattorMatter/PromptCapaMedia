package com.pichincha.sp.domain.enums;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CustomerStatusEnumTest {

    @Test
    void givenActiveCode_whenFromCode_thenReturnsActivo() {
        // When
        CustomerStatusEnum result = CustomerStatusEnum.fromCode("000");

        // Then
        assertThat(result).isEqualTo(CustomerStatusEnum.ACTIVO);
    }

    @Test
    void givenInactiveCode_whenFromCode_thenReturnsInactivo() {
        // When
        CustomerStatusEnum result = CustomerStatusEnum.fromCode("001");

        // Then
        assertThat(result).isEqualTo(CustomerStatusEnum.INACTIVO);
    }

    @Test
    void givenBlockedCode_whenFromCode_thenReturnsBloqueado() {
        // When
        CustomerStatusEnum result = CustomerStatusEnum.fromCode("002");

        // Then
        assertThat(result).isEqualTo(CustomerStatusEnum.BLOQUEADO);
    }

    @Test
    void givenSuspendedCode_whenFromCode_thenReturnsSuspendido() {
        // When
        CustomerStatusEnum result = CustomerStatusEnum.fromCode("003");

        // Then
        assertThat(result).isEqualTo(CustomerStatusEnum.SUSPENDIDO);
    }

    @Test
    void givenUnknownCode_whenFromCode_thenReturnsActivoByDefault() {
        // When
        CustomerStatusEnum result = CustomerStatusEnum.fromCode("999");

        // Then
        assertThat(result).isEqualTo(CustomerStatusEnum.ACTIVO);
    }

    @Test
    void givenActivoEnum_whenGetters_thenReturnsCorrectCodeAndDescription() {
        // When / Then
        assertThat(CustomerStatusEnum.ACTIVO.getCode()).isEqualTo("000");
        assertThat(CustomerStatusEnum.ACTIVO.getDescription()).isEqualTo("Activo");
    }

    @Test
    void givenInactivoEnum_whenGetters_thenReturnsCorrectCodeAndDescription() {
        // When / Then
        assertThat(CustomerStatusEnum.INACTIVO.getCode()).isEqualTo("001");
        assertThat(CustomerStatusEnum.INACTIVO.getDescription()).isEqualTo("Inactivo");
    }

    @Test
    void givenBloqueadoEnum_whenGetters_thenReturnsCorrectCodeAndDescription() {
        // When / Then
        assertThat(CustomerStatusEnum.BLOQUEADO.getCode()).isEqualTo("002");
        assertThat(CustomerStatusEnum.BLOQUEADO.getDescription()).isEqualTo("Bloqueado");
    }

    @Test
    void givenSuspendidoEnum_whenGetters_thenReturnsCorrectCodeAndDescription() {
        // When / Then
        assertThat(CustomerStatusEnum.SUSPENDIDO.getCode()).isEqualTo("003");
        assertThat(CustomerStatusEnum.SUSPENDIDO.getDescription()).isEqualTo("Suspendido");
    }
}
