package com.pichincha.sp.infrastructure.output.adapter.bancs.mapper;

import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.infrastructure.output.adapter.bancs.dto.response.CustomerBancsDtoResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for BancsCustomerMapper.
 *
 * @author Banco Pichincha
 * @version 1.0
 * @since 2026
 */
class BancsCustomerMapperTest {

    private BancsCustomerMapper mapper;
    private CustomerRequest request;
    private CustomerBancsDtoResponse.CustomerCollection bancsCustomer;

    @BeforeEach
    void setUp() {
        mapper = new BancsCustomerMapper();
        request = new CustomerRequest("0500563358", "0001");

        bancsCustomer = new CustomerBancsDtoResponse.CustomerCollection(
                "115678", "JUAN PEREZ", "01", "QUITO, AV. AMAZONAS",
                null, "0500563358", "0001", "01", null, "000"
        );
    }

    @Test
    void givenCompleteCustomerCollection_whenToCustomer_thenMapsAllFieldsCorrectly() {
        // When
        Customer result = mapper.toCustomer(bancsCustomer, request);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.cif()).isEqualTo("115678");
        assertThat(result.identificacion()).isEqualTo("0500563358");
        assertThat(result.tipoIdentificacion()).isEqualTo("0001");
        assertThat(result.nombre()).isEqualTo("JUAN PEREZ");
        assertThat(result.direccion()).isEqualTo("QUITO, AV. AMAZONAS");
        assertThat(result.tipoCliente()).isEqualTo("01");
        assertThat(result.estado()).isEqualTo("000");
        assertThat(result.apellidos()).isNull();
        assertThat(result.nombres()).isNull();
        assertThat(result.dataSource()).isEqualTo(DataSourceTypeEnum.BANCS);
    }

    @Test
    void givenCustomerCollectionWithNullFields_whenToCustomer_thenMapsWithNullsCorrectly() {
        // Given
        CustomerBancsDtoResponse.CustomerCollection bancsCustomerWithNulls =
                new CustomerBancsDtoResponse.CustomerCollection(
                        "115678", null, null, null, null, null, null, null, null, null
                );

        // When
        Customer result = mapper.toCustomer(bancsCustomerWithNulls, request);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.cif()).isEqualTo("115678");
        assertThat(result.identificacion()).isEqualTo("0500563358");
        assertThat(result.tipoIdentificacion()).isEqualTo("0001");
        assertThat(result.nombre()).isNull();
        assertThat(result.direccion()).isNull();
        assertThat(result.tipoCliente()).isNull();
        assertThat(result.estado()).isNull();
        assertThat(result.dataSource()).isEqualTo(DataSourceTypeEnum.BANCS);
    }

    @Test
    void givenRequestWithDifferentIdentification_whenToCustomer_thenPreservesIdentificationFromRequest() {
        // Given
        CustomerRequest differentRequest = new CustomerRequest("9999999999", "0002");

        // When
        Customer result = mapper.toCustomer(bancsCustomer, differentRequest);

        // Then
        assertThat(result.identificacion()).isEqualTo("9999999999");
        assertThat(result.tipoIdentificacion()).isEqualTo("0002");
        assertThat(result.cif()).isEqualTo("115678");
    }

    @Test
    void givenCustomerCollectionWithCustomerType_whenToCustomer_thenMapsCustomerTypeCorrectly() {
        // Given
        CustomerBancsDtoResponse.CustomerCollection naturalPersonClient =
                new CustomerBancsDtoResponse.CustomerCollection(
                        "115678", "MARIA LOPEZ", "01", "GUAYAQUIL, CALLE PRINCIPAL",
                        null, "0987654321", "0001", "01", null, "000"
                );

        // When
        Customer result = mapper.toCustomer(naturalPersonClient, new CustomerRequest("0987654321", "0001"));

        // Then
        assertThat(result.tipoCliente()).isEqualTo("01");
        assertThat(result.nombre()).isEqualTo("MARIA LOPEZ");
    }

    @Test
    void givenCustomerCollectionWithDifferentStatus_whenToCustomer_thenMapsStatusCorrectly() {
        // Given
        CustomerBancsDtoResponse.CustomerCollection inactiveClient =
                new CustomerBancsDtoResponse.CustomerCollection(
                        "115678", "PEDRO GOMEZ", "01", "CUENCA, AV. PRINCIPAL",
                        null, "0123456789", "0001", "01", null, "001"
                );

        // When
        Customer result = mapper.toCustomer(inactiveClient, new CustomerRequest("0123456789", "0001"));

        // Then
        assertThat(result.estado()).isEqualTo("001");
        assertThat(result.cif()).isEqualTo("115678");
    }
}
