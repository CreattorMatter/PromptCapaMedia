package com.pichincha.sp.infrastructure.config;

import com.pichincha.sp.application.output.port.BancsCustomerPort;
import com.pichincha.sp.application.output.port.CustomerQueryStrategyPort;
import com.pichincha.sp.application.output.port.StratioCustomerPort;
import com.pichincha.sp.infrastructure.output.adapter.strategy.BancsOnlyStrategy;
import com.pichincha.sp.infrastructure.output.adapter.strategy.BancsWithOcpFailoverStrategy;
import com.pichincha.sp.infrastructure.output.adapter.strategy.OcpOnlyStrategy;
import com.pichincha.sp.infrastructure.output.adapter.strategy.OcpWithBancsFailoverStrategy;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;

import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for CustomerStrategyConfig.
 *
 * @author Banco Pichincha
 * @version 1.0
 * @since 2026
 */
@ExtendWith(MockitoExtension.class)
class CustomerStrategyConfigTest {

    @Mock
    private StratioCustomerPort stratioCustomerPort;

    @Mock
    private BancsCustomerPort bancsCustomerPort;

    @Mock
    private CustomLogLevelHandler customLogLevelHandler;

    @ParameterizedTest(name = "Given datasource=''{0}'' And failover={1} When customerQueryStrategy Then returns {2}")
    @MethodSource("strategySelectionArgs")
    void givenDatasourceAndFailover_whenCustomerQueryStrategy_thenSelectsCorrectStrategy(
            String datasource,
            boolean failoverEnabled,
            Class<? extends CustomerQueryStrategyPort> expectedClass) {

        // Given
        CustomerPropertiesConfig props = buildProps(datasource, failoverEnabled);
        CustomerStrategyConfig config = new CustomerStrategyConfig(props, stratioCustomerPort, bancsCustomerPort, customLogLevelHandler);

        // When
        CustomerQueryStrategyPort strategy = config.customerQueryStrategy();

        // Then
        assertThat(strategy).isInstanceOf(expectedClass);
    }

    static Stream<Arguments> strategySelectionArgs() {
        return Stream.of(
                Arguments.of("OCP",   true,  OcpWithBancsFailoverStrategy.class),
                Arguments.of("ocp",   true,  OcpWithBancsFailoverStrategy.class),
                Arguments.of(null,    true,  OcpWithBancsFailoverStrategy.class),
                Arguments.of("OCP",   false, OcpOnlyStrategy.class),
                Arguments.of("BANCS", true,  BancsWithOcpFailoverStrategy.class),
                Arguments.of("bancs", true,  BancsWithOcpFailoverStrategy.class),
                Arguments.of("BANCS", false, BancsOnlyStrategy.class)
        );
    }

    private CustomerPropertiesConfig buildProps(String datasource, boolean failoverEnabled) {
        CustomerPropertiesConfig props = new CustomerPropertiesConfig();
        props.setDatasource(datasource);
        CustomerPropertiesConfig.Failover failover = new CustomerPropertiesConfig.Failover();
        failover.setEnabled(failoverEnabled);
        props.setFailover(failover);
        return props;
    }
}
