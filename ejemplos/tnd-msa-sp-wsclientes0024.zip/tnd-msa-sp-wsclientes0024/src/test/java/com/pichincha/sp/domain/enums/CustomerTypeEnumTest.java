package com.pichincha.sp.domain.enums;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for CustomerTypeEnum.
 *
 * @author Banco Pichincha
 * @version 1.0.0
 * @since 2026-03-20
 */
class CustomerTypeEnumTest {

    @Test
    void givenNormalCode_whenFromCode_thenReturnsNormal() {
        // When
        CustomerTypeEnum result = CustomerTypeEnum.fromCode("01");

        // Then
        assertThat(result).isEqualTo(CustomerTypeEnum.NORMAL);
    }

    @Test
    void givenVipCode_whenFromCode_thenReturnsVip() {
        // When
        CustomerTypeEnum result = CustomerTypeEnum.fromCode("02");

        // Then
        assertThat(result).isEqualTo(CustomerTypeEnum.VIP);
    }

    @Test
    void givenCorporateCode_whenFromCode_thenReturnsCorporativo() {
        // When
        CustomerTypeEnum result = CustomerTypeEnum.fromCode("03");

        // Then
        assertThat(result).isEqualTo(CustomerTypeEnum.CORPORATIVO);
    }

    @Test
    void givenUnknownCode_whenFromCode_thenReturnsNormalByDefault() {
        // When
        CustomerTypeEnum result = CustomerTypeEnum.fromCode("99");

        // Then
        assertThat(result).isEqualTo(CustomerTypeEnum.NORMAL);
    }

    @Test
    void givenNormalEnum_whenGetters_thenReturnsCorrectCodeAndDescription() {
        // When / Then
        assertThat(CustomerTypeEnum.NORMAL.getCode()).isEqualTo("01");
        assertThat(CustomerTypeEnum.NORMAL.getDescription()).isEqualTo("Normal");
    }

    @Test
    void givenVipEnum_whenGetters_thenReturnsCorrectCodeAndDescription() {
        // When / Then
        assertThat(CustomerTypeEnum.VIP.getCode()).isEqualTo("02");
        assertThat(CustomerTypeEnum.VIP.getDescription()).isEqualTo("VIP");
    }

    @Test
    void givenCorporativoEnum_whenGetters_thenReturnsCorrectCodeAndDescription() {
        // When / Then
        assertThat(CustomerTypeEnum.CORPORATIVO.getCode()).isEqualTo("03");
        assertThat(CustomerTypeEnum.CORPORATIVO.getDescription()).isEqualTo("Corporativo");
    }
}
