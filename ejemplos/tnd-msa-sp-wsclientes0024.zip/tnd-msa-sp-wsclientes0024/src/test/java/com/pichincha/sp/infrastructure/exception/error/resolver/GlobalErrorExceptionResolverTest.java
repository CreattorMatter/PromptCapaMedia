package com.pichincha.sp.infrastructure.exception.error.resolver;

import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultEnvelopeDto;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.server.ServerWebExchange;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for GlobalErrorExceptionResolver.
 */
@ExtendWith(MockitoExtension.class)
class GlobalErrorExceptionResolverTest {

    @Mock
    private CustomLogLevelHandler customLogLevelHandler;

    private GlobalErrorExceptionResolver resolver;

    @BeforeEach
    void setUp() {
        resolver = new GlobalErrorExceptionResolver(customLogLevelHandler);
    }

    @Test
    void givenGlobalErrorExceptionWithData_whenBuildError_thenBuildsEnvelopeCorrectly() {
        // Given
        ServerHttpResponse response = mock(ServerHttpResponse.class);
        GlobalErrorException ex = new GlobalErrorException("Business error", "TestComponent", HttpStatus.BAD_REQUEST);

        // When
        SoapFaultEnvelopeDto result = resolver.buildError(response, "/services/test", ex);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getFault()).isNotNull();
        assertThat(result.getBody().getFault().getFaultCode()).isEqualTo("soapenv:Client");
        assertThat(result.getBody().getFault().getFaultString()).isEqualTo("Service exception");
        assertThat(result.getBody().getFault().getDetail()).contains("Business error");
    }

    @Test
    void givenGlobalErrorExceptionWith500_whenBuildError_thenSetsStatusCodeInResponse() {
        // Given
        ServerHttpResponse response = mock(ServerHttpResponse.class);
        GlobalErrorException ex = new GlobalErrorException("Internal error", "TX060480", HttpStatus.INTERNAL_SERVER_ERROR);

        // When
        resolver.buildError(response, "/services/test", ex);

        // Then
        verify(response).setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Test
    void givenSimplifiedGlobalErrorException_whenBuildError_thenSetsStatus500AndBuildsEnvelope() {
        // Given
        ServerHttpResponse response = mock(ServerHttpResponse.class);
        GlobalErrorException ex = new GlobalErrorException("Generic error");

        // When
        SoapFaultEnvelopeDto result = resolver.buildError(response, "/services/test", ex);

        // Then
        assertThat(result).isNotNull();
        verify(response).setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(result.getBody().getFault().getDetail()).contains("Generic error");
    }

    @Test
    void givenGlobalErrorExceptionWithComponent_whenBuildError_thenDetailIncludesMessage() {
        // Given
        ServerHttpResponse response = mock(ServerHttpResponse.class);
        GlobalErrorException ex = new GlobalErrorException("Bancs error", "BancsAdapter");

        // When
        SoapFaultEnvelopeDto result = resolver.buildError(response, "/IntegrationBus/soap/WSClientes0024", ex);

        // Then
        assertThat(result.getBody().getFault().getDetail()).contains("Bancs error");
        assertThat(result.getBody().getFault().getDetail()).contains("Detailed error information:");
    }

    @Test
    void givenGlobalErrorExceptionAndExchange_whenApply_thenReturnsValidEnvelope() {
        // Given
        ServerWebExchange exchange = mock(ServerWebExchange.class);
        ServerHttpResponse response = mock(ServerHttpResponse.class);
        org.springframework.http.server.reactive.ServerHttpRequest request =
                mock(org.springframework.http.server.reactive.ServerHttpRequest.class);
        org.springframework.http.server.RequestPath requestPath =
                mock(org.springframework.http.server.RequestPath.class);

        when(exchange.getResponse()).thenReturn(response);
        when(exchange.getRequest()).thenReturn(request);
        when(request.getPath()).thenReturn(requestPath);
        when(requestPath.toString()).thenReturn("/IntegrationBus/soap/WSClientes0024");

        GlobalErrorException ex = new GlobalErrorException("Processed error", "TestComponent", HttpStatus.BAD_GATEWAY);

        // When
        SoapFaultEnvelopeDto result = resolver.apply(exchange, ex);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getFault()).isNotNull();
    }
}
