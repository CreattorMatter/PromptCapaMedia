package com.pichincha.sp.infrastructure.exception.error.resolver;

import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultEnvelopeDto;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.server.ServerWebExchange;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for ResponseStatusExceptionResolver.
 *
 * @author Banco Pichincha
 * @version 1.0.0
 * @since 2026-03-20
 */
@ExtendWith(MockitoExtension.class)
class ResponseStatusExceptionResolverTest {

    @Mock
    private CustomLogLevelHandler customLogLevelHandler;

    private ResponseStatusExceptionResolver resolver;

    @BeforeEach
    void setUp() {
        resolver = new ResponseStatusExceptionResolver(customLogLevelHandler);
    }

    @Test
    void givenProblemDetailWithTitleAndDetail_whenBuildBaseErrorModel_thenBuildsEnvelopeCorrectly() {
        // Given
        ProblemDetail problemDetail = ProblemDetail.forStatus(HttpStatus.BAD_REQUEST);
        problemDetail.setTitle("Error title");
        problemDetail.setDetail("Error detail");

        // When
        SoapFaultEnvelopeDto result = resolver.buildBaseErrorModel(problemDetail);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getFault()).isNotNull();
        assertThat(result.getBody().getFault().getFaultCode()).isEqualTo("soapenv:Client");
        assertThat(result.getBody().getFault().getFaultString()).isEqualTo("Error title");
        assertThat(result.getBody().getFault().getDetail()).contains("Error detail");
    }

    @Test
    void givenResponseStatusExceptionWith404_whenBuildError_thenSetsStatusCodeAndBuildsEnvelope() {
        // Given
        ServerHttpResponse response = mock(ServerHttpResponse.class);
        ResponseStatusException ex = new ResponseStatusException(HttpStatus.NOT_FOUND, "Resource not found");

        // When
        SoapFaultEnvelopeDto result = resolver.buildError(response, "/services/test", ex);

        // Then
        assertThat(result).isNotNull();
        verify(response).setStatusCode(HttpStatus.NOT_FOUND);
    }

    @Test
    void givenResponseStatusExceptionAndExchange_whenApply_thenReturnsValidEnvelope() {
        // Given
        ServerWebExchange exchange = mock(ServerWebExchange.class);
        ServerHttpResponse response = mock(ServerHttpResponse.class);
        org.springframework.http.server.reactive.ServerHttpRequest request =
                mock(org.springframework.http.server.reactive.ServerHttpRequest.class);
        org.springframework.http.server.RequestPath requestPath =
                mock(org.springframework.http.server.RequestPath.class);

        when(exchange.getResponse()).thenReturn(response);
        when(exchange.getRequest()).thenReturn(request);
        when(request.getPath()).thenReturn(requestPath);
        when(requestPath.toString()).thenReturn("/services/test");

        ResponseStatusException ex = new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "Service unavailable");

        // When
        SoapFaultEnvelopeDto result = resolver.apply(exchange, ex);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getFault()).isNotNull();
    }

    @Test
    void givenProblemDetailWithoutDetail_whenBuildBaseErrorModel_thenFaultStringReflectsTitle() {
        // Given
        ProblemDetail problemDetail = ProblemDetail.forStatus(HttpStatus.INTERNAL_SERVER_ERROR);
        problemDetail.setTitle("Internal error");

        // When
        SoapFaultEnvelopeDto result = resolver.buildBaseErrorModel(problemDetail);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getBody().getFault().getFaultString()).isEqualTo("Internal error");
    }
}
