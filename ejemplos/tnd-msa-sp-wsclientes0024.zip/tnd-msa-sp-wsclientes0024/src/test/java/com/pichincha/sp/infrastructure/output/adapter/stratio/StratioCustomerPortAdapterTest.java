package com.pichincha.sp.infrastructure.output.adapter.stratio;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.infrastructure.output.adapter.stratio.dto.StratioCustomerRequestDto;
import com.pichincha.sp.infrastructure.output.adapter.stratio.dto.StratioCustomerResponseDto;
import com.pichincha.sp.infrastructure.output.adapter.stratio.mapper.StratioMapper;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class StratioCustomerPortAdapterTest {

    @Mock
    private WebClient stratioWebClient;

    @Mock
    private CustomLogLevelHandler customLogLevelHandler;

    @Mock
    private StratioMapper stratioMapper;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    @SuppressWarnings("rawtypes")
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    private StratioCustomerPortAdapter adapter;

    @BeforeEach
    void setUp() {
        adapter = new StratioCustomerPortAdapter(stratioWebClient, customLogLevelHandler, stratioMapper);
        ReflectionTestUtils.setField(adapter, "stratioSoapNamespace", "http://example.com/wsdl/ExampleService");
        ReflectionTestUtils.setField(adapter, "stratioSoapOperation", "CustomerRequest");
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private StratioCustomerResponseDto buildSuccessResponse() {
        return StratioCustomerResponseDto.builder()
                .body(StratioCustomerResponseDto.Body.builder()
                        .customerResponse(StratioCustomerResponseDto.CustomerResponse.builder()
                                .bodyOut(StratioCustomerResponseDto.BodyOut.builder()
                                        .cif("0000000003860119")
                                        .identification("0602119182")
                                        .typeOfIdentification("0001")
                                        .name("CAISATASIG TORANZO  CIURLIZA ESCALERA DE CARCHIPULLA")
                                        .address("MEDARDO ANGEL SILVA")
                                        .customerType("01")
                                        .status("000")
                                        .build())
                                .error(StratioCustomerResponseDto.Error.builder()
                                        .codError("0")
                                        .descError("OK")
                                        .build())
                                .build())
                        .build())
                .build();
    }

    private StratioCustomerResponseDto buildErrorResponse(String codError, String descError) {
        return StratioCustomerResponseDto.builder()
                .body(StratioCustomerResponseDto.Body.builder()
                        .customerResponse(StratioCustomerResponseDto.CustomerResponse.builder()
                                .error(StratioCustomerResponseDto.Error.builder()
                                        .codError(codError)
                                        .descError(descError)
                                        .build())
                                .build())
                        .build())
                .build();
    }

    private Customer buildExpectedCustomer(String cif, String identificacion, String nombre, String estado) {
        return Customer.builder()
                .cif(cif)
                .identificacion(identificacion)
                .nombre(nombre)
                .estado(estado)
                .apellidos("")
                .nombres("")
                .dataSource(DataSourceTypeEnum.STRATIO)
                .build();
    }

    @SuppressWarnings("unchecked")
    private void mockWebClientChain(Mono<StratioCustomerResponseDto> responseMono) {
        when(stratioWebClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(StratioCustomerResponseDto.class)).thenReturn(responseMono);
    }

    private void mockMapperForSuccessFlow(Customer expectedCustomer) {
        when(stratioMapper.toSoapRequest(any(), anyString(), anyString()))
                .thenReturn(StratioCustomerRequestDto.builder().build());
        when(stratioMapper.isSuccessResponse(any())).thenReturn(true);
        when(stratioMapper.toCustomer(any(), any(), anyString())).thenReturn(expectedCustomer);
    }

    private void mockMapperForErrorFlow(String codError, String descError) {
        when(stratioMapper.toSoapRequest(any(), anyString(), anyString()))
                .thenReturn(StratioCustomerRequestDto.builder().build());
        when(stratioMapper.isSuccessResponse(any())).thenReturn(false);
        when(stratioMapper.getErrorCode(any())).thenReturn(codError);
        when(stratioMapper.getErrorDescription(any())).thenReturn(descError);
    }

    // ─── getCustomerInfo tests ───────────────────────────────────────────────

    @Test
    void givenSuccessfulResponse_whenGetCustomerInfo_thenReturnsCustomerSuccessfully() {
        // Given
        mockWebClientChain(Mono.just(buildSuccessResponse()));
        Customer expected = buildExpectedCustomer(
                "0000000003860119", "0602119182",
                "CAISATASIG TORANZO  CIURLIZA ESCALERA DE CARCHIPULLA", "000");
        mockMapperForSuccessFlow(expected);

        CustomerRequest request = new CustomerRequest("0602119182", "0001");

        // When
        Mono<Customer> result = adapter.getCustomerInfo(request, "0000000003860119", null);

        // Then
        StepVerifier.create(result)
                .expectNextMatches(c -> {
                    assertThat(c.cif()).isEqualTo("0000000003860119");
                    assertThat(c.identificacion()).isEqualTo("0602119182");
                    assertThat(c.nombre()).contains("CAISATASIG TORANZO");
                    assertThat(c.estado()).isEqualTo("000");
                    return true;
                })
                .verifyComplete();
    }

    @Test
    void givenNonNullHeader_whenGetCustomerInfo_thenWorksCorrectly() {
        // Given
        mockWebClientChain(Mono.just(buildSuccessResponse()));
        Customer expected = buildExpectedCustomer("0000000003860119", "0602119182", "TEST", "000");
        mockMapperForSuccessFlow(expected);

        CustomerRequest request = new CustomerRequest("0602119182", "0001");
        SoapRequestContext requestContext = SoapRequestContext.of("USINTERT", "02", "DEVICE-001");

        // When
        Mono<Customer> result = adapter.getCustomerInfo(request, "0000000003860119", requestContext);

        // Then
        StepVerifier.create(result)
                .expectNextMatches(c -> {
                    assertThat(c.cif()).isEqualTo("0000000003860119");
                    return true;
                })
                .verifyComplete();
    }

    @Test
    void givenCodErrorNotZero_whenGetCustomerInfo_thenPropagatesGlobalErrorException() {
        // Given
        mockWebClientChain(Mono.just(buildErrorResponse("E001", "Cliente no encontrado")));
        mockMapperForErrorFlow("E001", "Cliente no encontrado");

        CustomerRequest request = new CustomerRequest("9999999999", "0001");

        // When
        Mono<Customer> result = adapter.getCustomerInfo(request, "000000", null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(ex ->
                        ex instanceof GlobalErrorException &&
                        ex.getMessage().contains("Cliente no encontrado"))
                .verify();
    }

    @Test
    void givenHttpError_whenGetCustomerInfo_thenWrapsInGlobalErrorException() {
        // Given
        when(stratioMapper.toSoapRequest(any(), anyString(), anyString()))
                .thenReturn(StratioCustomerRequestDto.builder().build());
        mockWebClientChain(Mono.error(
                WebClientResponseException.create(500, "Internal Server Error", null, null, null)));

        CustomerRequest request = new CustomerRequest("0602119182", "0001");

        // When
        Mono<Customer> result = adapter.getCustomerInfo(request, "0000000003860119", null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(ex ->
                        ex instanceof GlobalErrorException &&
                        ex.getMessage().contains("Error HTTP en servicio Stratio"))
                .verify();
    }

    @Test
    void givenUnexpectedError_whenGetCustomerInfo_thenWrapsInGlobalErrorException() {
        // Given
        when(stratioMapper.toSoapRequest(any(), anyString(), anyString()))
                .thenReturn(StratioCustomerRequestDto.builder().build());
        mockWebClientChain(Mono.error(new RuntimeException("Connection refused")));

        CustomerRequest request = new CustomerRequest("0602119182", "0001");

        // When
        Mono<Customer> result = adapter.getCustomerInfo(request, "0000000003860119", null);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(GlobalErrorException.class::isInstance)
                .verify();
    }

    // ─── Fallback (Circuit Breaker) tests ────────────────────────────────────

    @Test
    void givenOpenCircuit_whenFallback_thenReturnsGlobalErrorException() {
        // Given
        CustomerRequest request = new CustomerRequest("0602119182", "0001");
        CallNotPermittedException callNotPermitted =
                CallNotPermittedException.createCallNotPermittedException(
                        CircuitBreaker.ofDefaults("ocp-client"));

        // When
        Mono<Customer> result = adapter.fallback(request, "000", null, callNotPermitted);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(ex ->
                        ex instanceof GlobalErrorException &&
                        ex.getMessage().contains("Stratio no disponible (circuit breaker ocp-client)"))
                .verify();
    }

    @Test
    void givenExistingGlobalErrorException_whenFallback_thenPropagatesOriginalWithoutWrapping() {
        // Given
        CustomerRequest request = new CustomerRequest("0602119182", "0001");
        GlobalErrorException original = new GlobalErrorException("Error original desde Stratio");

        // When
        Mono<Customer> result = adapter.fallback(request, "000", null, original);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(ex ->
                        ex instanceof GlobalErrorException &&
                        ex.getMessage().equals("Error original desde Stratio"))
                .verify();
    }

    @Test
    void givenRuntimeException_whenFallback_thenWrapsInGlobalErrorException() {
        // Given
        CustomerRequest request = new CustomerRequest("0602119182", "0001");
        SoapRequestContext ctx = SoapRequestContext.of("USINTERT", "02", "DEV-001");
        RuntimeException cause = new RuntimeException("Connection refused");

        // When
        Mono<Customer> result = adapter.fallback(request, "0000000003860119", ctx, cause);

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(ex ->
                        ex instanceof GlobalErrorException &&
                        ex.getMessage().contains("Stratio no disponible (circuit breaker ocp-client)") &&
                        ex.getMessage().contains("Connection refused"))
                .verify();
    }

    // ─── buildSoapRequest tests ──────────────────────────────────────────────

    @Test
    void givenValidCustomerRequest_whenBuildSoapRequest_thenDelegatesToMapperWithCorrectParams() {
        // Given
        CustomerRequest request = new CustomerRequest("0602119182", "0001");
        StratioCustomerRequestDto expectedDto = StratioCustomerRequestDto.builder().build();

        when(stratioMapper.toSoapRequest(
                eq(request),
                eq("http://example.com/wsdl/ExampleService"),
                eq("CustomerRequest")))
                .thenReturn(expectedDto);

        // When
        StratioCustomerRequestDto result = adapter.buildSoapRequest(request);

        // Then
        assertThat(result).isSameAs(expectedDto);
        verify(stratioMapper).toSoapRequest(request, "http://example.com/wsdl/ExampleService", "CustomerRequest");
    }

    // ─── processResponse tests ───────────────────────────────────────────────

    @Test
    void givenSuccessfulResponseDto_whenProcessResponse_thenReturnsCustomer() {
        // Given
        StratioCustomerResponseDto responseDto = buildSuccessResponse();
        CustomerRequest request = new CustomerRequest("0602119182", "0001");

        when(stratioMapper.isSuccessResponse(any())).thenReturn(true);
        Customer expectedCustomer = buildExpectedCustomer(
                "0000000003860119", "0602119182",
                "CAISATASIG TORANZO  CIURLIZA ESCALERA DE CARCHIPULLA", "000");
        when(stratioMapper.toCustomer(any(), any(), anyString())).thenReturn(expectedCustomer);

        // When
        Mono<Customer> result = adapter.processResponse(responseDto, request, "0000000003860119");

        // Then
        StepVerifier.create(result)
                .expectNextMatches(c -> {
                    assertThat(c.cif()).isEqualTo("0000000003860119");
                    assertThat(c.identificacion()).isEqualTo("0602119182");
                    return true;
                })
                .verifyComplete();
    }

    @Test
    void givenErrorResponseDto_whenProcessResponse_thenThrowsGlobalErrorException() {
        // Given
        StratioCustomerResponseDto responseDto = buildErrorResponse("E001", "Cliente no encontrado");
        CustomerRequest request = new CustomerRequest("9999999999", "0001");

        when(stratioMapper.isSuccessResponse(any())).thenReturn(false);
        when(stratioMapper.getErrorCode(any())).thenReturn("E001");
        when(stratioMapper.getErrorDescription(any())).thenReturn("Cliente no encontrado");

        // When
        Mono<Customer> result = adapter.processResponse(responseDto, request, "000");

        // Then
        StepVerifier.create(result)
                .expectErrorMatches(ex ->
                        ex instanceof GlobalErrorException &&
                        ex.getMessage().contains("Cliente no encontrado"))
                .verify();
    }
}
