package com.pichincha.sp.infrastructure.output.adapter.bancs;

import com.pichincha.bnc.apiclient.adapter.BancsClientAdapter;
import com.pichincha.bnc.apiclient.dto.request.BancsRequest;
import com.pichincha.bnc.apiclient.dto.response.BancsError;
import com.pichincha.bnc.apiclient.dto.response.BancsResponse;
import com.pichincha.bnc.apiclient.exception.BancsAPIClientException;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.infrastructure.output.adapter.bancs.dto.request.CustomerBancsDtoRequest;
import com.pichincha.sp.infrastructure.output.adapter.bancs.dto.response.CustomerBancsDtoResponse;
import com.pichincha.sp.infrastructure.output.adapter.bancs.mapper.BancsCustomerMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {@link CustomerAdapterBancs}.
 *
 * <p>Covers all adapter flows:</p>
 * <ul>
 *   <li>Successful query with correct Bancs response</li>
 *   <li>Error in Bancs response (non-null {@code error} field)</li>
 *   <li>Null body in response -> error 999</li>
 *   <li>Empty or null collection -> error 404</li>
 *   <li>{@link BancsAPIClientException} -> {@link GlobalErrorException} with standard message</li>
 *   <li>Generic exception -> {@link GlobalErrorException} with TX060480 prefix</li>
 * </ul>
 *
 * @author Banco Pichincha
 * @version 1.0
 * @since 2026
 */
@ExtendWith(MockitoExtension.class)
class CustomerAdapterBancsTest {

    // -----------------------------------------------------------------------
    // Mocks and SUT
    // -----------------------------------------------------------------------

    // BancsClient is a sealed interface that only allows BancsClientAdapter.
    // BancsClientAdapter is mocked directly (non-sealed, compatible with mock-maker-inline).
    @Mock
    private BancsClientAdapter bancsClient;

    @Mock
    private BancsCustomerMapper bancsCustomerMapper;

    private CustomerAdapterBancs adapter;

    // -----------------------------------------------------------------------
    // Constants replicating those from the adapter
    // -----------------------------------------------------------------------

    private static final String TRANSACTION_ID = "060480";
    private static final String COMPONENT_TX   = "TX060480";
    private static final String ERROR_HEADER   = "Error consultando información del cliente en Adaptador Bancs";

    private static final String IDENTIFICACION      = "1712485630";
    private static final String TIPO_IDENTIFICACION = "0001";
    private static final String CIF                 = "3860119";

    // -----------------------------------------------------------------------
    // Setup
    // -----------------------------------------------------------------------

    @BeforeEach
    void setUp() {
        adapter = new CustomerAdapterBancs(bancsClient, bancsCustomerMapper);
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    private CustomerRequest buildRequest() {
        return CustomerRequest.builder()
                .identificacion(IDENTIFICACION)
                .tipoIdentificacion(TIPO_IDENTIFICACION)
                .build();
    }

    private CustomerRequest buildRequest(String identificacion, String tipoIdentificacion) {
        return CustomerRequest.builder()
                .identificacion(identificacion)
                .tipoIdentificacion(tipoIdentificacion)
                .build();
    }

    private CustomerBancsDtoResponse.CustomerCollection buildCollection(String custId, String fullName) {
        return new CustomerBancsDtoResponse.CustomerCollection(
                custId, fullName, "DOMICILIO", "AV. AMAZONAS 4545, QUITO",
                null, IDENTIFICACION, TIPO_IDENTIFICACION, "01", "A", "000");
    }

    private CustomerBancsDtoResponse buildBody(
            List<CustomerBancsDtoResponse.CustomerCollection> collection) {
        return new CustomerBancsDtoResponse(
                null, null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, collection);
    }

    @SuppressWarnings("unchecked")
    private BancsResponse<CustomerBancsDtoResponse> buildBancsResponse(
            CustomerBancsDtoResponse body, BancsError error) {
        return new BancsResponse<>(TRANSACTION_ID, error == null, body, error);
    }

    private Customer buildCustomer(String cif) {
        return Customer.builder()
                .cif(cif)
                .identificacion(IDENTIFICACION)
                .tipoIdentificacion(TIPO_IDENTIFICACION)
                .nombre("JUAN PEREZ GARCIA")
                .direccion("AV. AMAZONAS 4545, QUITO")
                .tipoCliente("01")
                .estado("000")
                .apellidos(null)
                .nombres(null)
                .dataSource(DataSourceTypeEnum.BANCS)
                .build();
    }

    // =======================================================================
    // GROUP 1 — Successful query
    // =======================================================================

    @Nested
    class SuccessfulQuery {

        @Test
        @SuppressWarnings("unchecked")
        void givenBancsRespondsWithValidData_whenGetCustomerInfo_thenReturnsCustomer() {
            // Given
            CustomerRequest request = buildRequest();
            CustomerBancsDtoResponse body =
                    buildBody(List.of(buildCollection(CIF, "JUAN PEREZ GARCIA")));
            BancsResponse<CustomerBancsDtoResponse> bancsResponse = buildBancsResponse(body, null);
            Customer expectedCustomer = buildCustomer(CIF);

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));
            when(bancsCustomerMapper.toCustomer(any(), eq(request)))
                    .thenReturn(expectedCustomer);

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .assertNext(customer -> {
                        assertThat(customer).isNotNull();
                        assertThat(customer.cif()).isEqualTo(CIF);
                        assertThat(customer.identificacion()).isEqualTo(IDENTIFICACION);
                        assertThat(customer.tipoIdentificacion()).isEqualTo(TIPO_IDENTIFICACION);
                        assertThat(customer.nombre()).isEqualTo("JUAN PEREZ GARCIA");
                        assertThat(customer.direccion()).isEqualTo("AV. AMAZONAS 4545, QUITO");
                        assertThat(customer.tipoCliente()).isEqualTo("01");
                        assertThat(customer.estado()).isEqualTo("000");
                        assertThat(customer.dataSource()).isEqualTo(DataSourceTypeEnum.BANCS);
                    })
                    .verifyComplete();
        }

        @Test
        @SuppressWarnings({"unchecked", "rawtypes"})
        void givenValidDomainRequest_whenGetCustomerInfo_thenSendsBancsRequestWithCorrectTransactionIdAndServiceName() {
            // Given
            CustomerRequest request = buildRequest();
            CustomerBancsDtoResponse body =
                    buildBody(List.of(buildCollection(CIF, "JUAN PEREZ")));
            BancsResponse<CustomerBancsDtoResponse> bancsResponse = buildBancsResponse(body, null);

            ArgumentCaptor<BancsRequest> requestCaptor = ArgumentCaptor.forClass(BancsRequest.class);

            when(bancsClient.call(requestCaptor.capture(), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));
            when(bancsCustomerMapper.toCustomer(any(), any())).thenReturn(buildCustomer(CIF));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectNextCount(1)
                    .verifyComplete();

            BancsRequest capturedRequest = requestCaptor.getValue();
            assertThat(capturedRequest.getTransactionId()).isEqualTo(TRANSACTION_ID);
        }

        @Test
        @SuppressWarnings({"unchecked", "rawtypes"})
        void givenRequestWithIdentificationAndType_whenGetCustomerInfo_thenBuildsBodyWithIdentificationAndTypeFromRequest() {
            // Given
            CustomerRequest request = buildRequest("0602119182", "0002");
            CustomerBancsDtoResponse body =
                    buildBody(List.of(buildCollection("999001", "MARIA GARCIA")));
            BancsResponse<CustomerBancsDtoResponse> bancsResponse = buildBancsResponse(body, null);

            ArgumentCaptor<BancsRequest> requestCaptor = ArgumentCaptor.forClass(BancsRequest.class);

            when(bancsClient.call(requestCaptor.capture(), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));
            when(bancsCustomerMapper.toCustomer(any(), any())).thenReturn(buildCustomer("999001"));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectNextCount(1)
                    .verifyComplete();

            CustomerBancsDtoRequest bodyDto =
                    (CustomerBancsDtoRequest) requestCaptor.getValue().getBody();
            assertThat(bodyDto.getIdentificacion()).isEqualTo("0602119182");
            assertThat(bodyDto.getTipoIdentificacion()).isEqualTo("0002");
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenCollectionWithMultipleElements_whenGetCustomerInfo_thenInvokesMapperWithFirstElement() {
            // Given
            CustomerRequest request = buildRequest();
            CustomerBancsDtoResponse.CustomerCollection col1 =
                    buildCollection(CIF, "JUAN PEREZ");
            CustomerBancsDtoResponse.CustomerCollection col2 =
                    buildCollection("9999999", "OTRO CLIENTE");
            CustomerBancsDtoResponse body = buildBody(List.of(col1, col2));
            BancsResponse<CustomerBancsDtoResponse> bancsResponse = buildBancsResponse(body, null);

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));
            when(bancsCustomerMapper.toCustomer(eq(col1), eq(request)))
                    .thenReturn(buildCustomer(CIF));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .assertNext(c -> assertThat(c.cif()).isEqualTo(CIF))
                    .verifyComplete();

            verify(bancsCustomerMapper).toCustomer(eq(col1), eq(request));
            verify(bancsCustomerMapper, never()).toCustomer(eq(col2), any());
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenNullIdentificationType_whenGetCustomerInfo_thenWorksCorrectly() {
            // Given
            CustomerRequest request = buildRequest(IDENTIFICACION, null);
            CustomerBancsDtoResponse body =
                    buildBody(List.of(buildCollection(CIF, "JUAN PEREZ")));
            BancsResponse<CustomerBancsDtoResponse> bancsResponse = buildBancsResponse(body, null);

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));
            when(bancsCustomerMapper.toCustomer(any(), any())).thenReturn(buildCustomer(CIF));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .assertNext(c -> assertThat(c.cif()).isEqualTo(CIF))
                    .verifyComplete();
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenValidRequest_whenGetCustomerInfo_thenInvokesBancsClientExactlyOnce() {
            // Given
            CustomerRequest request = buildRequest();
            CustomerBancsDtoResponse body =
                    buildBody(List.of(buildCollection(CIF, "JUAN PEREZ")));
            BancsResponse<CustomerBancsDtoResponse> bancsResponse = buildBancsResponse(body, null);

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));
            when(bancsCustomerMapper.toCustomer(any(), any())).thenReturn(buildCustomer(CIF));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectNextCount(1)
                    .verifyComplete();

            verify(bancsClient, times(1))
                    .call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class));
        }
    }

    // =======================================================================
    // GROUP 2 — Errors from Bancs response
    // =======================================================================

    @Nested
    class BancsResponseErrors {

        @Test
        @SuppressWarnings("unchecked")
        void givenBancsReturnsError_whenGetCustomerInfo_thenPropagatesGlobalErrorExceptionWithOriginalCodeAndMessage() {
            // Given
            CustomerRequest request = buildRequest();
            BancsError bancsError = new BancsError("404", "Customer not found");
            BancsResponse<CustomerBancsDtoResponse> bancsResponse =
                    buildBancsResponse(null, bancsError);

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectErrorSatisfies(ex -> {
                        assertThat(ex).isInstanceOf(GlobalErrorException.class);
                        GlobalErrorException globalError = (GlobalErrorException) ex;
                        assertThat(globalError.getErrorCode()).isEqualTo("404");
                        assertThat(globalError.getMessage()).isEqualTo("Customer not found");
                        assertThat(globalError.getComponent()).isEqualTo(COMPONENT_TX);
                    })
                    .verify();

            verify(bancsCustomerMapper, never()).toCustomer(any(), any());
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenBancsReturnsErrorCode500_whenGetCustomerInfo_thenPropagatesCodeWithoutModification() {
            // Given
            CustomerRequest request = buildRequest();
            BancsError bancsError = new BancsError("500", "Bancs server internal error");
            BancsResponse<CustomerBancsDtoResponse> bancsResponse =
                    buildBancsResponse(null, bancsError);

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectErrorSatisfies(ex -> {
                        assertThat(ex).isInstanceOf(GlobalErrorException.class);
                        GlobalErrorException globalError = (GlobalErrorException) ex;
                        assertThat(globalError.getErrorCode()).isEqualTo("500");
                        assertThat(globalError.getMessage()).isEqualTo("Bancs server internal error");
                        assertThat(globalError.getComponent()).isEqualTo(COMPONENT_TX);
                    })
                    .verify();
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenBodyIsNull_whenGetCustomerInfo_thenReturnsGlobalErrorExceptionCode999() {
            // Given
            CustomerRequest request = buildRequest();
            BancsResponse<CustomerBancsDtoResponse> bancsResponse =
                    buildBancsResponse(null, null);

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectErrorSatisfies(ex -> {
                        assertThat(ex).isInstanceOf(GlobalErrorException.class);
                        GlobalErrorException globalError = (GlobalErrorException) ex;
                        assertThat(globalError.getErrorCode()).isEqualTo("999");
                        assertThat(globalError.getMessage())
                                .contains("sin body")
                                .contains(IDENTIFICACION);
                        assertThat(globalError.getComponent()).isEqualTo(COMPONENT_TX);
                    })
                    .verify();

            verify(bancsCustomerMapper, never()).toCustomer(any(), any());
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenEmptyCollection_whenGetCustomerInfo_thenReturnsGlobalErrorExceptionCode404() {
            // Given
            CustomerRequest request = buildRequest();
            CustomerBancsDtoResponse body = buildBody(Collections.emptyList());
            BancsResponse<CustomerBancsDtoResponse> bancsResponse = buildBancsResponse(body, null);

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectErrorSatisfies(ex -> {
                        assertThat(ex).isInstanceOf(GlobalErrorException.class);
                        GlobalErrorException globalError = (GlobalErrorException) ex;
                        assertThat(globalError.getErrorCode()).isEqualTo("404");
                        assertThat(globalError.getMessage())
                                .contains("No se encontró cliente")
                                .contains(IDENTIFICACION);
                        assertThat(globalError.getComponent()).isEqualTo(COMPONENT_TX);
                    })
                    .verify();

            verify(bancsCustomerMapper, never()).toCustomer(any(), any());
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenNullCollection_whenGetCustomerInfo_thenReturnsGlobalErrorExceptionCode404() {
            // Given
            CustomerRequest request = buildRequest();
            CustomerBancsDtoResponse body = buildBody(null);
            BancsResponse<CustomerBancsDtoResponse> bancsResponse = buildBancsResponse(body, null);

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectErrorSatisfies(ex -> {
                        assertThat(ex).isInstanceOf(GlobalErrorException.class);
                        GlobalErrorException globalError = (GlobalErrorException) ex;
                        assertThat(globalError.getErrorCode()).isEqualTo("404");
                        assertThat(globalError.getMessage()).contains(IDENTIFICACION);
                        assertThat(globalError.getComponent()).isEqualTo(COMPONENT_TX);
                    })
                    .verify();
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenErrorAndNullBodyPresent_whenGetCustomerInfo_thenErrorTakesPrecedenceOverNullBody() {
            // Given
            CustomerRequest request = buildRequest();
            BancsError bancsError = new BancsError("ERR_001", "Invalid identification");
            // null body AND error present -> Bancs error should take precedence
            BancsResponse<CustomerBancsDtoResponse> bancsResponse =
                    new BancsResponse<>(TRANSACTION_ID, false, null, bancsError);

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectErrorSatisfies(ex -> {
                        assertThat(ex).isInstanceOf(GlobalErrorException.class);
                        GlobalErrorException globalError = (GlobalErrorException) ex;
                        assertThat(globalError.getErrorCode()).isEqualTo("ERR_001");
                        assertThat(globalError.getMessage()).isEqualTo("Invalid identification");
                    })
                    .verify();
        }
    }

    // =======================================================================
    // GROUP 3 — Exceptions thrown by BancsClient (onErrorMap)
    // =======================================================================

    @Nested
    class BancsClientExceptions {

        @Test
        @SuppressWarnings("unchecked")
        void givenBancsAPIClientException_whenGetCustomerInfo_thenMapsToGlobalErrorExceptionWithStandardMessage() {
            // Given
            CustomerRequest request = buildRequest();

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.error(new BancsAPIClientException("Connection refused")));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectErrorSatisfies(ex -> {
                        assertThat(ex).isInstanceOf(GlobalErrorException.class);
                        GlobalErrorException globalError = (GlobalErrorException) ex;
                        assertThat(globalError.getMessage()).isEqualTo(ERROR_HEADER);
                        assertThat(globalError.getComponent()).isEqualTo(COMPONENT_TX);
                        assertThat(globalError.getErrorCode()).isNull();
                    })
                    .verify();

            verify(bancsCustomerMapper, never()).toCustomer(any(), any());
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenBancsAPIClientExceptionWithCode_whenGetCustomerInfo_thenMapsToGlobalErrorExceptionWithStandardMessage() {
            // Given
            CustomerRequest request = buildRequest();

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.error(new BancsAPIClientException("Request timeout", "503")));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectErrorSatisfies(ex -> {
                        assertThat(ex).isInstanceOf(GlobalErrorException.class);
                        GlobalErrorException globalError = (GlobalErrorException) ex;
                        assertThat(globalError.getMessage()).isEqualTo(ERROR_HEADER);
                        assertThat(globalError.getComponent()).isEqualTo(COMPONENT_TX);
                    })
                    .verify();
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenRuntimeException_whenGetCustomerInfo_thenMapsToGlobalErrorExceptionWithTXPrefix() {
            // Given
            CustomerRequest request = buildRequest();

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.error(new RuntimeException("Network failure")));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectErrorSatisfies(ex -> {
                        assertThat(ex).isInstanceOf(GlobalErrorException.class);
                        GlobalErrorException globalError = (GlobalErrorException) ex;
                        assertThat(globalError.getMessage())
                                .startsWith("Error en servicio TX060480")
                                .contains("Network failure");
                    })
                    .verify();

            verify(bancsCustomerMapper, never()).toCustomer(any(), any());
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenExceptionWithNullMessage_whenGetCustomerInfo_thenMapsToGlobalErrorExceptionWithNull() {
            // Given
            CustomerRequest request = buildRequest();

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.error(new RuntimeException((String) null)));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectErrorSatisfies(ex -> {
                        assertThat(ex).isInstanceOf(GlobalErrorException.class);
                        GlobalErrorException globalError = (GlobalErrorException) ex;
                        assertThat(globalError.getMessage())
                                .startsWith("Error en servicio TX060480")
                                .contains("null");
                    })
                    .verify();
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenBancsAPIClientException_whenGetCustomerInfo_thenResultIsGlobalErrorExceptionNeverOriginal() {
            // Given
            CustomerRequest request = buildRequest();

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.error(new BancsAPIClientException("integration error")));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectError(GlobalErrorException.class)
                    .verify();
        }
    }

    // =======================================================================
    // GROUP 4 — Interaction verification between components
    // =======================================================================

    @Nested
    class InteractionVerification {

        @Test
        @SuppressWarnings("unchecked")
        void givenResponseWithBancsError_whenGetCustomerInfo_thenDoesNotInvokeMapper() {
            // Given
            CustomerRequest request = buildRequest();
            BancsResponse<CustomerBancsDtoResponse> bancsResponse =
                    buildBancsResponse(null, new BancsError("ERR", "Error"));

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectError(GlobalErrorException.class)
                    .verify();

            verify(bancsCustomerMapper, never()).toCustomer(any(), any());
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenBancsClientThrowsException_whenGetCustomerInfo_thenDoesNotInvokeMapper() {
            // Given
            CustomerRequest request = buildRequest();

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.error(new BancsAPIClientException("timeout")));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectError(GlobalErrorException.class)
                    .verify();

            verify(bancsCustomerMapper, never()).toCustomer(any(), any());
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenEmptyCollection_whenGetCustomerInfo_thenDoesNotInvokeMapper() {
            // Given
            CustomerRequest request = buildRequest();
            CustomerBancsDtoResponse body = buildBody(Collections.emptyList());
            BancsResponse<CustomerBancsDtoResponse> bancsResponse = buildBancsResponse(body, null);

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectError(GlobalErrorException.class)
                    .verify();

            verify(bancsCustomerMapper, never()).toCustomer(any(), any());
        }

        @Test
        @SuppressWarnings("unchecked")
        void givenSuccessfulQuery_whenGetCustomerInfo_thenInvokesMapperExactlyOnce() {
            // Given
            CustomerRequest request = buildRequest();
            CustomerBancsDtoResponse body =
                    buildBody(List.of(buildCollection(CIF, "JUAN PEREZ")));
            BancsResponse<CustomerBancsDtoResponse> bancsResponse = buildBancsResponse(body, null);

            when(bancsClient.call(any(BancsRequest.class), eq(CustomerBancsDtoResponse.class)))
                    .thenReturn(Mono.just(bancsResponse));
            when(bancsCustomerMapper.toCustomer(any(), any())).thenReturn(buildCustomer(CIF));

            // When
            Mono<Customer> result = adapter.getCustomerInfo(request);

            // Then
            StepVerifier.create(result)
                    .expectNextCount(1)
                    .verifyComplete();

            verify(bancsCustomerMapper, times(1)).toCustomer(any(), any());
        }
    }
}
