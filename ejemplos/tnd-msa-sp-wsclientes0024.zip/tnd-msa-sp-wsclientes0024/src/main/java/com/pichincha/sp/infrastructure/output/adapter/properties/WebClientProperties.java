package com.pichincha.sp.infrastructure.output.adapter.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;
import java.util.List;

@ConfigurationProperties(prefix = "webclient")
public record WebClientProperties(
                                   HttpClientProperties stratioCustomer

                                  ) {
    public record HttpClientProperties(int connectionTimeout, Duration readTimeout, int maxConnections,
                                       Duration maxIdleTime, int pendingAcquireMaxCount, List<String> httpHeaders,
                                       Duration pendingAcquireTimeout, String uri) {
    }
}
