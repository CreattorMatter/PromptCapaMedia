package com.pichincha.sp.infrastructure.config;

import com.pichincha.sp.application.output.port.BancsCustomerPort;
import com.pichincha.sp.application.output.port.CustomerQueryStrategyPort;
import com.pichincha.sp.application.output.port.StratioCustomerPort;
import com.pichincha.sp.infrastructure.output.adapter.strategy.BancsOnlyStrategy;
import com.pichincha.sp.infrastructure.output.adapter.strategy.BancsWithOcpFailoverStrategy;
import com.pichincha.sp.infrastructure.output.adapter.strategy.OcpOnlyStrategy;
import com.pichincha.sp.infrastructure.output.adapter.strategy.OcpWithBancsFailoverStrategy;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevel;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@RequiredArgsConstructor
public class CustomerStrategyConfig {

    private final CustomerPropertiesConfig customerProperties;
    private final StratioCustomerPort stratioCustomerPort;
    private final BancsCustomerPort bancsCustomerPort;
    private final CustomLogLevelHandler customLogLevelHandler;

    @Bean
    public CustomerQueryStrategyPort customerQueryStrategy() {
        String datasource = customerProperties.getDatasource();
        boolean failoverEnabled = customerProperties.getFailover().isEnabled();



        if ("BANCS".equalsIgnoreCase(datasource)) {
            if (failoverEnabled) {
                customLogLevelHandler.log(
                        CustomLogLevel.DEBUG,
                        Thread.currentThread().getStackTrace(),
                        "CustomerStrategyConfig: Estrategia seleccionada → BancsWithOcpFailoverStrategy",
                        (Object) null);
                return new BancsWithOcpFailoverStrategy(bancsCustomerPort, stratioCustomerPort, customLogLevelHandler);
            } else {
                customLogLevelHandler.log(
                        CustomLogLevel.DEBUG,
                        Thread.currentThread().getStackTrace(),
                        "CustomerStrategyConfig: Estrategia seleccionada → BancsOnlyStrategy",
                        (Object) null);
                return new BancsOnlyStrategy(bancsCustomerPort);
            }
        } else {
            if (failoverEnabled) {
                customLogLevelHandler.log(
                        CustomLogLevel.DEBUG,
                        Thread.currentThread().getStackTrace(),
                        "CustomerStrategyConfig: Estrategia seleccionada → OcpWithBancsFailoverStrategy",
                        (Object) null);
                return new OcpWithBancsFailoverStrategy(stratioCustomerPort, bancsCustomerPort, customLogLevelHandler);
            } else {
                customLogLevelHandler.log(
                        CustomLogLevel.DEBUG,
                        Thread.currentThread().getStackTrace(),
                        "CustomerStrategyConfig: Estrategia seleccionada → OcpOnlyStrategy",
                        (Object) null);
                return new OcpOnlyStrategy(stratioCustomerPort);
            }
        }
    }
}
