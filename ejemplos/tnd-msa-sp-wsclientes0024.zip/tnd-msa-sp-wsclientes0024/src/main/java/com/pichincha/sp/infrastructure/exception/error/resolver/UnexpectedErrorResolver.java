package com.pichincha.sp.infrastructure.exception.error.resolver;

import com.pichincha.sp.infrastructure.exception.CatalogExceptionConstants;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultBodyDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultEnvelopeDto;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevel;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

@Component
public final class UnexpectedErrorResolver extends ErrorResolver<Throwable> {

    public UnexpectedErrorResolver(CustomLogLevelHandler customLogLevelHandler) {
        super(Throwable.class, customLogLevelHandler);
    }

    private static final String TITLE_UNEXPECTED_ERROR = "Unexpected error";
    private static final String DETAIL_UNEXPECTED_ERROR =
            "Detailed error information: An unexpected error has occurred";

    @NonNull
    @Override
    protected SoapFaultEnvelopeDto buildError(@NonNull ServerHttpResponse serverResponse,
                                               @NonNull final String requestPath,
                                               @NonNull final Throwable throwable) {
        customLogLevelHandler.log(
                CustomLogLevel.ERROR,
                Thread.currentThread().getStackTrace(),
                TITLE_UNEXPECTED_ERROR + ": {}",
                throwable.getMessage() != null ? throwable.getMessage() : "");

        serverResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
        SoapFaultDto faultDetail = getFaultDetail();
        SoapFaultBodyDto faultBody = new SoapFaultBodyDto();
        faultBody.setFault(faultDetail);
        SoapFaultEnvelopeDto soapFault = new SoapFaultEnvelopeDto();
        soapFault.setBody(faultBody);
        return soapFault;
    }

    private static SoapFaultDto getFaultDetail() {
        SoapFaultDto faultDetail = new SoapFaultDto();
        faultDetail.setFaultCode(CatalogExceptionConstants.FAULT_CODE);
        faultDetail.setFaultString(TITLE_UNEXPECTED_ERROR);
        faultDetail.setDetail(DETAIL_UNEXPECTED_ERROR);
        return faultDetail;
    }
}
