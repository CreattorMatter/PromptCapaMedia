package com.pichincha.sp.infrastructure.output.adapter.stratio;

import com.pichincha.common.trace.logger.annotation.BpLogger;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevel;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import com.pichincha.sp.application.output.port.StratioCustomerPort;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.infrastructure.output.adapter.stratio.dto.StratioCustomerRequestDto;
import com.pichincha.sp.infrastructure.output.adapter.stratio.dto.StratioCustomerResponseDto;
import com.pichincha.sp.infrastructure.output.adapter.stratio.mapper.StratioMapper;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.util.List;

@RequiredArgsConstructor
@Component
public class StratioCustomerPortAdapter implements StratioCustomerPort {

    private final WebClient stratioCustomerWebClient;
    private final CustomLogLevelHandler customLogLevelHandler;
    private final StratioMapper stratioMapper;



    @Value("${stratio.customer.soap-namespace}")
    private String stratioSoapNamespace;

    @Value("${stratio.customer.soap-operation:CustomerRequest}")
    private String stratioSoapOperation;

    @Override
    @CircuitBreaker(name = "ocp-client", fallbackMethod = "fallback")
    @BpLogger
    public Mono<Customer> getCustomerInfo(
            CustomerRequest request,
            String cif,
            SoapRequestContext requestContext) {


        return callStratioSoapService(request, cif)
                .doOnNext(customer -> customLogLevelHandler.log(
                        CustomLogLevel.DEBUG,
                        Thread.currentThread().getStackTrace(),
                        "StratioAdapter: Datos del cliente: CIF={}, Nombre={}, Estado={}",
                        List.of(customer.cif(), customer.nombre(), customer.estado())))
                .onErrorMap(ex -> {
                    if (ex instanceof GlobalErrorException) {
                        return ex;
                    }
                    customLogLevelHandler.log(
                            CustomLogLevel.ERROR,
                            Thread.currentThread().getStackTrace(),
                            "StratioAdapter: Error al consultar información en Stratio para CIF {}: {}",
                            List.of(cif, ex.getMessage() != null ? ex.getMessage() : ""));
                    return new GlobalErrorException(
                            "Error consultando información del cliente en Stratio: " + ex.getMessage(), ex);
                })
                .doFinally(signalType ->
                        customLogLevelHandler.log(
                                CustomLogLevel.INFO,
                                Thread.currentThread().getStackTrace(),
                                "StratioAdapter: Finalizando consulta para identificacion: {}. Signal: {}",
                                List.of(request.identificacion(), signalType)));
    }

    @SuppressWarnings("unused")
    Mono<Customer> fallback(
            CustomerRequest request,
            String cif,
            SoapRequestContext requestContext,
            Throwable throwable) {
        if (throwable instanceof CallNotPermittedException) {
            customLogLevelHandler.log(
                    CustomLogLevel.WARN,
                    Thread.currentThread().getStackTrace(),
                    "StratioAdapter [CB=ocp-client]: Circuito ABIERTO — llamadas bloqueadas temporalmente. Causa: {}",
                    throwable.getMessage());
        } else {
            customLogLevelHandler.log(
                    CustomLogLevel.WARN,
                    Thread.currentThread().getStackTrace(),
                    "StratioAdapter [CB=ocp-client]: Fallback activado por error en Stratio. Causa: {}",
                    throwable.getMessage());
        }

        Throwable wrapped = (throwable instanceof GlobalErrorException)
                ? throwable
                : new GlobalErrorException(
                "Stratio no disponible (circuit breaker ocp-client): " + throwable.getMessage(),
                throwable);

        return Mono.error(wrapped);
    }

    private Mono<Customer> callStratioSoapService(CustomerRequest request, String cif) {

        StratioCustomerRequestDto soapRequest = buildSoapRequest(request);

        return stratioCustomerWebClient.post()

                .bodyValue(soapRequest)
                .retrieve()
                .bodyToMono(StratioCustomerResponseDto.class)
                .onErrorMap(WebClientResponseException.class, ex -> {
                    customLogLevelHandler.log(
                            CustomLogLevel.ERROR,
                            Thread.currentThread().getStackTrace(),
                            "StratioAdapter: Error HTTP al llamar Stratio - Status: {}, Body: {}",
                            List.of(ex.getStatusCode().toString(), ex.getResponseBodyAsString()));
                    return new GlobalErrorException(
                            "Error HTTP en servicio Stratio: " + ex.getStatusCode(), ex);
                })
                .flatMap(responseDto -> processResponse(responseDto, request, cif));
    }

    StratioCustomerRequestDto buildSoapRequest(CustomerRequest request) {
        return stratioMapper.toSoapRequest(request, stratioSoapNamespace, stratioSoapOperation);
    }

    Mono<Customer> processResponse(StratioCustomerResponseDto responseDto, CustomerRequest request, String cif) {
        return Mono.fromCallable(() -> {
            customLogLevelHandler.log(
                    CustomLogLevel.DEBUG,
                    Thread.currentThread().getStackTrace(),
                    "StratioAdapter: Procesando respuesta deserializada de Stratio",
                    (Object) null);
            try {
                validateErrorInResponse(responseDto);
                return mapToCustomer(responseDto, request, cif);

            } catch (GlobalErrorException e) {
                throw e;
            } catch (Exception e) {
                customLogLevelHandler.log(
                        CustomLogLevel.ERROR,
                        Thread.currentThread().getStackTrace(),
                        "StratioAdapter: Error al procesar response: {}",
                        e.getMessage() != null ? e.getMessage() : "");
                throw new GlobalErrorException(
                        "Error al procesar response de Stratio: " + e.getMessage(), e);
            }
        });
    }


    private void validateErrorInResponse(StratioCustomerResponseDto responseDto) {
        StratioCustomerResponseDto.Error error = responseDto.getBody()
                .getCustomerResponse()
                .getError();

        if (!stratioMapper.isSuccessResponse(error)) {
            String codError = stratioMapper.getErrorCode(error);
            String descError = stratioMapper.getErrorDescription(error);

            customLogLevelHandler.log(
                    CustomLogLevel.ERROR,
                    Thread.currentThread().getStackTrace(),
                    "StratioAdapter: Error en response - Código: {}, Descripción: {}",
                    java.util.Arrays.asList(codError, descError));
            throw new GlobalErrorException(codError, descError, "STRATIO");
        }
    }

    private Customer mapToCustomer(StratioCustomerResponseDto responseDto, CustomerRequest request, String cifFallback) {
        StratioCustomerResponseDto.BodyOut bodyOut = responseDto.getBody()
                .getCustomerResponse()
                .getBodyOut();

        Customer customer = stratioMapper.toCustomer(bodyOut, request, cifFallback);

        customLogLevelHandler.log(
                CustomLogLevel.DEBUG,
                Thread.currentThread().getStackTrace(),
                "StratioAdapter: Datos mapeados - CIF: {}, Nombre: {}, Estado: {}",
                java.util.Arrays.asList(customer.cif(), customer.nombre(), customer.estado()));

        return customer;
    }
}
