package com.pichincha.sp.infrastructure.exception.error.resolver;

import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.sp.infrastructure.exception.CatalogExceptionConstants;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultBodyDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultEnvelopeDto;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevel;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
public final class GlobalErrorExceptionResolver extends ErrorResolver<GlobalErrorException> {

    public GlobalErrorExceptionResolver(CustomLogLevelHandler customLogLevelHandler) {
        super(GlobalErrorException.class, customLogLevelHandler);
    }

    @Override
    protected SoapFaultEnvelopeDto buildError(@NonNull ServerHttpResponse serverResponse,
                                               @NonNull String requestPath,
                                               @NonNull GlobalErrorException throwable) {

        customLogLevelHandler.log(
                CustomLogLevel.ERROR,
                Thread.currentThread().getStackTrace(),
                "GlobalErrorException - Componente: {}, Mensaje: {}",
                List.of(throwable.getComponent(), throwable.getMessage()));

        serverResponse.setStatusCode(throwable.getStatusCode());
        SoapFaultDto faultDetail = getFaultDetail(throwable);
        SoapFaultBodyDto faultBody = new SoapFaultBodyDto();
        faultBody.setFault(faultDetail);
        SoapFaultEnvelopeDto soapFault = new SoapFaultEnvelopeDto();
        soapFault.setBody(faultBody);
        return soapFault;
    }

    private static SoapFaultDto getFaultDetail(GlobalErrorException throwable) {

        SoapFaultDto faultDetail = new SoapFaultDto();
        faultDetail.setFaultCode(CatalogExceptionConstants.FAULT_CODE);
        faultDetail.setFaultString(CatalogExceptionConstants.EXCEPTION_TITLE);
        faultDetail.setDetail(CatalogExceptionConstants.DETAILED_ERROR_INFORMATION + throwable.getMessage());
        return faultDetail;
    }
}
