package com.pichincha.sp.infrastructure.output.adapter.strategy;

import com.pichincha.sp.application.output.port.BancsCustomerPort;
import com.pichincha.sp.application.output.port.CustomerQueryStrategyPort;
import com.pichincha.sp.application.output.port.StratioCustomerPort;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevel;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

import java.util.List;

@RequiredArgsConstructor
public class BancsWithOcpFailoverStrategy implements CustomerQueryStrategyPort {
  private final BancsCustomerPort bancsPort;
  private final StratioCustomerPort stratioPort;
  private final CustomLogLevelHandler customLogLevelHandler;

  @Override
  public Mono<Customer> query(
    CustomerRequest request,
    SoapRequestContext requestContext
  ) {
    return bancsPort
      .getCustomerInfo(request)
      .onErrorResume(
        bancsError -> {
          customLogLevelHandler.log(
            CustomLogLevel.WARN,
            Thread.currentThread().getStackTrace(),
            "Strategy Bancs→OCP: Bancs no disponible [{}] — activando FAILOVER a Stratio",
            bancsError.getMessage() != null ? bancsError.getMessage() : ""
          );
          return stratioPort
            .getCustomerInfo(request, null, requestContext)
            .map(customer -> CustomerQueryStrategyPort.withDataSource(customer, DataSourceTypeEnum.STRATIO))
            .onErrorMap(
              stratioError -> {
                customLogLevelHandler.log(
                  CustomLogLevel.ERROR,
                  Thread.currentThread().getStackTrace(),
                  "Strategy Bancs→OCP: AMBOS SERVICIOS FALLARON — Bancs: [{}] | Stratio: [{}]",
                  List.of(
                    bancsError.getMessage() != null ? bancsError.getMessage() : "",
                    stratioError.getMessage() != null ? stratioError.getMessage() : ""
                  )
                );
                if (stratioError instanceof GlobalErrorException globalError) {
                  return globalError;
                }
                return new GlobalErrorException("999", stratioError.getMessage(), "FAILOVER");
              }
            );
        }
      );
  }
}
