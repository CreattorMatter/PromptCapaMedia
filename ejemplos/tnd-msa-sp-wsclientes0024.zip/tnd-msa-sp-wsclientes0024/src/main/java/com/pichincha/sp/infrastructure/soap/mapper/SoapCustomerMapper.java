package com.pichincha.sp.infrastructure.soap.mapper;

import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.exception.BusinessValidationException;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.generated.ConsultarIdentificacion01;
import com.pichincha.sp.generated.DatosClienteEntrada;
import com.pichincha.sp.generated.DatosClienteSalida;
import org.springframework.stereotype.Component;

@Component
public class SoapCustomerMapper {

  public CustomerRequest toDomain(ConsultarIdentificacion01 soapRequest) {

    DatosClienteEntrada bodyIn = soapRequest.getBodyIn();

    if (bodyIn == null) {
      throw new BusinessValidationException("1", "La identificacion es requerida", "ERROR");
    }

    return CustomerRequest
      .builder()
      .identificacion(bodyIn.getIdentificacion())
      .tipoIdentificacion(bodyIn.getTipoIdentificacion())
      .build();
  }

  public DatosClienteSalida toSoap(Customer customer) {
    DatosClienteSalida salida = new DatosClienteSalida();

    salida.setCIF(customer.cif());
    salida.setIdentificacion(customer.identificacion());
    salida.setTipoIdentificacion(customer.tipoIdentificacion());
    salida.setApellidos(customer.apellidos());
    salida.setNombres(customer.nombres());
    salida.setNombre(customer.nombre());
    salida.setDireccion(customer.direccion());
    salida.setTipoCliente(customer.tipoCliente());
    salida.setEstado(customer.estado());

    return salida;
  }
}
