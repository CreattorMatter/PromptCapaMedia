package com.pichincha.sp.domain.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum CustomerStatusEnum {

    ACTIVO("000", "Activo"),
    INACTIVO("001", "Inactivo"),
    BLOQUEADO("002", "Bloqueado"),
    SUSPENDIDO("003", "Suspendido");

    private final String code;
    private final String description;

    public static CustomerStatusEnum fromCode(String code) {
        for (CustomerStatusEnum status : values()) {
            if (status.code.equals(code)) {
                return status;
            }
        }
        return ACTIVO;
    }
}
