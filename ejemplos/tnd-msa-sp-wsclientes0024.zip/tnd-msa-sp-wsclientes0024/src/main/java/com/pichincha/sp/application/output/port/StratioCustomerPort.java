package com.pichincha.sp.application.output.port;

import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import reactor.core.publisher.Mono;

public interface StratioCustomerPort {
  Mono<Customer> getCustomerInfo(
    CustomerRequest request,
    String cif,
    SoapRequestContext requestContext
  );
}
