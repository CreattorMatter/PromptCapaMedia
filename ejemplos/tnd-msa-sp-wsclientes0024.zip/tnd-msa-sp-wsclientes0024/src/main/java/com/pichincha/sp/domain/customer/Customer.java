package com.pichincha.sp.domain.customer;

import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import lombok.Builder;

@Builder
public record Customer(
    String cif,
    String identificacion,
    String tipoIdentificacion,
    String apellidos,
    String nombres,
    String nombre,
    String direccion,
    String tipoCliente,
    String estado,
    DataSourceTypeEnum dataSource
) {
}
