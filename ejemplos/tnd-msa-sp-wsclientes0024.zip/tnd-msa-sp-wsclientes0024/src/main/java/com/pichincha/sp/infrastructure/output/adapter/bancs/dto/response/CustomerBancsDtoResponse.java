package com.pichincha.sp.infrastructure.output.adapter.bancs.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record CustomerBancsDtoResponse(
        @JsonProperty("custLastName") String custLastName,
        @JsonProperty("custFirstName") String custFirstName,
        @JsonProperty("brchNum") Integer branchNumber,
        @JsonProperty("custAddr") String custAddress,
        @JsonProperty("pstCode") String postCode,
        @JsonProperty("homePhnNum") String homePhoneNumber,
        @JsonProperty("strtFrm") Long startFrom,
        @JsonProperty("langCode") Integer languageCode,
        @JsonProperty("custMidName") String custMidName,
        @JsonProperty("idNum") String idNumber,
        @JsonProperty("idTyp") Integer idType,
        @JsonProperty("custName2") String custName2,
        @JsonProperty("custName3") String custName3,
        @JsonProperty("actn") String action,
        @JsonProperty("coCmrclName1") String coCommercialName1,
        @JsonProperty("customerInfoList") List<CustomerCollection> collection1) {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CustomerCollection(
            @JsonProperty("custId") String custId,
            @JsonProperty("fullName") String fullName,
            @JsonProperty("addrTyp") String addressType,
            @JsonProperty("addr1") String address1,
            @JsonProperty("custName2") String custName2,
            @JsonProperty("idNum") String idNum,
            @JsonProperty("idType") String idType,
            @JsonProperty("custType") String custType,
            @JsonProperty("custClassCode") String custClassCode,
            @JsonProperty("custStatus") String custStatus) {
    }
}
