package com.pichincha.sp.infrastructure.soap.helper;

import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.infrastructure.exception.CatalogExceptionConstants;
import com.pichincha.sp.generated.GenericError;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.generated.GenericHeaderOut;
import com.pichincha.sp.generated.TransaccionFinancieraType;
import lombok.experimental.UtilityClass;

@UtilityClass
public class SoapResponseHelper {

  public static GenericHeaderOut buildHeaderOut(GenericHeaderIn headerIn) {
    GenericHeaderOut headerOut = new GenericHeaderOut();
    headerOut.setDocumento(new TransaccionFinancieraType());
    if (headerIn == null) {
      // headerIn puede ser null si el cliente omite <headerIn> o si JAXB no lo deserializa.
      // Se retorna un GenericHeaderOut vacío para evitar NPE y permitir que la respuesta
      // de negocio se complete correctamente.
      return headerOut;
    }
    headerOut.setDispositivo(headerIn.getDispositivo());
    headerOut.setEmpresa(headerIn.getEmpresa());
    headerOut.setCanal(headerIn.getCanal());
    headerOut.setMedio(headerIn.getMedio());
    headerOut.setAplicacion(headerIn.getAplicacion());
    headerOut.setAgencia(headerIn.getAgencia());
    headerOut.setTipoTransaccion(headerIn.getTipoTransaccion());
    headerOut.setGeolocalizacion(headerIn.getGeolocalizacion());
    headerOut.setUsuario(headerIn.getUsuario());
    headerOut.setUnicidad(headerIn.getUnicidad());
    headerOut.setGuid(headerIn.getGuid());
    headerOut.setFechaHora(headerIn.getFechaHora());
    headerOut.setFiller(headerIn.getFiller());
    headerOut.setIdioma(headerIn.getIdioma());
    headerOut.setSesion(headerIn.getSesion());
    headerOut.setIp(headerIn.getIp());
    headerOut.setIdCliente(headerIn.getIdCliente());
    headerOut.setTipoIdCliente(headerIn.getTipoIdCliente());
    headerOut.setBancs(headerIn.getBancs());
    return headerOut;
  }

  // IIB compatibility: STRATIO source returns "OK-OCP", BANCS returns "OK"
  public static String resolveSuccessMessage(Customer customer) {
    if (
      customer.dataSource() != null &&
      DataSourceTypeEnum.STRATIO.equals(customer.dataSource())
    ) {
      return CatalogExceptionConstants.SUCCESS_MESSAGE_OCP;
    }
    return CatalogExceptionConstants.SUCCESS_MESSAGE_BANCS;
  }

  public static GenericError buildGenericError(
    String codigo,
    String mensaje,
    String mensajeNegocio,
    String tipo
  ) {
    GenericError error = new GenericError();
    error.setCodigo(codigo);
    error.setMensaje(mensaje);
    error.setMensajeNegocio(mensajeNegocio);
    error.setTipo(tipo);
    error.setRecurso(CatalogExceptionConstants.WS_RECURSO);
    error.setComponente(CatalogExceptionConstants.WS_COMPONENTE);
    error.setBackend(CatalogExceptionConstants.BACKEND_CODE);
    return error;
  }
}
