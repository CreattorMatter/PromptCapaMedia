package com.pichincha.sp.infrastructure.output.adapter.bancs;

import com.pichincha.bnc.apiclient.adapter.BancsClient;
import com.pichincha.bnc.apiclient.annotations.BancsService;
import com.pichincha.bnc.apiclient.dto.request.BancsRequest;
import com.pichincha.bnc.apiclient.dto.response.BancsResponse;
import com.pichincha.bnc.apiclient.exception.BancsAPIClientException;
import com.pichincha.common.trace.logger.annotation.BpLogger;
import com.pichincha.sp.application.output.port.BancsCustomerPort;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.sp.infrastructure.output.adapter.bancs.dto.request.CustomerBancsDtoRequest;
import com.pichincha.sp.infrastructure.output.adapter.bancs.dto.response.CustomerBancsDtoResponse;
import com.pichincha.sp.infrastructure.output.adapter.bancs.mapper.BancsCustomerMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Objects;

@Component
@RequiredArgsConstructor
public class CustomerAdapterBancs implements BancsCustomerPort {
    @BancsService("ws-tx060480")
    private final BancsClient bancsClient;
    private final BancsCustomerMapper bancsCustomerMapper;

    private static final String TRANSACTION_ID = "060480";
    private static final String ERROR_TX060480_TX = "TX060480";
    private static final String ERROR_TX060480_HEADER = "Error consultando información del cliente en Adaptador Bancs";

    @Override
    @BpLogger
    public Mono<Customer> getCustomerInfo(CustomerRequest request) {

        CustomerBancsDtoRequest bodyDto = CustomerBancsDtoRequest.builder()
                .identificacion(request.identificacion())
                .tipoIdentificacion(request.tipoIdentificacion())
                .build();

        BancsRequest<CustomerBancsDtoRequest> bancsRequest = BancsRequest.<CustomerBancsDtoRequest>builder()
                .transactionId(TRANSACTION_ID)
                .body(bodyDto)
                .build();

        return bancsClient.call(bancsRequest, CustomerBancsDtoResponse.class)
                .onErrorMap(ex -> {
                    if (ex instanceof BancsAPIClientException) {
                        return new GlobalErrorException(ERROR_TX060480_HEADER, ERROR_TX060480_TX);
                    }
                    return new GlobalErrorException("Error en servicio TX060480: " + ex.getMessage(), ex);
                })
                .flatMap(response -> extractCustomerFromResponse(response, request));
    }

    private Mono<Customer> extractCustomerFromResponse(
            BancsResponse<CustomerBancsDtoResponse> bancsResponse,
            CustomerRequest request) {

        if (Objects.nonNull(bancsResponse.error())) {
            return Mono.error(new GlobalErrorException(
                    bancsResponse.error().code(),
                    bancsResponse.error().message(),
                    ERROR_TX060480_TX));
        }

        if (Objects.isNull(bancsResponse.body())) {
            return Mono.error(new GlobalErrorException(
                    "999",
                    "Respuesta de Adaptador Bancs sin body para identificación: " + request.identificacion(),
                    ERROR_TX060480_TX));
        }

        if (Objects.isNull(bancsResponse.body().collection1()) || bancsResponse.body().collection1().isEmpty()) {
            return Mono.error(new GlobalErrorException(
                    "404",
                    "No se encontró cliente con identificación: " + request.identificacion(),
                    ERROR_TX060480_TX));
        }

        CustomerBancsDtoResponse.CustomerCollection customerCollection = bancsResponse.body().collection1().get(0);

        return Mono.just(bancsCustomerMapper.toCustomer(customerCollection, request));
    }
}
