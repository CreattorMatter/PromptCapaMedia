package com.pichincha.sp.infrastructure.output.adapter.config;

import com.pichincha.sp.infrastructure.output.adapter.properties.WebClientProperties;
import io.netty.channel.ChannelOption;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.time.Duration;
import java.util.Objects;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class WebClientConfig {

    public static WebClient.Builder getWebClientBuilder(WebClientProperties.HttpClientProperties properties) {
        return WebClient.builder()
                .baseUrl(Objects.requireNonNull(properties.uri()))
                .clientConnector(new ReactorClientHttpConnector(createHttpClient(properties)));
    }

    private static HttpClient createHttpClient(WebClientProperties.HttpClientProperties properties) {
        return HttpClient.create(createConnectionProvider(properties)).responseTimeout(properties.readTimeout())
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, properties.connectionTimeout())
                .option(ChannelOption.SO_KEEPALIVE, true);
    }

    private static ConnectionProvider createConnectionProvider(WebClientProperties.HttpClientProperties properties) {
        return ConnectionProvider
                .builder("custom")
                .maxConnections(properties.maxConnections() > 0 ?
                        properties.maxConnections() :
                        ConnectionProvider.DEFAULT_POOL_MAX_CONNECTIONS)
                .maxIdleTime(Objects.nonNull(properties.maxIdleTime()) ?
                        properties.maxIdleTime() :
                        Duration.ofMillis(ConnectionProvider.DEFAULT_POOL_MAX_IDLE_TIME))
                .pendingAcquireMaxCount(properties.pendingAcquireMaxCount())
                .pendingAcquireTimeout(Objects.nonNull(properties.pendingAcquireTimeout()) ?
                        properties.pendingAcquireTimeout() :
                        Duration.ofMillis(ConnectionProvider.DEFAULT_POOL_ACQUIRE_TIMEOUT))
                .build();
    }
}
