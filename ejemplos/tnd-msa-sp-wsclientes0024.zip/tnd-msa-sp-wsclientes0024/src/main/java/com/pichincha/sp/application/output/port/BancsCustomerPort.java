package com.pichincha.sp.application.output.port;

import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.request.CustomerRequest;
import reactor.core.publisher.Mono;

public interface BancsCustomerPort {

    Mono<Customer> getCustomerInfo(CustomerRequest request);
}
