package com.pichincha.sp.domain.header;

public record SoapRequestContext(
    String usuario,
    String canal,
    String dispositivo
) {

    public static SoapRequestContext of(String usuario, String canal, String dispositivo) {
        return new SoapRequestContext(usuario, canal, dispositivo);
    }
}
