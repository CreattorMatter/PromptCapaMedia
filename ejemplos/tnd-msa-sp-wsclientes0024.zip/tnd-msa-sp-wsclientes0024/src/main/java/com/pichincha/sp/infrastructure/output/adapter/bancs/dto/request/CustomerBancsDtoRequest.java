package com.pichincha.sp.infrastructure.output.adapter.bancs.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerBancsDtoRequest {

    @JsonProperty("idNum")
    private String identificacion;

    @JsonProperty("idTyp")
    private String tipoIdentificacion;
}
