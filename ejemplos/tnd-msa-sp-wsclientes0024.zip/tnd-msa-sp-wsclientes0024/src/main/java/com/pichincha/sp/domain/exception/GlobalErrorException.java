package com.pichincha.sp.domain.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class GlobalErrorException extends RuntimeException {

    protected final HttpStatus statusCode;
    protected final String message;
    protected final String component;
    protected final String errorCode;

    public GlobalErrorException(String errorCode, String message, String component) {
        super(message);
        this.errorCode = errorCode;
        this.message = message;
        this.component = component;
        this.statusCode = HttpStatus.INTERNAL_SERVER_ERROR;
    }

    public GlobalErrorException(String message, String component, HttpStatus status) {
        super(message);
        this.statusCode = status;
        this.message = message;
        this.component = component;
        this.errorCode = null;
    }

    public GlobalErrorException(String message) {
        super(message);
        this.statusCode = HttpStatus.INTERNAL_SERVER_ERROR;
        this.message = message;
        this.component = "UNKNOWN";
        this.errorCode = null;
    }

    public GlobalErrorException(String message, Throwable cause) {
        super(message, cause);
        this.statusCode = HttpStatus.INTERNAL_SERVER_ERROR;
        this.message = message;
        this.component = "UNKNOWN";
        this.errorCode = null;
    }

    public GlobalErrorException(String message, String component) {
        super(message);
        this.statusCode = HttpStatus.INTERNAL_SERVER_ERROR;
        this.message = message;
        this.component = component;
        this.errorCode = null;
    }
}
