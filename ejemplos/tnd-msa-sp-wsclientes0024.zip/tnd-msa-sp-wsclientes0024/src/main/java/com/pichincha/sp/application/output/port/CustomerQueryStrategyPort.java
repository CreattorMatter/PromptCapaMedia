package com.pichincha.sp.application.output.port;

import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import reactor.core.publisher.Mono;

public interface CustomerQueryStrategyPort {
  Mono<Customer> query(CustomerRequest request, SoapRequestContext requestContext);

  static Customer withDataSource(Customer customer, DataSourceTypeEnum dataSource) {
    return Customer
      .builder()
      .cif(customer.cif())
      .identificacion(customer.identificacion())
      .tipoIdentificacion(customer.tipoIdentificacion())
      .apellidos(customer.apellidos())
      .nombres(customer.nombres())
      .nombre(customer.nombre())
      .direccion(customer.direccion())
      .tipoCliente(customer.tipoCliente())
      .estado(customer.estado())
      .dataSource(dataSource)
      .build();
  }
}
