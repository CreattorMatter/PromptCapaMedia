package com.pichincha.sp.infrastructure.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "customer")
public class CustomerPropertiesConfig {

    private String datasource = "OCP";

    private Failover failover = new Failover();

    @Data
    public static class Failover {
        private boolean enabled = true;
    }
}
