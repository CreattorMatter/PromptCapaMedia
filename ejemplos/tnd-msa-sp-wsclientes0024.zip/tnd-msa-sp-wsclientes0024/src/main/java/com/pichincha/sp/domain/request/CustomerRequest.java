package com.pichincha.sp.domain.request;

import lombok.Builder;

@Builder
public record CustomerRequest(
    String identificacion,
    String tipoIdentificacion
) {
}
