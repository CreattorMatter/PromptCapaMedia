package com.pichincha.sp.infrastructure.output.adapter.strategy;

import com.pichincha.sp.application.output.port.BancsCustomerPort;
import com.pichincha.sp.application.output.port.CustomerQueryStrategyPort;
import com.pichincha.sp.application.output.port.StratioCustomerPort;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevel;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;
import java.util.List;

@RequiredArgsConstructor
public class OcpWithBancsFailoverStrategy implements CustomerQueryStrategyPort {
  private final StratioCustomerPort stratioPort;
  private final BancsCustomerPort bancsPort;
  private final CustomLogLevelHandler customLogLevelHandler;

  @Override
  public Mono<Customer> query(
    CustomerRequest request,
    SoapRequestContext requestContext
  ) {
    return stratioPort
      .getCustomerInfo(request, null, requestContext)
      .map(customer -> CustomerQueryStrategyPort.withDataSource(customer, DataSourceTypeEnum.STRATIO))
      .onErrorResume(
        stratioError -> {
          customLogLevelHandler.log(
            CustomLogLevel.WARN,
            Thread.currentThread().getStackTrace(),
            "Strategy OCP→Bancs: Stratio no disponible [{}] — activando FAILOVER a Bancs TX060480",
            stratioError.getMessage() != null ? stratioError.getMessage() : ""
          );
          return bancsPort
            .getCustomerInfo(request)
            .onErrorMap(
              bancsError -> {
                customLogLevelHandler.log(
                  CustomLogLevel.ERROR,
                  Thread.currentThread().getStackTrace(),
                  "Strategy OCP→Bancs: AMBOS SERVICIOS FALLARON — Stratio: [{}] | Bancs: [{}]",
                  List.of(
                    stratioError.getMessage() != null ? stratioError.getMessage() : "",
                    bancsError.getMessage() != null ? bancsError.getMessage() : ""
                  )
                );
                if (bancsError instanceof GlobalErrorException globalError) {
                  return globalError;
                }
                return new GlobalErrorException("999", bancsError.getMessage(), "FAILOVER");
              }
            );
        }
      );
  }
}
