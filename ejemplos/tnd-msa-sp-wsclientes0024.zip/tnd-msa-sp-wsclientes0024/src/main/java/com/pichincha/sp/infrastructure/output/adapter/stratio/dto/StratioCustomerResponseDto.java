package com.pichincha.sp.infrastructure.output.adapter.stratio.dto;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JacksonXmlRootElement(localName = "Envelope", namespace = "http://schemas.xmlsoap.org/soap/envelope/")
public class StratioCustomerResponseDto {

    @JacksonXmlProperty(localName = "Body", namespace = "http://schemas.xmlsoap.org/soap/envelope/")
    private Body body;

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Body {
        @JacksonXmlProperty(localName = "CustomerResponse", namespace = "http://example.com/wsdl/ExampleService")
        private CustomerResponse customerResponse;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CustomerResponse {
        @JacksonXmlProperty(localName = "bodyOut", namespace = "http://example.com/wsdl/ExampleService")
        private BodyOut bodyOut;

        @JacksonXmlProperty(localName = "error", namespace = "http://example.com/wsdl/ExampleService")
        private Error error;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BodyOut {
        @JacksonXmlProperty(localName = "cif")
        private String cif;

        @JacksonXmlProperty(localName = "identification")
        private String identification;

        @JacksonXmlProperty(localName = "typeOfIdentification")
        private String typeOfIdentification;

        @JacksonXmlProperty(localName = "name")
        private String name;

        @JacksonXmlProperty(localName = "address")
        private String address;

        @JacksonXmlProperty(localName = "customerType")
        private String customerType;

        @JacksonXmlProperty(localName = "status")
        private String status;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Error {
        @JacksonXmlProperty(localName = "codError")
        private String codError;

        @JacksonXmlProperty(localName = "descError")
        private String descError;
    }
}
