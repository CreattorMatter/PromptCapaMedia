package com.pichincha.sp.domain.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum CustomerTypeEnum {

    NORMAL("01", "Normal"),
    VIP("02", "VIP"),
    CORPORATIVO("03", "Corporativo");

    private final String code;
    private final String description;

    public static CustomerTypeEnum fromCode(String code) {
        for (CustomerTypeEnum type : values()) {
            if (type.code.equals(code)) {
                return type;
            }
        }
        return NORMAL;
    }
}
