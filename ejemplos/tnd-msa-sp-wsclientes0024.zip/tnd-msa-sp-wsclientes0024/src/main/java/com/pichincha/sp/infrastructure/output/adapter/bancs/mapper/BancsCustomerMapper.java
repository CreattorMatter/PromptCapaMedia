package com.pichincha.sp.infrastructure.output.adapter.bancs.mapper;

import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.infrastructure.output.adapter.bancs.dto.response.CustomerBancsDtoResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class BancsCustomerMapper {

    public Customer toCustomer(CustomerBancsDtoResponse.CustomerCollection bancsCustomer,
                               CustomerRequest request) {

        return Customer.builder()
                .cif(bancsCustomer.custId())
                .identificacion(request.identificacion())
                .tipoIdentificacion(request.tipoIdentificacion())
                .nombre(bancsCustomer.fullName())
                .direccion(bancsCustomer.address1())
                .tipoCliente(bancsCustomer.custType())
                .estado(bancsCustomer.custStatus())
                .apellidos(null)
                .nombres(null)
                .dataSource(DataSourceTypeEnum.BANCS)
                .build();

    }
}
