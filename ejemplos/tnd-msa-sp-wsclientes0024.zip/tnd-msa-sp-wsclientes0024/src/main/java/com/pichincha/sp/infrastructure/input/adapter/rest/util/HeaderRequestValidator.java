package com.pichincha.sp.infrastructure.input.adapter.rest.util;

import com.pichincha.sp.domain.model.HeaderRequestModel;
import com.pichincha.sp.generated.GenericHeaderOut;

import java.util.Optional;
import java.util.regex.Pattern;

public final class HeaderRequestValidator {

  private static final Pattern DEVICE_PATTERN =
      Pattern.compile("^[A-Za-z0-9\\s_/();.,:\\-+=]*$");
  private static final Pattern ALPHANUMERIC = Pattern.compile("^[A-Za-z0-9]*$");
  private static final Pattern DIGITS_ONLY = Pattern.compile("^\\d*$");
  private static final Pattern ALPHANUMERIC_EXTENDED =
      Pattern.compile("^[A-Za-z\u00C0-\u00FF0-9 .,\\-]*$");
  private static final Pattern BASE64_PATTERN =
      Pattern.compile("^[A-Za-z0-9+/=]*$");
  private static final Pattern ALPHANUMERIC_DASH = Pattern.compile("^[A-Za-z0-9\\-]*$");

  private HeaderRequestValidator() {
  }

  public static Optional<String> validate(GenericHeaderOut header) {
    if (header == null) {
      return Optional.empty();
    }
    return checkField(header.getDispositivo(), 50, DEVICE_PATTERN, "dispositivo")
        .or(() -> checkField(header.getEmpresa(), 5, ALPHANUMERIC, "empresa"))
        .or(() -> checkField(header.getCanal(), 5, DIGITS_ONLY, "canal"))
        .or(() -> checkField(header.getMedio(), 10, DIGITS_ONLY, "medio"))
        .or(() -> checkField(header.getAplicacion(), 8, DIGITS_ONLY, "aplicacion"))
        .or(() -> checkField(header.getAgencia(), 20, DIGITS_ONLY, "agencia"))
        .or(() -> checkField(header.getTipoTransaccion(), 12, DIGITS_ONLY, "tipoTransaccion"))
        .or(() -> checkField(header.getGeolocalizacion(), 100, ALPHANUMERIC_EXTENDED, "geolocalizacion"))
        .or(() -> checkField(header.getUsuario(), 10, ALPHANUMERIC, "usuario"))
        .or(() -> checkField(header.getUnicidad(), 70, BASE64_PATTERN, "unicidad"))
        .or(() -> checkField(header.getGuid(), 36, ALPHANUMERIC_DASH, "guid"))
        .or(() -> checkField(header.getFechaHora(), 40, ALPHANUMERIC_EXTENDED, "fechaHora"))
        .or(() -> checkField(header.getFiller(), 100, ALPHANUMERIC_EXTENDED, "filler"))
        .or(() -> checkField(header.getIdioma(), 10, ALPHANUMERIC_DASH, "idioma"))
        .or(() -> checkField(header.getSesion(), 100, ALPHANUMERIC_EXTENDED, "sesion"))
        .or(() -> checkField(header.getIp(), 50, ALPHANUMERIC_EXTENDED, "ip"))
        .or(() -> checkField(header.getIdCliente(), 15, DIGITS_ONLY, "idCliente"))
        .or(() -> checkField(header.getTipoIdCliente(), 5, ALPHANUMERIC, "tipoIdCliente"));
  }

  private static Optional<String> checkField(
      String value, int maxLength, Pattern pattern, String fieldName) {
    if (value == null || value.isEmpty()) {
      return Optional.empty();
    }
    if (value.length() > maxLength) {
      return Optional.of(
          "Campo " + fieldName + " excede el maximo de " + maxLength + " caracteres");
    }
    if (!pattern.matcher(value).matches()) {
      return Optional.of("Campo " + fieldName + " contiene caracteres no permitidos");
    }
    return Optional.empty();
  }
}
