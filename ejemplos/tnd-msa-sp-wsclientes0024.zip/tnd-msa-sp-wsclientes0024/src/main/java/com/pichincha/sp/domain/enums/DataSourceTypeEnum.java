package com.pichincha.sp.domain.enums;

public enum DataSourceTypeEnum {

    // Stratio (OCP) -> success message "OK-OCP"
    STRATIO,

    // Bancs TX060480 -> success message "OK"
    BANCS
}
