package com.pichincha.sp.application.input.port;

import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import reactor.core.publisher.Mono;

public interface CustomerServicePort {
  Mono<Customer> getCustomerByIdentification(
    CustomerRequest request,
    SoapRequestContext requestContext
  );
}
