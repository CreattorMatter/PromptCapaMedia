@XmlSchema(
    xmlns = {
        @XmlNs(prefix = "NS1", namespaceURI = "http://schemas.xmlsoap.org/soap/envelope/"),
        @XmlNs(prefix = "NS2", namespaceURI = "http://bpichincha.com/servicios")
    }
)
package com.pichincha.sp.infrastructure.input.adapter.rest.dto;

import jakarta.xml.bind.annotation.XmlNs;
import jakarta.xml.bind.annotation.XmlSchema;