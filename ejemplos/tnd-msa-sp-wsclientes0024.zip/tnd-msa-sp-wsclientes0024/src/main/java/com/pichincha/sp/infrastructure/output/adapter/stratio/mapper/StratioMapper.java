package com.pichincha.sp.infrastructure.output.adapter.stratio.mapper;

import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.infrastructure.output.adapter.stratio.dto.StratioCustomerRequestDto;
import com.pichincha.sp.infrastructure.output.adapter.stratio.dto.StratioCustomerResponseDto;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface StratioMapper {

    default StratioCustomerRequestDto toSoapRequest(
            CustomerRequest request,
            @Context String soapNamespace,
            @Context String soapOperation) {

        StratioCustomerRequestDto.CustomerRequest customerRequest = 
                StratioCustomerRequestDto.CustomerRequest.builder()
                        .identificationId(request.identificacion())
                        .identificationTypeId(request.tipoIdentificacion())
                        .build();

        StratioCustomerRequestDto.Body body = StratioCustomerRequestDto.Body.builder()
                .customerRequest(customerRequest)
                .build();

        StratioCustomerRequestDto.Header header = StratioCustomerRequestDto.Header.builder()
                .build();

        return StratioCustomerRequestDto.builder()
                .header(header)
                .body(body)
                .build();
    }

    @Mapping(target = "cif", expression = "java(bodyOut.getCif() != null ? bodyOut.getCif() : cifFallback)")
    @Mapping(target = "identificacion", expression = "java(bodyOut.getIdentification() != null ? bodyOut.getIdentification() : request.identificacion())")
    @Mapping(target = "tipoIdentificacion", expression = "java(bodyOut.getTypeOfIdentification() != null ? bodyOut.getTypeOfIdentification() : request.tipoIdentificacion())")
    @Mapping(source = "bodyOut.name", target = "nombre")
    @Mapping(target = "apellidos", constant = "")
    @Mapping(target = "nombres", constant = "")
    @Mapping(source = "bodyOut.address", target = "direccion")
    @Mapping(source = "bodyOut.customerType", target = "tipoCliente")
    @Mapping(source = "bodyOut.status", target = "estado")
    @Mapping(target = "dataSource", constant = "STRATIO")
    Customer toCustomer(
            StratioCustomerResponseDto.BodyOut bodyOut,
            @Context CustomerRequest request,
            @Context String cifFallback
    );

    default boolean isSuccessResponse(StratioCustomerResponseDto.Error error) {
        return error != null && "0".equals(error.getCodError());
    }

    default String getErrorCode(StratioCustomerResponseDto.Error error) {
        return error != null && error.getCodError() != null 
                ? error.getCodError() 
                : "UNKNOWN";
    }

    default String getErrorDescription(StratioCustomerResponseDto.Error error) {
        return error != null && error.getDescError() != null 
                ? error.getDescError() 
                : "Error en servicio Stratio";
    }
}
