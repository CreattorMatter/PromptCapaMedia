package com.pichincha.sp.infrastructure.output.adapter.config;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.pichincha.sp.infrastructure.output.adapter.properties.WebClientProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.codec.DecoderHttpMessageReader;
import org.springframework.http.codec.EncoderHttpMessageWriter;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
@EnableConfigurationProperties(WebClientProperties.class)
public class StratioWebClientConfig extends WebClientConfig {

    @Bean
    public WebClient.Builder stratioCustomerWebClientBuilder(final WebClientProperties webClientProperties) {
        XmlMapper xmlMapper = new XmlMapper();
        xmlMapper.configure(com.fasterxml.jackson.databind.SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

        ExchangeStrategies strategies = ExchangeStrategies.builder()
                .codecs(configurer -> {
                    configurer.customCodecs().register(
                            new EncoderHttpMessageWriter<>(
                                    new Jackson2JsonEncoder(xmlMapper, MediaType.APPLICATION_XML, MediaType.TEXT_XML)
                            )
                    );
                    configurer.customCodecs().register(
                            new DecoderHttpMessageReader<>(
                                    new Jackson2JsonDecoder(xmlMapper, MediaType.APPLICATION_XML, MediaType.TEXT_XML)
                            )
                    );
                })
                .build();

        return getWebClientBuilder(webClientProperties.stratioCustomer())
                .exchangeStrategies(strategies);
    }

    @Bean
    public WebClient stratioCustomerWebClient(WebClient.Builder customerPaymentsWebClientBuilder) {
        return customerPaymentsWebClientBuilder.build();
    }
}
