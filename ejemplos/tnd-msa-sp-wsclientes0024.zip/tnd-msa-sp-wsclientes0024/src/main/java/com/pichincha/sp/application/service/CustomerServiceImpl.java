package com.pichincha.sp.application.service;

import com.pichincha.common.trace.logger.annotation.BpLogger;
import com.pichincha.sp.application.input.port.CustomerServicePort;
import com.pichincha.sp.application.output.port.CustomerQueryStrategyPort;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.domain.exception.BusinessValidationException;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevel;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Objects;


@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerServicePort {
  private final CustomerQueryStrategyPort customerQueryStrategy;
  private final CustomLogLevelHandler customLogLevelHandler;

  @Override
  @BpLogger
  public Mono<Customer> getCustomerByIdentification(
    CustomerRequest request,
    SoapRequestContext requestContext
  ) {

    return Mono
      .fromCallable(
        () -> {
          validateRequest(request);
          return normalizeIdentification(request);
        }
      )
      .flatMap(normalizedRequest -> customerQueryStrategy.query(normalizedRequest, requestContext));
  }

  /**
   * IIB compatibility: strips leading "000" and trims to last 10 chars; blank
   * tipoIdentificacion is normalized to null.
   *
   * <p>Reference: sqb-msa-wsclientes0024/ConsultarIdentificacion01.esql lines 63-65, 77-80.
   */
  private CustomerRequest normalizeIdentification(CustomerRequest request) {
    String identificacion = request.identificacion();
    String tipoIdentificacion = request.tipoIdentificacion();

    if (tipoIdentificacion != null && tipoIdentificacion.trim().isEmpty()) {
      tipoIdentificacion = null;
    }

    if (identificacion == null) {
      return CustomerRequest
        .builder()
        .identificacion(identificacion)
        .tipoIdentificacion(tipoIdentificacion)
        .build();
    }

    if (identificacion.startsWith("000") && identificacion.length() > 10) {
      String normalizedId = identificacion.substring(
        identificacion.length() - 10
      );
      customLogLevelHandler.log(
        CustomLogLevel.INFO,
        Thread.currentThread().getStackTrace(),
        "Service: Normalizando identificacion de {} a {} (compatibilidad IIB)",
        List.of(identificacion, normalizedId)
      );

      return CustomerRequest
        .builder()
        .identificacion(normalizedId)
        .tipoIdentificacion(tipoIdentificacion)
        .build();
    }

    if (!Objects.equals(tipoIdentificacion, request.tipoIdentificacion())) {
      return CustomerRequest
        .builder()
        .identificacion(identificacion)
        .tipoIdentificacion(tipoIdentificacion)
        .build();
    }

    return request;
  }

  /**
   * IIB legacy validation: identificacion is mandatory (error code "1").
   * tipoIdentificacion is OPTIONAL per the original XSD (minOccurs=0).
   */
  private static void validateRequest(CustomerRequest request) {
    if (request == null) {
      throw new IllegalArgumentException("El request no puede ser nulo");
    }

    if (
      request.identificacion() == null ||
      request.identificacion().trim().isEmpty()
    ) {
      throw new BusinessValidationException(
        "1",
        "Valor del campo identificacion vacio o invalido"
      );
    }
  }
}
