package com.pichincha.sp.infrastructure.input.adapter.rest.impl;

import com.pichincha.common.trace.logger.annotation.BpTraceable;
import com.pichincha.sp.application.input.port.CustomerServicePort;
import com.pichincha.sp.infrastructure.input.adapter.rest.util.HeaderRequestValidator;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.generated.ConsultarIdentificacion01;
import com.pichincha.sp.generated.ConsultarIdentificacion01Response;
import com.pichincha.sp.generated.DatosClienteSalida;
import com.pichincha.sp.generated.GenericHeaderOut;
import com.pichincha.sp.domain.exception.BusinessValidationException;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import com.pichincha.sp.infrastructure.exception.CatalogExceptionConstants;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapBodyResponseDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapEnvelopeRequestDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapEnvelopeResponseDto;
import com.pichincha.sp.infrastructure.soap.helper.SoapResponseHelper;
import com.pichincha.sp.infrastructure.soap.mapper.SoapCustomerMapper;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;


@RestController
@RequiredArgsConstructor
@RequestMapping("/IntegrationBus/soap/WSClientes0024")
public class WSClientes0024Controller {

    private final CustomerServicePort customerService;
    private final SoapCustomerMapper soapMapper;

    @PostMapping(
            consumes = {
                    MediaType.TEXT_XML_VALUE,
                    MediaType.TEXT_XML_VALUE + ";charset=utf-8",
                    MediaType.APPLICATION_XML_VALUE,
                    "application/soap+xml"
            },
            produces = {MediaType.TEXT_XML_VALUE + ";charset=utf-8", MediaType.APPLICATION_XML_VALUE}
    )
    @BpTraceable
    public Mono<SoapEnvelopeResponseDto> consultarIdentificacion01(
            @RequestBody @Valid SoapEnvelopeRequestDto soapRequest) {

        ConsultarIdentificacion01 request = soapRequest.getBody().getConsultarIdentificacion01();

        GenericHeaderOut headerOut = SoapResponseHelper.buildHeaderOut(request.getHeaderIn());
        HeaderRequestValidator.validate(headerOut).ifPresent(errorMsg -> {
            throw new BusinessValidationException("1", errorMsg);
        });

        CustomerRequest customerRequest = soapMapper.toDomain(request);
        SoapRequestContext requestContext = toRequestContext(request.getHeaderIn());

        return customerService.getCustomerByIdentification(customerRequest, requestContext)
                .map(customer -> {
                    DatosClienteSalida datosCliente = soapMapper.toSoap(customer);
                    return buildSuccessResponse(headerOut, datosCliente, customer);
                })
                .onErrorResume(throwable -> {
                    if (throwable instanceof BusinessValidationException businessError) {
                        return Mono.just(buildBusinessErrorResponse(businessError, headerOut));
                    }
                    if (throwable instanceof GlobalErrorException globalError) {
                        return Mono.just(buildServiceErrorResponse(globalError, headerOut));
                    }
                    return Mono.error(throwable);
                });
    }

    private SoapEnvelopeResponseDto buildSuccessResponse(GenericHeaderOut headerOut,
                                                          DatosClienteSalida datosCliente,
                                                          Customer customer) {
        ConsultarIdentificacion01Response response = new ConsultarIdentificacion01Response();
        response.setHeaderOut(headerOut);
        response.setBodyOut(datosCliente);
        String mensaje = SoapResponseHelper.resolveSuccessMessage(customer);
        response.setError(SoapResponseHelper.buildGenericError(
                CatalogExceptionConstants.SUCCESS_CODE,
                mensaje,
                CatalogExceptionConstants.SUCCESS_MENSAJE_NEGOCIO,
                CatalogExceptionConstants.ERROR_TYPE_INFO));

        SoapBodyResponseDto body = new SoapBodyResponseDto();
        body.setConsultarIdentificacion01Response(response);
        return SoapEnvelopeResponseDto.builder().body(body).build();
    }

    private static SoapEnvelopeResponseDto buildBusinessErrorResponse(BusinessValidationException bve,
                                                                       GenericHeaderOut headerOut) {
        ConsultarIdentificacion01Response response = new ConsultarIdentificacion01Response();
        response.setHeaderOut(headerOut);
        response.setError(SoapResponseHelper.buildGenericError(
                bve.getErrorCode(),
                bve.getErrorMessage(),
                bve.getErrorMessage(),
                bve.getErrorType()));

        SoapBodyResponseDto body = new SoapBodyResponseDto();
        body.setConsultarIdentificacion01Response(response);
        return SoapEnvelopeResponseDto.builder().body(body).build();
    }

    // IIB compat: service errors returned as HTTP 200 with error in GenericError
    // (see ConsultarIdentificacion01.esql lines 189, 233)
    private static SoapEnvelopeResponseDto buildServiceErrorResponse(
            GlobalErrorException globalError,
            GenericHeaderOut headerOut) {
        ConsultarIdentificacion01Response response = new ConsultarIdentificacion01Response();
        response.setHeaderOut(headerOut);
        
        String errorCode = globalError.getErrorCode() != null
                ? globalError.getErrorCode() 
                : CatalogExceptionConstants.ERROR_CODE_GENERIC;
        
        response.setError(SoapResponseHelper.buildGenericError(
                errorCode,
                globalError.getMessage(),
                globalError.getMessage(),
                CatalogExceptionConstants.ERROR_TYPE_ERROR));
        
        SoapBodyResponseDto body = new SoapBodyResponseDto();
        body.setConsultarIdentificacion01Response(response);
        return SoapEnvelopeResponseDto.builder().body(body).build();
    }

    private static SoapRequestContext toRequestContext(
            com.pichincha.sp.generated.GenericHeaderIn headerIn) {
        if (headerIn == null) {
            return new SoapRequestContext(null, null, null);
        }
        return SoapRequestContext.of(
                headerIn.getUsuario(),
                headerIn.getCanal(),
                headerIn.getDispositivo());
    }
}
