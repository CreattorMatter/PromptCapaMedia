package com.pichincha.sp.infrastructure.output.adapter.strategy;

import com.pichincha.sp.application.output.port.CustomerQueryStrategyPort;
import com.pichincha.sp.application.output.port.StratioCustomerPort;
import com.pichincha.sp.domain.customer.Customer;
import com.pichincha.sp.domain.enums.DataSourceTypeEnum;
import com.pichincha.sp.domain.header.SoapRequestContext;
import com.pichincha.sp.domain.request.CustomerRequest;
import com.pichincha.sp.domain.exception.GlobalErrorException;
import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
public class OcpOnlyStrategy implements CustomerQueryStrategyPort {
  private final StratioCustomerPort stratioPort;

  @Override
  public Mono<Customer> query(
    CustomerRequest request,
    SoapRequestContext requestContext
  ) {
    return stratioPort
      .getCustomerInfo(request, null, requestContext)
      .map(customer -> CustomerQueryStrategyPort.withDataSource(customer, DataSourceTypeEnum.STRATIO))
      .onErrorMap(e -> {
          if (e instanceof GlobalErrorException globalError) {
            return globalError;
          }
          return new GlobalErrorException("999", e.getMessage(), "STRATIO");
        }
      );
  }
}
