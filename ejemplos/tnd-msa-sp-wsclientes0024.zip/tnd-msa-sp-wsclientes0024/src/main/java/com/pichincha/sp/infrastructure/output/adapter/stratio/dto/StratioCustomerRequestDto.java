package com.pichincha.sp.infrastructure.output.adapter.stratio.dto;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JacksonXmlRootElement(localName = "Envelope", namespace = "http://schemas.xmlsoap.org/soap/envelope/")
public class StratioCustomerRequestDto {

    @JacksonXmlProperty(localName = "Header", namespace = "http://schemas.xmlsoap.org/soap/envelope/")
    private Header header;

    @JacksonXmlProperty(localName = "Body", namespace = "http://schemas.xmlsoap.org/soap/envelope/")
    private Body body;

    @Getter
    @Setter
    @Builder
    public static class Header {
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Body {
        @JacksonXmlProperty(localName = "CustomerRequest", namespace = "http://example.com/wsdl/ExampleService")
        private CustomerRequest customerRequest;
    }

    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CustomerRequest {
        @JacksonXmlProperty(localName = "IdentificationId")
        private String identificationId;

        @JacksonXmlProperty(localName = "IdentificationTypeId")
        private String identificationTypeId;
    }
}
