# Criterios de Aceptación — Servicio de Consulta de Clientes

Servicio encargado de consultar la información de un cliente a partir de su número de identificación.

---

## 1. Consulta exitosa de un cliente

**Dado que** un usuario necesita obtener la información de un cliente
**Cuando** envía una consulta con un número de identificación válido
**Entonces** el servicio debe devolver los datos completos del cliente junto con un mensaje indicando que la consulta fue exitosa

---

## 2. Consulta cuando la fuente principal no responde

**Dado que** la fuente principal de información no está disponible o presenta errores
**Cuando** el usuario realiza una consulta
**Entonces** el servicio debe intentar automáticamente obtener los datos desde la fuente alterna, sin que el usuario tenga que hacer algo adicional

---

## 3. Consulta cuando ninguna fuente responde

**Dado que** ambas fuentes de información están fuera de servicio
**Cuando** el usuario realiza una consulta
**Entonces** el servicio debe devolver una respuesta controlada con un mensaje de error claro, sin dejar al usuario sin respuesta

---

## 4. Identificación con ceros al inicio

**Dado que** un usuario envía una identificación que comienza con ceros y tiene más de 10 dígitos
**Cuando** el servicio procesa la solicitud
**Entonces** debe ajustar automáticamente la identificación para consultarla en el formato correcto, manteniendo la compatibilidad con el comportamiento anterior del servicio

---

## 5. Identificación vacía o no enviada

**Dado que** un usuario envía una consulta sin número de identificación
**Cuando** el servicio recibe la solicitud
**Entonces** debe responder con un mensaje indicando que la identificación es obligatoria, sin intentar consultar en ninguna fuente

---

## 6. Información de encabezado incompleta

**Dado que** un usuario envía una consulta con datos de encabezado faltantes o inválidos (como canal, usuario o dispositivo)
**Cuando** el servicio valida la solicitud
**Entonces** debe responder con un mensaje claro indicando qué dato falta o está mal, para que el usuario pueda corregirlo

---

## 7. Identificación de la fuente de los datos

**Dado que** el cliente puede estar registrado en una o ambas fuentes
**Cuando** se devuelve la información del cliente
**Entonces** la respuesta debe indicar claramente de qué fuente provienen los datos
