package com.pichincha.sp.infrastructure.exception;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

class GlobalErrorExceptionTest {

  @Test
  void shouldBuildErrorWithCodeMessageAndComponent() {
    GlobalErrorException exception =
        new GlobalErrorException("001", "failure", "WSClientes");

    assertThat(exception.getErrorCode()).isEqualTo("001");
    assertThat(exception.getMessage()).isEqualTo("failure");
    assertThat(exception.getComponent()).isEqualTo("WSClientes");
    assertThat(exception.getStatusCode())
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @Test
  void shouldBuildErrorWithCustomStatus() {
    GlobalErrorException exception =
        new GlobalErrorException("not-found", "WSClientes", HttpStatus.NOT_FOUND);

    assertThat(exception.getErrorCode()).isNull();
    assertThat(exception.getMessage()).isEqualTo("not-found");
    assertThat(exception.getComponent()).isEqualTo("WSClientes");
    assertThat(exception.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
  }

  @Test
  void shouldBuildErrorWithDefaultsAndCause() {
    RuntimeException cause = new RuntimeException("boom");

    GlobalErrorException withMessageOnly =
        new GlobalErrorException("generic");
    GlobalErrorException withCause =
        new GlobalErrorException("generic-cause", cause);
    GlobalErrorException withComponent =
        new GlobalErrorException("generic-component", "SOAP");

    assertThat(withMessageOnly.getComponent()).isEqualTo("UNKNOWN");
    assertThat(withMessageOnly.getErrorCode()).isNull();
    assertThat(withCause.getCause()).isEqualTo(cause);
    assertThat(withCause.getComponent()).isEqualTo("UNKNOWN");
    assertThat(withComponent.getComponent()).isEqualTo("SOAP");
  }
}
