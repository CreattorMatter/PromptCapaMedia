package com.pichincha.sp;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import org.junit.jupiter.api.Test;

class ApplicationTest {

  @Test
  void shouldStartApplicationMainWithTestProfile() {
    assertDoesNotThrow(() -> Application.main(new String[] {
        "--spring.profiles.active=test",
        "--spring.main.web-application-type=none",
        "--spring.main.lazy-initialization=true",
        "--spring.main.banner-mode=off",
        "--spring.main.register-shutdown-hook=false"
    }));
  }
}
