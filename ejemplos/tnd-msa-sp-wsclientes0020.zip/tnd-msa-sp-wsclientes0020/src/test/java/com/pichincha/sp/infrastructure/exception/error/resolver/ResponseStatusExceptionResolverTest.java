package com.pichincha.sp.infrastructure.exception.error.resolver;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultEnvelopeDto;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.ResponseStatusException;

class ResponseStatusExceptionResolverTest {

  @Test
  void shouldResolveResponseStatusExceptionToSoapFault() {
    ResponseStatusExceptionResolver resolver =
        new ResponseStatusExceptionResolver();
    MockServerWebExchange exchange =
        MockServerWebExchange.from(MockServerHttpRequest.get("/soap").build());
    ResponseStatusException exception =
        new ResponseStatusException(HttpStatus.NOT_FOUND, "not-found");

    SoapFaultEnvelopeDto response = resolver.apply(exchange, exception);

    assertEquals(HttpStatus.NOT_FOUND, exchange.getResponse().getStatusCode());
    assertNotNull(response.getBody());
    assertEquals("soapenv:Client", response.getBody().getFault().getFaultCode());
    assertEquals("Not Found", response.getBody().getFault().getFaultString());
    assertEquals("Detailed error information:not-found", response.getBody().getFault().getDetail());
  }

  @Test
  void shouldBuildBaseErrorModel() {
    ProblemDetail problemDetail = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "bad-request");
    problemDetail.setTitle("Bad Request");

    SoapFaultEnvelopeDto response =
        ResponseStatusExceptionResolver.buildBaseErrorModel(problemDetail);

    assertNotNull(response.getBody());
    assertEquals("Bad Request", response.getBody().getFault().getFaultString());
    assertEquals("Detailed error information:bad-request", response.getBody().getFault().getDetail());
  }
}
