package com.pichincha.sp.infrastructure.input.adapter.rest.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.pichincha.sp.application.input.port.UpdateTransactionalContactInputPort;
import com.pichincha.sp.application.util.ServiceLogHelper;
import com.pichincha.sp.domain.exception.BancsOperationException;
import com.pichincha.sp.domain.model.ContactOperationResult;
import com.pichincha.sp.domain.model.TransactionalContactRequest;
import com.pichincha.sp.generated.ActualizarContactoTransaccional31;
import com.pichincha.sp.generated.BancsTeller;
import com.pichincha.sp.generated.BodyInActualizarContactoTransaccional31;
import com.pichincha.sp.generated.Contacto;
import com.pichincha.sp.generated.DatosContacto;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.infrastructure.config.BancsErrorCodesProperties;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapBodyRequestDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapEnvelopeRequestDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.util.HeaderRequestValidator;
import com.pichincha.sp.infrastructure.soap.helper.SoapResponseHelper;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class WSClientes0020ControllerTest {

  @Mock
  private UpdateTransactionalContactInputPort updateService;

  @Mock
  private HeaderRequestValidator headerValidator;

  @Mock
  private ServiceLogHelper log;

  private SoapResponseHelper soapResponseHelper;
  private WSClientes0020Controller controller;

  @BeforeEach
  void setUp() {
    soapResponseHelper = new SoapResponseHelper(
        new BancsErrorCodesProperties("00638", "00045"));
    controller = new WSClientes0020Controller(
        updateService, headerValidator,
        soapResponseHelper, log);
  }

  @Test
  void shouldMapSoapRequestAndReturnSuccessEnvelope() {
    SoapEnvelopeRequestDto request = buildEnvelope("02");
    when(headerValidator.validate(any())).thenReturn(Optional.empty());
    when(updateService.updateTransactionalContact(any()))
        .thenReturn(Mono.just(ContactOperationResult.success()));

    StepVerifier.create(controller.actualizarContactoTransaccional31(request))
        .assertNext(xml -> {
          assertThat(xml).contains("<codigo>0</codigo>");
          assertThat(xml).contains("<mensaje>OK</mensaje>");
        })
        .verifyComplete();

    ArgumentCaptor<TransactionalContactRequest> requestCaptor =
        ArgumentCaptor.forClass(TransactionalContactRequest.class);
    verify(updateService).updateTransactionalContact(requestCaptor.capture());
    TransactionalContactRequest domainRequest = requestCaptor.getValue();

    assertThat(domainRequest.cif()).isEqualTo("399743");
    assertThat(domainRequest.contacts()).hasSize(1);
    assertThat(domainRequest.contacts().getFirst().type()).isEqualTo("1");
    assertThat(domainRequest.contacts().getFirst().email()).isEqualTo("test@bp.com");
    assertThat(domainRequest.headerContext().canal()).isEqualTo("02");
    assertThat(domainRequest.headerContext().bancs().teller()).isEqualTo("001");
  }

  @Test
  void shouldReturnBusinessErrorWhenHeaderValidationFails() {
    SoapEnvelopeRequestDto request = buildEnvelope("AA");
    when(headerValidator.validate(argThat(header -> header != null
        && "AA".equals(header.canal()))))
        .thenReturn(Optional.of("Campo canal contiene caracteres no permitidos"));

    StepVerifier.create(controller.actualizarContactoTransaccional31(request))
        .assertNext(xml -> {
          assertThat(xml).contains("<codigo>1</codigo>");
          assertThat(xml).contains("<tipo>FATAL</tipo>");
        })
        .verifyComplete();

    verifyNoInteractions(updateService);
  }

  @Test
  void shouldReturnHeaderValidationErrorWhenBancsBlockIsMissing() {
    SoapEnvelopeRequestDto request = buildEnvelopeWithoutBancs();
    when(headerValidator.validate(any()))
        .thenReturn(Optional.of(
            "Datos de la cabecera de la transaccion no se han asignado"));

    StepVerifier.create(controller.actualizarContactoTransaccional31(request))
        .assertNext(xml -> {
          assertThat(xml).contains("<codigo>1</codigo>");
          assertThat(xml).contains("<tipo>FATAL</tipo>");
        })
        .verifyComplete();

    verifyNoInteractions(updateService);
  }

  @Test
  void shouldReturnGenericErrorEnvelopeWhenServiceThrowsUnexpected() {
    SoapEnvelopeRequestDto request = buildEnvelope("02");
    when(headerValidator.validate(any())).thenReturn(Optional.empty());
    when(updateService.updateTransactionalContact(any()))
        .thenReturn(Mono.error(new RuntimeException("boom")));

    StepVerifier.create(controller.actualizarContactoTransaccional31(request))
        .assertNext(xml -> {
          assertThat(xml).contains("<codigo>999</codigo>");
          assertThat(xml).contains("<tipo>FATAL</tipo>");
        })
        .verifyComplete();
  }

  @Test
  void shouldReturnBancsErrorEnvelopeWhenServiceFails() {
    SoapEnvelopeRequestDto request = buildEnvelope("02");
    when(headerValidator.validate(any())).thenReturn(Optional.empty());
    when(updateService.updateTransactionalContact(any()))
        .thenReturn(Mono.error(new BancsOperationException("500", "BANCS timeout", "067186")));

    StepVerifier.create(controller.actualizarContactoTransaccional31(request))
        .assertNext(xml -> {
          assertThat(xml).contains("<codigo>500</codigo>");
          assertThat(xml).contains("<componente>067186</componente>");
        })
        .verifyComplete();
  }

  private SoapEnvelopeRequestDto buildEnvelope(String canal) {
    GenericHeaderIn header = new GenericHeaderIn();
    header.setDispositivo("device");
    header.setEmpresa("0010");
    header.setCanal(canal);
    header.setMedio("020002");
    header.setAplicacion("00270");
    header.setAgencia("123");
    header.setTipoTransaccion("304100111");
    header.setGeolocalizacion("Quito 123");
    header.setUsuario("USR001");
    header.setUnicidad("UZhDOa2GXtkAK2/QovFagnnS+nQSGAF/SKyTIIv1axc=");
    header.setGuid("550e8400-e29b-41d4-a716-446655440000");
    header.setFechaHora("20260410153000");
    header.setFiller("FILLER");
    header.setIdioma("es");
    header.setSesion("SESION01");
    header.setIp("192.168.1.1");
    header.setIdCliente("1711089364");
    header.setTipoIdCliente("CED");

    BancsTeller bancs = new BancsTeller();
    bancs.setTeller("001");
    bancs.setTerminal("002");
    bancs.setInstitucion("003");
    bancs.setAgencia("004");
    bancs.setEstacion("005");
    bancs.setAplicacion("006");
    bancs.setCanal("007");
    header.setBancs(bancs);

    Contacto contacto = new Contacto();
    contacto.setTipo("1");
    contacto.setEmail("test@bp.com");
    contacto.setCelular("0999999999");
    contacto.setActivar(true);

    DatosContacto datosContacto = new DatosContacto();
    datosContacto.getContactosTransaccionals().add(contacto);

    BodyInActualizarContactoTransaccional31 bodyIn =
        new BodyInActualizarContactoTransaccional31();
    bodyIn.setCif("399743");
    bodyIn.setContactosTransaccionales(datosContacto);

    ActualizarContactoTransaccional31 request =
        new ActualizarContactoTransaccional31();
    request.setHeaderIn(header);
    request.setBodyIn(bodyIn);

    SoapBodyRequestDto body = new SoapBodyRequestDto();
    body.setActualizarContactoTransaccional31(request);

    SoapEnvelopeRequestDto envelope = new SoapEnvelopeRequestDto();
    envelope.setBody(body);
    return envelope;
  }

  private SoapEnvelopeRequestDto buildEnvelopeWithoutBancs() {
    SoapEnvelopeRequestDto envelope = buildEnvelope("02");
    envelope.getBody().getActualizarContactoTransaccional31()
        .getHeaderIn().setBancs(null);
    return envelope;
  }
}
