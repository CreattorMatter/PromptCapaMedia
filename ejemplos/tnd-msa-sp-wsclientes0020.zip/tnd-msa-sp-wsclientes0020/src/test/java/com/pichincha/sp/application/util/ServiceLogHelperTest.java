package com.pichincha.sp.application.util;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevel;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ServiceLogHelperTest {

  @Mock
  private CustomLogLevelHandler logLevelHandler;

  @InjectMocks
  private ServiceLogHelper serviceLogHelper;

  @Test
  void shouldLogInfoLevel() {
    serviceLogHelper.info("info-message", "payload");

    verify(logLevelHandler).log(
        eq(CustomLogLevel.INFO),
        any(StackTraceElement[].class),
        eq("info-message"),
        any(Object[].class));
  }

  @Test
  void shouldLogDebugWarnAndErrorLevels() {
    serviceLogHelper.debug("debug-message", "a");
    serviceLogHelper.warn("warn-message", "b");
    serviceLogHelper.error("error-message", "c");

    verify(logLevelHandler).log(
        eq(CustomLogLevel.DEBUG),
        any(StackTraceElement[].class),
        eq("debug-message"),
        any(Object[].class));
    verify(logLevelHandler).log(
        eq(CustomLogLevel.WARN),
        any(StackTraceElement[].class),
        eq("warn-message"),
        any(Object[].class));
    verify(logLevelHandler).log(
        eq(CustomLogLevel.ERROR),
        any(StackTraceElement[].class),
        eq("error-message"),
        any(Object[].class));
  }
}
