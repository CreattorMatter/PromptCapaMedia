package com.pichincha.sp.infrastructure.exception.error.resolver.handler;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import com.pichincha.sp.infrastructure.exception.GlobalErrorException;
import com.pichincha.sp.infrastructure.exception.error.resolver.ErrorResolver;
import com.pichincha.sp.infrastructure.exception.error.resolver.GlobalErrorExceptionResolver;
import com.pichincha.sp.infrastructure.exception.error.resolver.UnexpectedErrorResolver;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import reactor.test.StepVerifier;

class ErrorResolverHandlerTest {

  @Test
  void shouldWriteSoapResponseUsingMappedResolver() {
    ErrorResolverHandler<Throwable> handler = new ErrorResolverHandler<>(
        mappedResolvers(),
        new UnexpectedErrorResolver(mock(CustomLogLevelHandler.class)));
    MockServerWebExchange exchange =
        MockServerWebExchange.from(MockServerHttpRequest.get("/soap").build());

    StepVerifier.create(handler.handle(
            exchange, new GlobalErrorException("001", "broken", "component")))
        .verifyComplete();

    String body = exchange.getResponse().getBodyAsString().block();

    assertEquals(MediaType.APPLICATION_XML, exchange.getResponse().getHeaders().getContentType());
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exchange.getResponse().getStatusCode());
    assertTrue(body.contains("Service exception"));
    assertTrue(body.contains("Detailed error information:broken"));
  }

  @Test
  void shouldFallbackToUnexpectedResolverWhenNoMappedResolverExists() {
    ErrorResolverHandler<Throwable> handler = new ErrorResolverHandler<>(
        Map.of(), new UnexpectedErrorResolver(mock(CustomLogLevelHandler.class)));
    MockServerWebExchange exchange =
        MockServerWebExchange.from(MockServerHttpRequest.get("/soap").build());

    StepVerifier.create(handler.handle(exchange, new IllegalArgumentException("boom")))
        .verifyComplete();

    String body = exchange.getResponse()
        .getBodyAsString()
        .map(value -> new String(value.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8))
        .block();

    assertEquals(MediaType.APPLICATION_XML, exchange.getResponse().getHeaders().getContentType());
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exchange.getResponse().getStatusCode());
    assertTrue(body.contains("Unexpected error"));
  }

  @SuppressWarnings("unchecked")
  private ErrorResolver<Throwable> cast(ErrorResolver<?> resolver) {
    return (ErrorResolver<Throwable>) resolver;
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  private Map<Class<Throwable>, ErrorResolver<Throwable>> mappedResolvers() {
    return (Map) Map.of(
        GlobalErrorException.class,
        new GlobalErrorExceptionResolver());
  }
}
