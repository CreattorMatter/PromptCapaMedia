package com.pichincha.sp.infrastructure.output.adapter.bancs.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.pichincha.bnc.apiclient.adapter.BancsClientAdapter;
import com.pichincha.bnc.apiclient.dto.response.BancsError;
import com.pichincha.bnc.apiclient.dto.response.BancsResponse;
import com.pichincha.sp.application.util.ServiceLogHelper;
import com.pichincha.sp.domain.exception.BancsOperationException;
import com.pichincha.sp.domain.model.ExistingContact;
import com.pichincha.sp.infrastructure.output.adapter.bancs.dto.response.Tx067186ResponseDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class ContactQueryBancsAdapterTest {

  @Mock
  private BancsClientAdapter bancsClient;

  @Mock
  private ServiceLogHelper log;

  @InjectMocks
  private ContactBancsAdapter adapter;

  @Test
  void shouldReturnUpdateOptionWhenContactExists() {
    Tx067186ResponseDto responseBody =
        new Tx067186ResponseDto("0987654321", "a@b.com", "00");
    when(bancsClient.call(any(), eq(Tx067186ResponseDto.class)))
        .thenReturn(Mono.just(
            new BancsResponse<>("067186", true, responseBody, null)));

    ExistingContact result =
        adapter.getExistingContact("0000000000399743", "1").block();

    assertThat(result.option()).isEqualTo("3");
    assertThat(result.email()).isEqualTo("a@b.com");
    assertThat(result.phone()).isEqualTo("0987654321");
  }

  @Test
  void shouldReturnInsertOptionWhenError0282() {
    when(bancsClient.call(any(), eq(Tx067186ResponseDto.class)))
        .thenReturn(Mono.just(new BancsResponse<>(
            "067186", false, null,
            new BancsError("0282", "Not found"))));

    ExistingContact result =
        adapter.getExistingContact("0000000000399743", "1").block();

    assertThat(result.option()).isEqualTo("1");
  }

  @Test
  void shouldReturnUpdateOptionWhenError1Inactive() {
    when(bancsClient.call(any(), eq(Tx067186ResponseDto.class)))
        .thenReturn(Mono.just(new BancsResponse<>(
            "067186", false, null,
            new BancsError("1", "Inactive"))));

    ExistingContact result =
        adapter.getExistingContact("0000000000399743", "1").block();

    assertThat(result.option()).isEqualTo("3");
  }

  @Test
  void shouldPropagateUnknownBancsError() {
    when(bancsClient.call(any(), eq(Tx067186ResponseDto.class)))
        .thenReturn(Mono.just(new BancsResponse<>(
            "067186", false, null,
            new BancsError("9999", "Unknown error"))));

    assertThatThrownBy(() ->
        adapter.getExistingContact("0000000000399743", "1").block())
        .isInstanceOf(BancsOperationException.class)
        .extracting("errorCode").isEqualTo("9999");
  }
}
