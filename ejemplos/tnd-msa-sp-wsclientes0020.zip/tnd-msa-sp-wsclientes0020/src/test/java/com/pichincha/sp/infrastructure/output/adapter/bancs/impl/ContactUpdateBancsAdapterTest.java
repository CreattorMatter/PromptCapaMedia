package com.pichincha.sp.infrastructure.output.adapter.bancs.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.bnc.apiclient.adapter.BancsClientAdapter;
import com.pichincha.bnc.apiclient.dto.request.BancsRequest;
import com.pichincha.bnc.apiclient.dto.response.BancsError;
import com.pichincha.bnc.apiclient.dto.response.BancsResponse;
import com.pichincha.sp.domain.exception.BancsOperationException;
import com.pichincha.sp.infrastructure.output.adapter.bancs.dto.request.Tx067186RequestDto;
import com.pichincha.sp.infrastructure.output.adapter.bancs.dto.response.Tx067186ResponseDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class ContactUpdateBancsAdapterTest {

  @Mock
  private BancsClientAdapter bancsClient;

  @InjectMocks
  private ContactBancsAdapter adapter;

  @Test
  void shouldCallBancsWithCorrectParameters() {
    when(bancsClient.call(any(), eq(Tx067186ResponseDto.class)))
        .thenReturn(Mono.just(
            new BancsResponse<>("067186", true, null, null)));

    adapter.updateContact(
        "0000000000399743", "1", "1",
        "test@mail.com", "0987654321", "00").block();

    ArgumentCaptor<BancsRequest<Tx067186RequestDto>> captor =
        ArgumentCaptor.forClass((Class) BancsRequest.class);
    verify(bancsClient).call(captor.capture(), eq(Tx067186ResponseDto.class));

    BancsRequest<Tx067186RequestDto> request = captor.getValue();
    assertThat(request.getTransactionId()).isEqualTo("067186");
    assertThat(request.getBody().customerNo()).isEqualTo("0000000000399743");
    assertThat(request.getBody().trxInstance()).isEqualTo("1");
    assertThat(request.getBody().option()).isEqualTo("1");
    assertThat(request.getBody().trxemail()).isEqualTo("test@mail.com");
    assertThat(request.getBody().trxcelular()).isEqualTo("0987654321");
    assertThat(request.getBody().trxestado()).isEqualTo("00");
  }

  @Test
  void shouldPropagateBancsError() {
    when(bancsClient.call(any(), eq(Tx067186ResponseDto.class)))
        .thenReturn(Mono.just(new BancsResponse<>(
            "067186", false, null,
            new BancsError("500", "BANCS error"))));

    assertThatThrownBy(() ->
        adapter.updateContact(
            "0000000000399743", "1", "3",
            "test@mail.com", "0987654321", "00").block())
        .isInstanceOf(BancsOperationException.class)
        .extracting("errorCode").isEqualTo("500");
  }
}
