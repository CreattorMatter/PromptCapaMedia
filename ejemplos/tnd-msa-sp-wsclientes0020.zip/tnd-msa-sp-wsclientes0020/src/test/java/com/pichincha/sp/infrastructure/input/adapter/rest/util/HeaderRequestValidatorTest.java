package com.pichincha.sp.infrastructure.input.adapter.rest.util;

import static org.assertj.core.api.Assertions.assertThat;

import com.pichincha.sp.domain.header.BancsRequestContext;
import com.pichincha.sp.domain.model.HeaderRequestModel;
import com.pichincha.sp.infrastructure.input.adapter.rest.config.HeaderValidationConfig;
import java.util.Map;
import org.junit.jupiter.api.Test;

class HeaderRequestValidatorTest {

  private final HeaderRequestValidator validator = buildValidator();

  private static BancsRequestContext bancsContext() {
    return new BancsRequestContext("001", "002", "003", "004", "005", "006", "007");
  }

  @Test
  void shouldReturnErrorWhenHeaderIsNull() {
    assertThat(validator.validate(null))
        .contains("Datos de la cabecera de la transaccion "
            + "no se han asignado");
  }

  @Test
  void shouldReturnEmptyWhenHeaderIsValid() {
    HeaderRequestModel header = HeaderRequestModel.builder()
        .dispositivo("Device_01")
        .empresa("0010")
        .canal("02")
        .medio("020002")
        .aplicacion("00270")
        .agencia("12345")
        .tipoTransaccion("304100111")
        .geolocalizacion("Quito 123")
        .usuario("USR001")
        .unicidad("UZhDOa2GXtkAK2/QovFagnnS+nQSGAF/SKyTIIv1axc=")
        .guid("550e8400-e29b-41d4-a716-446655440000")
        .fechaHora("20260410153000")
        .filler("FILLER")
        .idioma("es")
        .sesion("SESION-01")
        .ip("192.168.1.1")
        .idCliente("1711089364")
        .tipoIdCliente("CED")
        .bancs(bancsContext())
        .build();

    assertThat(validator.validate(header)).isEmpty();
  }

  @Test
  void shouldReturnBancsRequiredErrorWhenBancsBlockIsMissing() {
    HeaderRequestModel header = HeaderRequestModel.builder().build();

    assertThat(validator.validate(header))
        .contains("Datos de la cabecera de la transaccion "
            + "no se han asignado");
  }

  @Test
  void shouldReturnLengthErrorWhenFieldExceedsMaxLength() {
    HeaderRequestModel header = HeaderRequestModel.builder()
        .empresa("001000")
        .bancs(bancsContext())
        .build();

    assertThat(validator.validate(header))
        .contains("Campo empresa excede el maximo de 4 caracteres");
  }

  @Test
  void shouldReturnPatternErrorWhenFieldContainsInvalidCharacters() {
    HeaderRequestModel header = HeaderRequestModel.builder()
        .canal("A2")
        .bancs(bancsContext())
        .build();

    assertThat(validator.validate(header))
        .contains("Campo canal contiene caracteres no permitidos");
  }

  private HeaderRequestValidator buildValidator() {
    HeaderValidationConfig config = new HeaderValidationConfig();
    config.setPatterns(Map.of(
        "device", "^[A-Za-z0-9_]+$",
        "alphanumeric", "^[A-Za-z0-9]+$",
        "digits-only", "^\\d+$",
        "alphanumeric-extended", "^[A-Za-z0-9+/=_ .:-]+$",
        "base64", "^[A-Za-z0-9+/=]+$",
        "alphanumeric-dash", "^[A-Za-z0-9-]+$"));
    config.setMaxLengths(Map.of(
        "empresa", 4,
        "canal", 2));
    return new HeaderRequestValidator(config);
  }
}
