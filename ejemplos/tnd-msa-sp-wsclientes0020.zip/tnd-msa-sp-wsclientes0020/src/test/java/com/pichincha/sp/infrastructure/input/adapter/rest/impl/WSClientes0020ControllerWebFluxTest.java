package com.pichincha.sp.infrastructure.input.adapter.rest.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.pichincha.sp.application.input.port.UpdateTransactionalContactInputPort;
import com.pichincha.sp.application.util.ServiceLogHelper;
import com.pichincha.sp.domain.exception.BancsOperationException;
import com.pichincha.sp.domain.model.ContactOperationResult;
import com.pichincha.sp.generated.ActualizarContactoTransaccional31;
import com.pichincha.sp.generated.BodyInActualizarContactoTransaccional31;
import com.pichincha.sp.generated.Contacto;
import com.pichincha.sp.generated.DatosContacto;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.infrastructure.config.BancsErrorCodesProperties;
import com.pichincha.sp.infrastructure.exception.error.resolver.UnexpectedErrorResolver;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapBodyRequestDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapEnvelopeRequestDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.util.HeaderRequestValidator;
import com.pichincha.sp.infrastructure.soap.helper.SoapResponseHelper;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

@ActiveProfiles("test")
@WebFluxTest(controllers = WSClientes0020Controller.class)
@AutoConfigureWebTestClient
@Import({UnexpectedErrorResolver.class,
    WSClientes0020ControllerWebFluxTest.TestConfig.class})
class WSClientes0020ControllerWebFluxTest {

  @TestConfiguration
  static class TestConfig {
    @Bean
    BancsErrorCodesProperties bancsErrorCodesProperties() {
      return new BancsErrorCodesProperties("00638", "00045");
    }

    @Bean
    SoapResponseHelper soapResponseHelper(
        BancsErrorCodesProperties props) {
      return new SoapResponseHelper(props);
    }
  }

  @Autowired
  private WebTestClient webTestClient;

  @MockitoBean
  private UpdateTransactionalContactInputPort updateService;

  @MockitoBean
  private HeaderRequestValidator headerValidator;

  @MockitoBean
  private ServiceLogHelper log;

  @MockitoBean
  private com.pichincha.common.trace.logger.logger.custom.level
      .CustomLogLevelHandler customLogLevelHandler;

  @Test
  void shouldReturnSoapSuccessResponse() {
    when(headerValidator.validate(any())).thenReturn(Optional.empty());
    when(updateService.updateTransactionalContact(any()))
        .thenReturn(Mono.just(ContactOperationResult.success()));

    webTestClient.post()
        .uri("/IntegrationBus/soap/WSClientes0020")
        .contentType(MediaType.APPLICATION_XML)
        .bodyValue(validSoapRequest())
        .exchange()
        .expectStatus().isOk()
        .expectBody(String.class)
        .value(body -> {
          org.assertj.core.api.Assertions.assertThat(body)
              .contains("ActualizarContactoTransaccional31Response");
          org.assertj.core.api.Assertions.assertThat(body)
              .contains("<codigo>0</codigo>");
          org.assertj.core.api.Assertions.assertThat(body)
              .contains("<mensaje>OK</mensaje>");
        });
  }

  @Test
  void shouldReturnSoapErrorWhenServiceThrowsBancsException() {
    when(headerValidator.validate(any())).thenReturn(Optional.empty());
    when(updateService.updateTransactionalContact(any()))
        .thenReturn(Mono.error(new BancsOperationException("500", "BANCS timeout", "067186")));

    webTestClient.post()
        .uri("/IntegrationBus/soap/WSClientes0020")
        .contentType(MediaType.APPLICATION_XML)
        .bodyValue(validSoapRequest())
        .exchange()
        .expectStatus().isOk()
        .expectBody(String.class)
        .value(body -> {
          org.assertj.core.api.Assertions.assertThat(body)
              .contains("<codigo>500</codigo>");
          org.assertj.core.api.Assertions.assertThat(body)
              .contains("<componente>067186</componente>");
        });
  }

  private SoapEnvelopeRequestDto validSoapRequest() {
    GenericHeaderIn header = new GenericHeaderIn();
    header.setDispositivo("device");
    header.setEmpresa("0010");
    header.setCanal("02");
    header.setMedio("020002");
    header.setAplicacion("00270");
    header.setAgencia("123");
    header.setTipoTransaccion("304100111");
    header.setGeolocalizacion("Quito 123");
    header.setUsuario("USR001");
    header.setUnicidad("UZhDOa2GXtkAK2/QovFagnnS+nQSGAF/SKyTIIv1axc=");
    header.setGuid("550e8400-e29b-41d4-a716-446655440000");
    header.setFechaHora("20260410153000");
    header.setFiller("FILLER");
    header.setIdioma("es");
    header.setSesion("SESION01");
    header.setIp("192.168.1.1");
    header.setIdCliente("1711089364");
    header.setTipoIdCliente("CED");

    Contacto contacto = new Contacto();
    contacto.setTipo("1");
    contacto.setEmail("test@bp.com");
    contacto.setCelular("0999999999");
    contacto.setActivar(true);

    DatosContacto datosContacto = new DatosContacto();
    datosContacto.getContactosTransaccionals().add(contacto);

    BodyInActualizarContactoTransaccional31 bodyIn =
        new BodyInActualizarContactoTransaccional31();
    bodyIn.setCif("399743");
    bodyIn.setContactosTransaccionales(datosContacto);

    ActualizarContactoTransaccional31 request =
        new ActualizarContactoTransaccional31();
    request.setHeaderIn(header);
    request.setBodyIn(bodyIn);

    SoapBodyRequestDto body = new SoapBodyRequestDto();
    body.setActualizarContactoTransaccional31(request);

    SoapEnvelopeRequestDto envelope = new SoapEnvelopeRequestDto();
    envelope.setBody(body);
    return envelope;
  }
}
