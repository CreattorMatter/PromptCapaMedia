package com.pichincha.sp.domain.enums;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ErrorSeverityTest {

  @Test
  void shouldExposeExpectedEnumValues() {
    ErrorSeverity[] values = ErrorSeverity.values();

    assertEquals(3, values.length);
    assertEquals(ErrorSeverity.CLIENT_ERROR, ErrorSeverity.valueOf("CLIENT_ERROR"));
    assertEquals(ErrorSeverity.SERVER_ERROR, ErrorSeverity.valueOf("SERVER_ERROR"));
    assertEquals(ErrorSeverity.BUSINESS_ERROR, ErrorSeverity.valueOf("BUSINESS_ERROR"));
  }
}
