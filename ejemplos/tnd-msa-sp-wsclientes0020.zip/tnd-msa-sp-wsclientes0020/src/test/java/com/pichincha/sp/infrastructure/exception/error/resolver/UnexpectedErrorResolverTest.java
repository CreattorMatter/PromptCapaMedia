package com.pichincha.sp.infrastructure.exception.error.resolver;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import static org.mockito.Mockito.mock;

import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultEnvelopeDto;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;

class UnexpectedErrorResolverTest {

  @Test
  void shouldResolveUnexpectedErrorToSoapFault() {
    UnexpectedErrorResolver resolver =
        new UnexpectedErrorResolver(mock(CustomLogLevelHandler.class));
    MockServerWebExchange exchange =
        MockServerWebExchange.from(MockServerHttpRequest.get("/soap").build());

    SoapFaultEnvelopeDto response =
        resolver.apply(exchange, new RuntimeException("boom"));

    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exchange.getResponse().getStatusCode());
    assertNotNull(response.getBody());
    assertEquals("soapenv:Client", response.getBody().getFault().getFaultCode());
    assertEquals("Unexpected error", response.getBody().getFault().getFaultString());
    assertEquals(
        "Detailed error information: An unexpected error has occurred",
        response.getBody().getFault().getDetail());
  }
}
