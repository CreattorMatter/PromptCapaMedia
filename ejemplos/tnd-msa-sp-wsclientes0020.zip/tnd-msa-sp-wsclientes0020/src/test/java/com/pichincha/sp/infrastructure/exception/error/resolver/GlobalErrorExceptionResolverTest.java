package com.pichincha.sp.infrastructure.exception.error.resolver;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.pichincha.sp.infrastructure.exception.GlobalErrorException;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultEnvelopeDto;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;

class GlobalErrorExceptionResolverTest {

  @Test
  void shouldResolveGlobalErrorToSoapFault() {
    GlobalErrorExceptionResolver resolver =
        new GlobalErrorExceptionResolver();
    MockServerWebExchange exchange =
        MockServerWebExchange.from(MockServerHttpRequest.get("/soap").build());
    GlobalErrorException exception =
        new GlobalErrorException("001", "broken", "component");

    SoapFaultEnvelopeDto response = resolver.apply(exchange, exception);

    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exchange.getResponse().getStatusCode());
    assertNotNull(response.getBody());
    assertEquals("soapenv:Client", response.getBody().getFault().getFaultCode());
    assertEquals("Service exception", response.getBody().getFault().getFaultString());
    assertEquals("Detailed error information:broken", response.getBody().getFault().getDetail());
  }
}
