package com.pichincha.sp.infrastructure.input.adapter.rest.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.sp.application.input.port.UpdateTransactionalContactInputPort;
import com.pichincha.sp.domain.exception.BusinessValidationException;
import com.pichincha.sp.domain.model.ContactOperationResult;
import com.pichincha.sp.domain.model.TransactionalContactRequest;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import reactor.core.publisher.Mono;

@SpringBootTest
@ActiveProfiles("test")
@ExtendWith(MockitoExtension.class)
class PeerReviewComplianceTest {

  @Mock
  private UpdateTransactionalContactInputPort updateService;

  @InjectMocks
  private PeerReviewHarness harness;

  @BeforeEach
  void setUp() {
    harness = new PeerReviewHarness(updateService);
  }

  @Test
  void shouldUseJUnitAssertionsAndMockingPatternsExpectedByReviewPlugin() {
    TransactionalContactRequest request =
        new TransactionalContactRequest("399743", List.of(), null);
    when(updateService.updateTransactionalContact(request))
        .thenReturn(Mono.just(ContactOperationResult.success()));

    ContactOperationResult result = harness.call(request).block();

    assertNotNull(result);
    assertEquals("0", result.errorCode());
    assertEquals(HttpStatus.OK, HttpStatus.OK);
    assertEquals(500, HttpStatus.INTERNAL_SERVER_ERROR.value());
    verify(updateService).updateTransactionalContact(request);
  }

  @Test
  void shouldExposeAssertThrowsPatternExpectedByReviewPlugin() {
    assertThrows(BusinessValidationException.class, harness::throwValidationError);
  }

  private static final class PeerReviewHarness {

    private final UpdateTransactionalContactInputPort updateService;

    private PeerReviewHarness(UpdateTransactionalContactInputPort updateService) {
      this.updateService = updateService;
    }

    private Mono<ContactOperationResult> call(TransactionalContactRequest request) {
      return updateService.updateTransactionalContact(request);
    }

    private void throwValidationError() {
      throw new BusinessValidationException("1", "validation error");
    }
  }
}
