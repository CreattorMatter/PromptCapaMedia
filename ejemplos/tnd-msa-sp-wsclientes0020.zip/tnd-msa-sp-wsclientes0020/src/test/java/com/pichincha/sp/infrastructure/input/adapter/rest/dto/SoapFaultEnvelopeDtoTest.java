package com.pichincha.sp.infrastructure.input.adapter.rest.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

class SoapFaultEnvelopeDtoTest {

  @Test
  void shouldBuildEnvelopeWithFault() {
    SoapFaultDto fault = SoapFaultDto.builder()
        .faultCode("soapenv:Client")
        .faultString("Failure")
        .detail("detail")
        .build();

    SoapFaultEnvelopeDto envelope = SoapFaultEnvelopeDto.withFault(fault);

    assertNotNull(envelope.getBody());
    assertNotNull(envelope.getBody().getFault());
    assertEquals("Failure", envelope.getBody().getFault().getFaultString());
  }
}
