package com.pichincha.sp.infrastructure.soap.helper;

import static org.assertj.core.api.Assertions.assertThat;

import com.pichincha.sp.infrastructure.config.BancsErrorCodesProperties;
import com.pichincha.sp.infrastructure.exception.ErrorCatalogConstants;
import com.pichincha.sp.generated.BancsTeller;
import com.pichincha.sp.generated.GenericError;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.generated.GenericHeaderOut;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SoapResponseHelperTest {

  private SoapResponseHelper helper;

  @BeforeEach
  void setUp() {
    helper = new SoapResponseHelper(
        new BancsErrorCodesProperties("00638", "00045"));
  }

  @Test
  void shouldCreateHeaderOutWithDocumentWhenHeaderIsNull() {
    GenericHeaderOut headerOut =
        SoapResponseHelper.buildHeaderOut(null);

    assertThat(headerOut).isNotNull();
    assertThat(headerOut.getDocumento()).isNotNull();
    assertThat(headerOut.getCanal()).isNull();
  }

  @Test
  void shouldBuildDocumentWithFullRequiredStructure() {
    GenericHeaderOut headerOut =
        SoapResponseHelper.buildHeaderOut(null);

    assertThat(headerOut.getDocumento()).isNotNull();
    assertThat(headerOut.getDocumento().getFechaContable())
        .isEqualTo("");
    assertThat(headerOut.getDocumento().getNumeroDocumento())
        .isEqualTo("");
    assertThat(headerOut.getDocumento().getJournals()).isNotNull();
    assertThat(headerOut.getDocumento().getJournals().getJournals())
        .hasSize(1);
    assertThat(headerOut.getDocumento().getJournals().getJournals()
        .get(0).getValor()).isEqualTo("");
  }

  @Test
  void shouldCopyHeaderFieldsToHeaderOut() {
    GenericHeaderIn headerIn = new GenericHeaderIn();
    headerIn.setDispositivo("device");
    headerIn.setEmpresa("0010");
    headerIn.setCanal("02");
    headerIn.setUsuario("USR001");
    headerIn.setGuid("550e8400-e29b-41d4-a716-446655440000");

    GenericHeaderOut headerOut =
        SoapResponseHelper.buildHeaderOut(headerIn);

    assertThat(headerOut.getDispositivo()).isEqualTo("device");
    assertThat(headerOut.getEmpresa()).isEqualTo("0010");
    assertThat(headerOut.getCanal()).isEqualTo("02");
    assertThat(headerOut.getUsuario()).isEqualTo("USR001");
    assertThat(headerOut.getGuid())
        .isEqualTo("550e8400-e29b-41d4-a716-446655440000");
  }

  @Test
  void shouldNotEchoBancsSectionInHeaderOutWhenPresentInRequest() {
    GenericHeaderIn headerIn = new GenericHeaderIn();
    BancsTeller bancs = new BancsTeller();
    bancs.setTeller("001");
    bancs.setTerminal("002");
    bancs.setInstitucion("003");
    bancs.setAgencia("004");
    bancs.setEstacion("005");
    bancs.setAplicacion("006");
    bancs.setCanal("007");
    headerIn.setBancs(bancs);

    GenericHeaderOut headerOut =
        SoapResponseHelper.buildHeaderOut(headerIn);

    assertThat(headerOut.getBancs()).isNull();
  }

  @Test
  void givenSuccess_whenBuild_thenInfoTypeAndIibBackend() {
    GenericError error = helper.buildSuccessError(
        "0", "OK", "OK");

    assertThat(error.getCodigo()).isEqualTo("0");
    assertThat(error.getTipo())
        .isEqualTo(ErrorCatalogConstants.ERROR_TYPE_INFO);
    assertThat(error.getBackend()).isEqualTo("00638");
    assertThat(error.getComponente())
        .isEqualTo(ErrorCatalogConstants.WS_COMPONENTE);
  }

  @Test
  void givenBusinessError_whenBuild_thenErrorTypeAndIibBackend() {
    GenericError error = helper.buildBusinessError(
        "1", "Validacion fallida", "Validacion fallida");

    assertThat(error.getTipo())
        .isEqualTo(ErrorCatalogConstants.ERROR_TYPE_ERROR);
    assertThat(error.getBackend()).isEqualTo("00638");
  }

  @Test
  void givenFatal_whenBuild_thenFatalTypeAndIibBackend() {
    GenericError error = helper.buildFatalError(
        "999", "Error interno");

    assertThat(error.getTipo())
        .isEqualTo(ErrorCatalogConstants.ERROR_TYPE_FATAL);
    assertThat(error.getBackend()).isEqualTo("00638");
  }

  @Test
  void givenBancsError_whenBuild_thenFatalTypeAndBancsBackend() {
    GenericError error = helper.buildBancsError(
        "500", "TX failed", "067186");

    assertThat(error.getTipo())
        .isEqualTo(ErrorCatalogConstants.ERROR_TYPE_FATAL);
    assertThat(error.getBackend()).isEqualTo("00045");
    assertThat(error.getComponente()).isEqualTo("067186");
  }
}
