package com.pichincha.sp.application.util;

import static org.assertj.core.api.Assertions.assertThat;

import com.pichincha.sp.domain.model.PhoneNormalizationConfig;
import org.junit.jupiter.api.Test;

class PhoneNormalizationUtilTest {

  @Test
  void shouldReplaceConfiguredPrefixWhenPhoneExceedsInternationalLength() {
    PhoneNormalizationConfig config =
        new PhoneNormalizationConfig(10, "5930", "593");

    assertThat(PhoneNormalizationUtil.normalize("593012345678", config))
        .isEqualTo("59312345678");
  }

  @Test
  void shouldKeepOriginalPhoneWhenNoReplacementIsNeeded() {
    PhoneNormalizationConfig config =
        new PhoneNormalizationConfig(10, "5930", "593");

    assertThat(PhoneNormalizationUtil.normalize("0991234567", config))
        .isEqualTo("0991234567");
  }
}
