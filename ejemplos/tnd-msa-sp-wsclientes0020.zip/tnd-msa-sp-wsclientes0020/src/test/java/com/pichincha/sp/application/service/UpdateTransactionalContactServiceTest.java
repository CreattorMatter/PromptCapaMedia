package com.pichincha.sp.application.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.pichincha.sp.application.output.port.ContactBancsOutputPort;
import com.pichincha.sp.application.util.ServiceLogHelper;
import com.pichincha.sp.domain.exception.BancsOperationException;
import com.pichincha.sp.domain.exception.BusinessValidationException;
import com.pichincha.sp.domain.model.ExistingContact;
import com.pichincha.sp.domain.model.TransactionalContact;
import com.pichincha.sp.domain.model.TransactionalContactRequest;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class UpdateTransactionalContactServiceTest {

  @Mock
  private ServiceLogHelper log;

  @Mock
  private ContactBancsOutputPort bancsPort;

  @InjectMocks
  private UpdateTransactionalContactService service;

  @BeforeEach
  void setUp() {
    ReflectionTestUtils.setField(service, "phoneInternationalLength", 12);
    ReflectionTestUtils.setField(service, "phonePrefixExclude", "5930");
    ReflectionTestUtils.setField(service, "phonePrefixReplace", "593");
  }

  @Test
  void givenValidRequest_whenActivateNew_thenSuccess() {
    var contact = new TransactionalContact("1", "a@b.com", "099", true);
    var request = new TransactionalContactRequest("399743", List.of(contact), null);

    when(bancsPort.getExistingContact(any(), eq("1")))
        .thenReturn(Mono.just(new ExistingContact("1", "", "")));
    when(bancsPort.updateContact(any(), any(), any(), any(), any(), any()))
        .thenReturn(Mono.empty());

    StepVerifier.create(service.updateTransactionalContact(request))
        .expectNextMatches(result -> "0".equals(result.errorCode()))
        .verifyComplete();
  }

  @Test
  void givenExisting_whenSelectiveUpdate_thenOnlyChanged() {
    var contact = new TransactionalContact("1", "new@b.com", "", true);
    var request = new TransactionalContactRequest("399743", List.of(contact), null);

    when(bancsPort.getExistingContact(any(), eq("1")))
        .thenReturn(Mono.just(new ExistingContact("3", "old@b.com", "099")));
    when(bancsPort.updateContact(any(), any(), any(), any(), any(), any()))
        .thenReturn(Mono.empty());

    StepVerifier.create(service.updateTransactionalContact(request))
        .expectNextMatches(result -> "0".equals(result.errorCode()))
        .verifyComplete();

    verify(bancsPort).updateContact(any(), any(), eq("3"), eq("new@b.com"), eq(""), eq("00"));
  }

  @Test
  void givenNoChanges_whenUpdate_thenSkips() {
    var contact = new TransactionalContact("1", "same@b.com", "099", true);
    var request = new TransactionalContactRequest("399743", List.of(contact), null);

    when(bancsPort.getExistingContact(any(), eq("1")))
        .thenReturn(Mono.just(new ExistingContact("3", "same@b.com", "099")));

    StepVerifier.create(service.updateTransactionalContact(request))
        .expectNextMatches(result -> "0".equals(result.errorCode()))
        .verifyComplete();

    verify(bancsPort, never()).updateContact(any(), any(), any(), any(), any(), any());
  }

  @Test
  void givenEmptyCif_whenUpdate_thenError1() {
    var contact = new TransactionalContact("1", "a@b.com", "099", true);
    var request = new TransactionalContactRequest("", List.of(contact), null);

    assertThatThrownBy(() -> service.updateTransactionalContact(request))
        .isInstanceOf(BusinessValidationException.class)
        .extracting("errorCode").isEqualTo("1");
  }

  @Test
  void givenActivateEmptyFields_whenUpdate_thenError4() {
    var contact = new TransactionalContact("1", "", "", true);
    var request = new TransactionalContactRequest("399743", List.of(contact), null);

    when(bancsPort.getExistingContact(any(), eq("1")))
        .thenReturn(Mono.just(new ExistingContact("1", "", "")));
    StepVerifier.create(service.updateTransactionalContact(request))
        .expectErrorMatches(e ->
            e instanceof BusinessValidationException bve && "4".equals(bve.getErrorCode()))
        .verify();
  }

  @Test
  void givenDeactivateNonExisting_whenUpdate_thenError3() {
    var contact = new TransactionalContact("2", "", "", false);
    var request = new TransactionalContactRequest("399743", List.of(contact), null);

    when(bancsPort.getExistingContact(any(), eq("2")))
        .thenReturn(Mono.just(new ExistingContact("1", "", "")));

    StepVerifier.create(service.updateTransactionalContact(request))
        .expectErrorMatches(e ->
            e instanceof BusinessValidationException bve && "3".equals(bve.getErrorCode()))
        .verify();
  }

  @Test
  void givenDeactivateExisting_whenUpdate_thenInactive() {
    var contact = new TransactionalContact("1", "", "", false);
    var request = new TransactionalContactRequest("399743", List.of(contact), null);

    when(bancsPort.getExistingContact(any(), eq("1")))
        .thenReturn(Mono.just(new ExistingContact("3", "old@b.com", "099")));
    when(bancsPort.updateContact(any(), any(), any(), any(), any(), any()))
        .thenReturn(Mono.empty());

    StepVerifier.create(service.updateTransactionalContact(request))
        .expectNextMatches(result -> "0".equals(result.errorCode()))
        .verifyComplete();

    verify(bancsPort).updateContact(any(), any(), eq("3"), eq(""), eq(""), eq("99"));
  }

  @Test
  void givenBancsError_whenQuery_thenPropagates() {
    var contact = new TransactionalContact("1", "a@b.com", "099", true);
    var request = new TransactionalContactRequest("399743", List.of(contact), null);

    when(bancsPort.getExistingContact(any(), eq("1")))
        .thenReturn(Mono.error(new BancsOperationException("999", "timeout", "067186")));

    StepVerifier.create(service.updateTransactionalContact(request))
        .expectErrorMatches(e ->
            e instanceof BancsOperationException boe && "999".equals(boe.getErrorCode()))
        .verify();
  }

  @Test
  void givenPhone5930_whenNormalize_thenReplaces593() {
    var contact = new TransactionalContact("1", "a@b.com", "59301234567890", true);
    var request = new TransactionalContactRequest("399743", List.of(contact), null);

    when(bancsPort.getExistingContact(any(), eq("1")))
        .thenReturn(Mono.just(new ExistingContact("1", "", "")));
    when(bancsPort.updateContact(any(), any(), any(), any(), any(), any()))
        .thenReturn(Mono.empty());

    StepVerifier.create(service.updateTransactionalContact(request))
        .expectNextMatches(result -> "0".equals(result.errorCode()))
        .verifyComplete();

    verify(bancsPort).updateContact(any(), any(), any(), any(), eq("5931234567890"), any());
  }

  @Test
  void givenEmailEscapeChars_whenNormalize_thenTrims() {
    var contact = new TransactionalContact("1", "\ttest@b.com\r\n", "099", true);
    var request = new TransactionalContactRequest("399743", List.of(contact), null);

    when(bancsPort.getExistingContact(any(), eq("1")))
        .thenReturn(Mono.just(new ExistingContact("1", "", "")));
    when(bancsPort.updateContact(any(), any(), any(), any(), any(), any()))
        .thenReturn(Mono.empty());

    StepVerifier.create(service.updateTransactionalContact(request))
        .expectNextMatches(result -> "0".equals(result.errorCode()))
        .verifyComplete();

    verify(bancsPort).updateContact(any(), any(), any(), eq("test@b.com"), any(), any());
  }
}
