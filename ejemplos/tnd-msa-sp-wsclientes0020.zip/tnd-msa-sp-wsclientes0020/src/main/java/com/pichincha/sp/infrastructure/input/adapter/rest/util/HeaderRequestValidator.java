package com.pichincha.sp.infrastructure.input.adapter.rest.util;

import com.pichincha.sp.domain.model.HeaderRequestModel;
import com.pichincha.sp.infrastructure.input.adapter.rest.config.HeaderValidationConfig;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class HeaderRequestValidator {

  private static final String PATTERN_ALPHANUMERIC = "alphanumeric";
  private static final String PATTERN_DIGITS_ONLY = "digits-only";
  private static final String PATTERN_ALPHANUMERIC_EXTENDED =
      "alphanumeric-extended";

  private final HeaderValidationConfig config;
  private final Map<String, Pattern> compiledPatterns =
      new ConcurrentHashMap<>();

  private static final String HEADER_NOT_ASSIGNED =
      "Datos de la cabecera de la transaccion no se han asignado";

  public Optional<String> validate(HeaderRequestModel header) {
    if (header == null) {
      return Optional.of(HEADER_NOT_ASSIGNED);
    }
    if (header.bancs() == null) {
      return Optional.of(HEADER_NOT_ASSIGNED);
    }
    return check(header.dispositivo(), "dispositivo", "device")
        .or(() -> check(header.empresa(), "empresa", PATTERN_ALPHANUMERIC))
        .or(() -> check(header.canal(), "canal", PATTERN_DIGITS_ONLY))
        .or(() -> check(header.medio(), "medio", PATTERN_DIGITS_ONLY))
        .or(() -> check(header.aplicacion(), "aplicacion", PATTERN_DIGITS_ONLY))
        .or(() -> check(header.agencia(), "agencia", PATTERN_DIGITS_ONLY))
        .or(() -> check(header.tipoTransaccion(), "tipo-transaccion", PATTERN_DIGITS_ONLY))
        .or(() -> check(header.geolocalizacion(), "geolocalizacion",
            PATTERN_ALPHANUMERIC_EXTENDED))
        .or(() -> check(header.usuario(), "usuario", PATTERN_ALPHANUMERIC))
        .or(() -> check(header.unicidad(), "unicidad", "base64"))
        .or(() -> check(header.guid(), "guid", "alphanumeric-dash"))
        .or(() -> check(header.fechaHora(), "fecha-hora",
            PATTERN_ALPHANUMERIC_EXTENDED))
        .or(() -> check(header.filler(), "filler",
            PATTERN_ALPHANUMERIC_EXTENDED))
        .or(() -> check(header.idioma(), "idioma", "alphanumeric-dash"))
        .or(() -> check(header.sesion(), "sesion",
            PATTERN_ALPHANUMERIC_EXTENDED))
        .or(() -> check(header.ip(), "ip", PATTERN_ALPHANUMERIC_EXTENDED))
        .or(() -> check(header.idCliente(), "id-cliente", PATTERN_DIGITS_ONLY))
        .or(() -> check(header.tipoIdCliente(), "tipo-id-cliente",
            PATTERN_ALPHANUMERIC));
  }

  private Optional<String> check(
      String value, String fieldKey, String patternKey) {
    if (value == null || value.isEmpty()) {
      return Optional.empty();
    }
    int maxLength = config.getMaxLengths()
        .getOrDefault(fieldKey, Integer.MAX_VALUE);
    if (value.length() > maxLength) {
      return Optional.of(
          "Campo " + fieldKey + " excede el maximo de "
              + maxLength + " caracteres");
    }
    String regex = config.getPatterns().get(patternKey);
    if (regex != null) {
      Pattern pattern = compiledPatterns.computeIfAbsent(
          patternKey, k -> Pattern.compile(regex));
      if (!pattern.matcher(value).matches()) {
        return Optional.of(
            "Campo " + fieldKey
                + " contiene caracteres no permitidos");
      }
    }
    return Optional.empty();
  }
}
