package com.pichincha.sp.infrastructure.output.adapter.bancs.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;

@Builder
public record Tx067186RequestDto(
    @JsonProperty("instNo") String instNo,
    @JsonProperty("customerNo") String customerNo,
    @JsonProperty("option") String option,
    @JsonProperty("trxType") String trxType,
    @JsonProperty("trxInstance") String trxInstance,
    @JsonProperty("trxCelular") String trxcelular,
    @JsonProperty("trxEmail") String trxemail,
    @JsonProperty("trxEstado") String trxestado) {
}
