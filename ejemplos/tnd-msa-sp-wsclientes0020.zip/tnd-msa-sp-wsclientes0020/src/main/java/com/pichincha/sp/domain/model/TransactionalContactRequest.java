package com.pichincha.sp.domain.model;

import java.util.List;

public record TransactionalContactRequest(
    String cif,
    List<TransactionalContact> contacts,
    HeaderRequestModel headerContext) {
}
