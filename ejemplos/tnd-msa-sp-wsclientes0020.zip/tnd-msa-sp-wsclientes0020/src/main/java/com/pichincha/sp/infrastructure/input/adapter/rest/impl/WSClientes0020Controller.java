package com.pichincha.sp.infrastructure.input.adapter.rest.impl;

import com.pichincha.common.trace.logger.annotation.BpTraceable;
import com.pichincha.sp.application.input.port.UpdateTransactionalContactInputPort;
import com.pichincha.sp.infrastructure.input.adapter.rest.util.HeaderRequestValidator;
import com.pichincha.sp.domain.exception.BancsOperationException;
import com.pichincha.sp.domain.exception.BusinessValidationException;
import com.pichincha.sp.domain.header.BancsRequestContext;
import com.pichincha.sp.domain.model.HeaderRequestModel;
import com.pichincha.sp.domain.model.TransactionalContact;
import com.pichincha.sp.domain.model.TransactionalContactRequest;
import com.pichincha.sp.generated.ActualizarContactoTransaccional31;
import com.pichincha.sp.generated.ActualizarContactoTransaccional31Response;
import com.pichincha.sp.generated.BancsTeller;
import com.pichincha.sp.generated.Contacto;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.generated.GenericError;
import com.pichincha.sp.generated.GenericHeaderOut;
import com.pichincha.sp.application.util.ServiceLogHelper;
import com.pichincha.sp.infrastructure.exception.ErrorCatalogConstants;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapBodyResponseDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapEnvelopeRequestDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapEnvelopeResponseDto;
import com.pichincha.sp.infrastructure.soap.helper.SoapResponseHelper;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
@RequestMapping("/IntegrationBus/soap/WSClientes0020")
public class WSClientes0020Controller {

  private final UpdateTransactionalContactInputPort updateService;
  private final HeaderRequestValidator headerValidator;
  private final SoapResponseHelper soapResponseHelper;
  private final ServiceLogHelper log;

  @PostMapping(
      consumes = {
          MediaType.TEXT_XML_VALUE,
          MediaType.TEXT_XML_VALUE + ";charset=utf-8",
          MediaType.APPLICATION_XML_VALUE,
          "application/soap+xml"
      },
      produces = {
          MediaType.TEXT_XML_VALUE + ";charset=utf-8",
          MediaType.APPLICATION_XML_VALUE
      })
  @BpTraceable
  public Mono<String> actualizarContactoTransaccional31(
      @RequestBody @Valid SoapEnvelopeRequestDto soapRequest) {

    ActualizarContactoTransaccional31 request =
        soapRequest.getBody().getActualizarContactoTransaccional31();
    GenericHeaderOut headerOut =
        SoapResponseHelper.buildHeaderOut(request.getHeaderIn());
    HeaderRequestModel headerModel =
        toHeaderModel(request.getHeaderIn());

    return Mono.defer(() -> {
          Optional<String> headerError =
              headerValidator.validate(headerModel);
          if (headerError.isPresent()) {
            return Mono.just(marshal(wrapResponse(headerOut,
                soapResponseHelper.buildFatalError(
                    "1", headerError.get()))));
          }
          TransactionalContactRequest domainRequest =
              toDomainRequest(request, headerModel);
          return updateService
              .updateTransactionalContact(domainRequest)
              .map(result -> marshal(wrapResponse(headerOut,
                  soapResponseHelper.buildSuccessError(
                      ErrorCatalogConstants.SUCCESS_CODE,
                      ErrorCatalogConstants.SUCCESS_MESSAGE,
                      ErrorCatalogConstants.SUCCESS_MESSAGE))));
        })
        .onErrorResume(throwable -> handleError(throwable, headerOut));
  }

  private Mono<String> handleError(
      Throwable throwable, GenericHeaderOut headerOut) {
    if (throwable instanceof BusinessValidationException bve) {
      return Mono.just(marshal(wrapResponse(headerOut,
          soapResponseHelper.buildBusinessError(
              bve.getErrorCode(), bve.getErrorMessage(),
              bve.getErrorMessage()))));
    }
    if (throwable instanceof BancsOperationException boe) {
      return Mono.just(marshal(wrapResponse(headerOut,
          soapResponseHelper.buildBancsError(
              boe.getErrorCode(), boe.getErrorMessage(),
              boe.getTransactionId()))));
    }
    log.error(
        "Unexpected error processing "
            + "actualizarContactoTransaccional31: {}",
        throwable.getMessage() != null
            ? throwable.getMessage() : "");
    return Mono.just(marshal(wrapResponse(headerOut,
        soapResponseHelper.buildFatalError(
            ErrorCatalogConstants.ERROR_CODE_GENERIC,
            "Error interno del servicio"))));
  }

  private String marshal(SoapEnvelopeResponseDto envelope) {
    return soapResponseHelper.marshalToXml(envelope);
  }

  private static SoapEnvelopeResponseDto wrapResponse(
      GenericHeaderOut headerOut, GenericError error) {
    ActualizarContactoTransaccional31Response response =
        new ActualizarContactoTransaccional31Response();
    response.setHeaderOut(headerOut);
    response.setError(error);
    SoapBodyResponseDto body = new SoapBodyResponseDto();
    body.setActualizarContactoTransaccional31Response(response);
    return SoapEnvelopeResponseDto.builder().body(body).build();
  }

  private TransactionalContactRequest toDomainRequest(
      ActualizarContactoTransaccional31 request,
      HeaderRequestModel headerModel) {
    String cif = request.getBodyIn().getCif();
    List<Contacto> contacts = request.getBodyIn()
        .getContactosTransaccionales().getContactosTransaccionals();
    List<TransactionalContact> domainContacts = contacts.stream()
        .map(c -> new TransactionalContact(
            c.getTipo(), c.getEmail(), c.getCelular(), c.isActivar()))
        .toList();
    return new TransactionalContactRequest(
        cif, domainContacts, headerModel);
  }

  static HeaderRequestModel toHeaderModel(GenericHeaderIn headerIn) {
    if (headerIn == null) {
      return null;
    }
    BancsRequestContext bancs = toBancsContext(headerIn.getBancs());
    return HeaderRequestModel.builder()
        .dispositivo(headerIn.getDispositivo())
        .empresa(headerIn.getEmpresa())
        .canal(headerIn.getCanal())
        .medio(headerIn.getMedio())
        .aplicacion(headerIn.getAplicacion())
        .agencia(headerIn.getAgencia())
        .tipoTransaccion(headerIn.getTipoTransaccion())
        .geolocalizacion(headerIn.getGeolocalizacion())
        .usuario(headerIn.getUsuario())
        .unicidad(headerIn.getUnicidad())
        .guid(headerIn.getGuid())
        .fechaHora(headerIn.getFechaHora())
        .filler(headerIn.getFiller())
        .idioma(headerIn.getIdioma())
        .sesion(headerIn.getSesion())
        .ip(headerIn.getIp())
        .idCliente(headerIn.getIdCliente())
        .tipoIdCliente(headerIn.getTipoIdCliente())
        .bancs(bancs)
        .build();
  }

  private static BancsRequestContext toBancsContext(BancsTeller bancs) {
    if (bancs == null) {
      return null;
    }
    return new BancsRequestContext(
        bancs.getTeller(), bancs.getTerminal(),
        bancs.getInstitucion(), bancs.getAgencia(),
        bancs.getEstacion(), bancs.getAplicacion(),
        bancs.getCanal());
  }
}
