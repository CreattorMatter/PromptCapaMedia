package com.pichincha.sp.domain.header;

public record BancsRequestContext(
    String teller,
    String terminal,
    String institution,
    String branch,
    String workstation,
    String application,
    String channel) {
}
