package com.pichincha.sp.infrastructure.exception.error.resolver;

import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevel;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import com.pichincha.sp.infrastructure.exception.ErrorCatalogConstants;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultBodyDto;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto.SoapFaultEnvelopeDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

@Component
public final class UnexpectedErrorResolver
    extends ErrorResolver<Throwable> {

  private static final String TITLE = "Unexpected error";
  private static final String DETAIL =
      "Detailed error information: "
          + "An unexpected error has occurred";

  private final CustomLogLevelHandler logLevelHandler;

  public UnexpectedErrorResolver(
      CustomLogLevelHandler logLevelHandler) {
    this.logLevelHandler = logLevelHandler;
  }

  @NonNull
  @Override
  protected SoapFaultEnvelopeDto buildError(
      @NonNull ServerHttpResponse serverResponse,
      @NonNull String requestPath,
      @NonNull Throwable throwable) {
    logLevelHandler.log(CustomLogLevel.ERROR,
        Thread.currentThread().getStackTrace(),
        "Unexpected error processing " + requestPath
            + " - " + throwable.getClass().getSimpleName()
            + ": " + throwable.getMessage(),
        "");
    serverResponse.setStatusCode(
        HttpStatus.INTERNAL_SERVER_ERROR);
    SoapFaultDto faultDetail = new SoapFaultDto();
    faultDetail.setFaultCode(ErrorCatalogConstants.FAULT_CODE);
    faultDetail.setFaultString(TITLE);
    faultDetail.setDetail(DETAIL);
    SoapFaultBodyDto faultBody = new SoapFaultBodyDto();
    faultBody.setFault(faultDetail);
    SoapFaultEnvelopeDto soapFault = new SoapFaultEnvelopeDto();
    soapFault.setBody(faultBody);
    return soapFault;
  }
}
