package com.pichincha.sp.domain.model;

public record PhoneNormalizationConfig(
    int internationalLength,
    String prefixExclude,
    String prefixReplace) {
}
