package com.pichincha.sp.application.input.port;

import com.pichincha.sp.domain.model.ContactOperationResult;
import com.pichincha.sp.domain.model.TransactionalContactRequest;
import reactor.core.publisher.Mono;

public interface UpdateTransactionalContactInputPort {

  Mono<ContactOperationResult> updateTransactionalContact(
      TransactionalContactRequest request);
}
