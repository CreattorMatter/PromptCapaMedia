package com.pichincha.sp.application.service;

import com.pichincha.common.trace.logger.annotation.BpLogger;
import com.pichincha.sp.application.input.port.UpdateTransactionalContactInputPort;
import com.pichincha.sp.application.output.port.ContactBancsOutputPort;
import com.pichincha.sp.application.util.ContactValidationUtil;
import com.pichincha.sp.application.util.ServiceLogHelper;
import com.pichincha.sp.domain.exception.BancsOperationException;
import com.pichincha.sp.domain.model.ContactOperationResult;
import com.pichincha.sp.domain.model.ExistingContact;
import com.pichincha.sp.domain.model.HeaderRequestModel;
import com.pichincha.sp.domain.model.PhoneNormalizationConfig;
import com.pichincha.sp.domain.model.TransactionalContact;
import com.pichincha.sp.domain.model.TransactionalContactRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class UpdateTransactionalContactService
    implements UpdateTransactionalContactInputPort {

  private static final String STATUS_ACTIVE = "00";
  private static final String STATUS_INACTIVE = "99";
  private static final String OPTION_UPDATE = "3";

  private final ServiceLogHelper log;
  private final ContactBancsOutputPort bancsPort;

  @Value("${phone.normalization.international-length:12}")
  private int phoneInternationalLength;

  @Value("${phone.normalization.prefix-exclude:5930}")
  private String phonePrefixExclude;

  @Value("${phone.normalization.prefix-replace:593}")
  private String phonePrefixReplace;

  @Override
  @BpLogger
  public Mono<ContactOperationResult> updateTransactionalContact(
      TransactionalContactRequest request) {
    ContactValidationUtil.validateCif(request.cif());
    String paddedCif = ContactValidationUtil.padCif(request.cif());
    log.info("[guid: {}] Updating transactional contacts for customer {}",
        extractGuid(request.headerContext()), paddedCif);
    return Flux.fromIterable(request.contacts())
        .concatMap(contact -> processOneContact(
            paddedCif, contact, request.headerContext()))
        .then(Mono.fromSupplier(() -> {
          log.info("[guid: {}] Transactional contact update completed successfully for customer {}",
              extractGuid(request.headerContext()), paddedCif);
          return ContactOperationResult.success();
        }))
        .doOnError(BancsOperationException.class, ex -> log.error(
            "[guid: {}] Error while updating transactional contacts for customer {} - code: {} message: {}",
            extractGuid(request.headerContext()), paddedCif,
            ex.getErrorCode(), ex.getErrorMessage()));
  }

  @BpLogger
  private Mono<Void> processOneContact(
      String cif, TransactionalContact contact,
      HeaderRequestModel headerContext) {
    return bancsPort.getExistingContact(cif, contact.type())
        .flatMap(existing -> contact.activate()
            ? handleActivation(cif, contact, existing, headerContext)
            : handleDeactivation(cif, contact, existing, headerContext));
  }

  @BpLogger
  private Mono<Void> handleActivation(
      String cif, TransactionalContact contact,
      ExistingContact existing, HeaderRequestModel headerContext) {
    PhoneNormalizationConfig phoneConfig = phoneConfig();
    String email = ContactValidationUtil.normalizeEmail(contact.email());
    String phone = ContactValidationUtil.normalizePhone(
        contact.phone(), phoneConfig);
    ContactValidationUtil.validateContactNotEmpty(
        email, phone, contact.type());
    if (OPTION_UPDATE.equals(existing.option())) {
      if (!ContactValidationUtil.hasChanges(email, phone, existing)) {
        log.info("[guid: {}] No changes detected for transactional contact {} of customer {}",
            extractGuid(headerContext), contact.type(), cif);
        return Mono.empty();
      }
      return bancsPort.updateContact(cif, contact.type(), OPTION_UPDATE,
          ContactValidationUtil.resolveEmail(email, existing),
          ContactValidationUtil.resolvePhone(phone, existing),
          STATUS_ACTIVE);
    }
    return bancsPort.updateContact(cif, contact.type(),
        existing.option(), email, phone, STATUS_ACTIVE);
  }

  @BpLogger
  private Mono<Void> handleDeactivation(
      String cif, TransactionalContact contact,
      ExistingContact existing, HeaderRequestModel headerContext) {
    ContactValidationUtil.validateCanDeactivate(
        existing, contact.type());
    return bancsPort.updateContact(cif, contact.type(),
        existing.option(), "", "", STATUS_INACTIVE);
  }

  @BpLogger
  private PhoneNormalizationConfig phoneConfig() {
    return new PhoneNormalizationConfig(
        phoneInternationalLength, phonePrefixExclude,
        phonePrefixReplace);
  }

  private static String extractGuid(HeaderRequestModel headerContext) {
    return headerContext == null ? "" : headerContext.guid();
  }
}
