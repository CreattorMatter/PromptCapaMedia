package com.pichincha.sp.application.util;

import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevel;
import com.pichincha.common.trace.logger.logger.custom.level.CustomLogLevelHandler;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ServiceLogHelper {

  private final CustomLogLevelHandler logLevelHandler;

  public void info(String message, Object... data) {
    logLevelHandler.log(
        CustomLogLevel.INFO,
        Thread.currentThread().getStackTrace(), message, data);
  }

  public void debug(String message, Object... data) {
    logLevelHandler.log(
        CustomLogLevel.DEBUG,
        Thread.currentThread().getStackTrace(), message, data);
  }

  public void warn(String message, Object... data) {
    logLevelHandler.log(
        CustomLogLevel.WARN,
        Thread.currentThread().getStackTrace(), message, data);
  }

  public void error(String message, Object... data) {
    logLevelHandler.log(
        CustomLogLevel.ERROR,
        Thread.currentThread().getStackTrace(), message, data);
  }
}
