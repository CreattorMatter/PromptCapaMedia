package com.pichincha.sp.application.util;

import com.pichincha.sp.domain.exception.BusinessValidationException;
import com.pichincha.sp.domain.model.ExistingContact;
import com.pichincha.sp.domain.model.PhoneNormalizationConfig;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

@UtilityClass
public class ContactValidationUtil {

  private static final int CIF_PADDED_LENGTH = 16;
  private static final String OPTION_INSERT = "1";

  public static void validateCif(String cif) {
    if (StringUtils.isBlank(cif)) {
      throw new BusinessValidationException(
          "1", "Valor del campo cif vacio o invalido");
    }
  }

  public static void validateContactNotEmpty(
      String email, String phone, String type) {
    if (StringUtils.isBlank(email) && StringUtils.isBlank(phone)) {
      throw new BusinessValidationException(
          "4",
          "contacto transaccional del tipo " + type + " vacio");
    }
  }

  public static void validateCanDeactivate(
      ExistingContact existing, String type) {
    if (OPTION_INSERT.equals(existing.option())) {
      throw new BusinessValidationException(
          "3",
          "No existe contacto transaccional para eliminar del tipo "
              + type);
    }
  }

  public static String padCif(String cif) {
    return StringUtils.leftPad(cif.trim(), CIF_PADDED_LENGTH, '0');
  }

  public static String normalizeEmail(String email) {
    if (email == null) {
      return "";
    }
    return email.replaceAll("[\\t\\r\\n ]", "");
  }

  public static String normalizePhone(
      String phone, PhoneNormalizationConfig config) {
    return PhoneNormalizationUtil.normalize(phone, config);
  }

  public static String resolveField(
      String newValue, String existingValue) {
    return StringUtils.equals(newValue, existingValue)
        ? null : newValue;
  }

  public static boolean hasChanges(
      String email, String phone, ExistingContact existing) {
    return !StringUtils.equals(email, existing.email())
        || !StringUtils.equals(phone, existing.phone());
  }

  public static String resolveEmail(
      String email, ExistingContact existing) {
    return StringUtils.equals(email, existing.email())
        ? existing.email() : email;
  }

  public static String resolvePhone(
      String phone, ExistingContact existing) {
    return StringUtils.equals(phone, existing.phone())
        ? existing.phone() : phone;
  }
}
