package com.pichincha.sp.domain.enums;

public enum ErrorSeverity {
  CLIENT_ERROR,
  SERVER_ERROR,
  BUSINESS_ERROR
}
