package com.pichincha.sp.domain.model;

import com.pichincha.sp.domain.header.BancsRequestContext;
import lombok.Builder;

@Builder
public record HeaderRequestModel(
    String dispositivo,
    String empresa,
    String canal,
    String medio,
    String aplicacion,
    String agencia,
    String tipoTransaccion,
    String geolocalizacion,
    String usuario,
    String unicidad,
    String guid,
    String fechaHora,
    String filler,
    String idioma,
    String sesion,
    String ip,
    String idCliente,
    String tipoIdCliente,
    BancsRequestContext bancs) {
}
