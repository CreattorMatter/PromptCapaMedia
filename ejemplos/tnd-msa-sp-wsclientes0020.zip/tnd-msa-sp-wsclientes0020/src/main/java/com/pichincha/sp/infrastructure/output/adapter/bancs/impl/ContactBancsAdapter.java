package com.pichincha.sp.infrastructure.output.adapter.bancs.impl;

import com.pichincha.bnc.apiclient.adapter.BancsClient;
import com.pichincha.bnc.apiclient.annotations.BancsService;
import com.pichincha.bnc.apiclient.dto.request.BancsRequest;
import com.pichincha.bnc.apiclient.dto.response.BancsResponse;
import com.pichincha.common.trace.logger.annotation.BpLogger;
import com.pichincha.sp.application.output.port.ContactBancsOutputPort;
import com.pichincha.sp.domain.exception.BancsOperationException;
import com.pichincha.sp.domain.model.ExistingContact;
import com.pichincha.sp.infrastructure.output.adapter.bancs.dto.request.Tx067186RequestDto;
import com.pichincha.sp.infrastructure.output.adapter.bancs.dto.response.Tx067186ResponseDto;
import com.pichincha.sp.application.util.ServiceLogHelper;
import java.util.Objects;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
public class ContactBancsAdapter implements ContactBancsOutputPort {

  private final ServiceLogHelper log;

  private static final String TX_CODE = "067186";
  private static final String WS_TX067186 = "ws-tx067186";
  private static final String INST_NO = "3";
  private static final String TRX_TYPE = "1";
  private static final String OPTION_QUERY = "2";
  private static final String OPTION_INSERT = "1";
  private static final String OPTION_UPDATE = "3";
  private static final String ERROR_NOT_FOUND = "0282";
  private static final String ERROR_INACTIVE = "1";
  private static final String ERROR_HEADER = "Error in BANCS TX067186";

  private final BancsClient bancsClient;

  public ContactBancsAdapter(
      @BancsService(WS_TX067186) BancsClient bancsClient,
      ServiceLogHelper log) {
    this.bancsClient = bancsClient;
    this.log = log;
  }

  @Override
  @BpLogger
  public Mono<ExistingContact> getExistingContact(
      String cif, String contactType) {

    Tx067186RequestDto body = Tx067186RequestDto.builder()
        .instNo(INST_NO)
        .customerNo(cif)
        .option(OPTION_QUERY)
        .trxType(TRX_TYPE)
        .trxInstance(contactType)
        .build();

    return callBancs(body)
        .doOnNext(r -> log.debug(
            "[TX{}] Query response - success: {}, error: {}",
            TX_CODE, r.success(), r.error()))
        .doOnError(ex -> log.error(
            "[TX{}] Query error - {}: {}",
            TX_CODE, ex.getClass().getName(), ex.getMessage()))
        .onErrorMap(ex -> !(ex instanceof BancsOperationException),
            ex -> new BancsOperationException(
                "999", ex.getMessage(), TX_CODE))
        .flatMap(this::mapQueryResponse);
  }

  @Override
  @BpLogger
  public Mono<Void> updateContact(
      String cif, String contactType, String option,
      String email, String phone, String status) {

    Tx067186RequestDto body = Tx067186RequestDto.builder()
        .instNo(INST_NO)
        .customerNo(cif)
        .option(option)
        .trxType(TRX_TYPE)
        .trxInstance(contactType)
        .trxemail(email)
        .trxcelular(phone)
        .trxestado(status)
        .build();

    return callBancs(body)
        .onErrorMap(ex -> !(ex instanceof BancsOperationException),
            ex -> new BancsOperationException(
                "999", ex.getMessage(), TX_CODE))
        .flatMap(response -> {
          if (Objects.nonNull(response.error())) {
            return Mono.error(new BancsOperationException(
                response.error().code(),
                response.error().message(), TX_CODE));
          }
          return Mono.empty();
        });
  }

  private Mono<BancsResponse<Tx067186ResponseDto>> callBancs(
      Tx067186RequestDto body) {
    BancsRequest<Tx067186RequestDto> request =
        BancsRequest.<Tx067186RequestDto>builder()
            .transactionId(TX_CODE)
            .body(body)
            .build();
    return bancsClient.call(request, Tx067186ResponseDto.class);
  }

  private Mono<ExistingContact> mapQueryResponse(
      BancsResponse<Tx067186ResponseDto> response) {
    if (Objects.nonNull(response.error())) {
      return resolveErrorAsContact(response.error().code());
    }
    if (Objects.isNull(response.body())) {
      return Mono.just(
          new ExistingContact(OPTION_INSERT, "", ""));
    }
    Tx067186ResponseDto body = response.body();
    String email = body.trxEmail() == null ? "" : body.trxEmail();
    String phone = body.trxCelular() == null ? "" : body.trxCelular();
    return Mono.just(
        new ExistingContact(OPTION_UPDATE, email, phone));
  }

  private Mono<ExistingContact> resolveErrorAsContact(String code) {
    if (ERROR_NOT_FOUND.equals(code)) {
      return Mono.just(
          new ExistingContact(OPTION_INSERT, "", ""));
    }
    if (ERROR_INACTIVE.equals(code)) {
      return Mono.just(
          new ExistingContact(OPTION_UPDATE, "", ""));
    }
    return Mono.error(new BancsOperationException(
        code, ERROR_HEADER, TX_CODE));
  }
}
