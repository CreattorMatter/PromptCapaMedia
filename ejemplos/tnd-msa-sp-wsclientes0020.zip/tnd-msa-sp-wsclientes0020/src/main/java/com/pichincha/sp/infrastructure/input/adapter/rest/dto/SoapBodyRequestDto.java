package com.pichincha.sp.infrastructure.input.adapter.rest.dto;

import com.pichincha.sp.generated.ActualizarContactoTransaccional31;
import jakarta.validation.Valid;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class SoapBodyRequestDto {

  @XmlElement(
      name = "ActualizarContactoTransaccional31",
      namespace = "http://bpichincha.com/servicios")
  @Valid
  private ActualizarContactoTransaccional31 actualizarContactoTransaccional31;
}
