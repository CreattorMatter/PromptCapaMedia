package com.pichincha.sp.domain.model;

public record ExistingContact(
    String option,
    String email,
    String phone) {
}
