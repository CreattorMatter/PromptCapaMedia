package com.pichincha.sp.infrastructure.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "bancs.error-codes")
public record BancsErrorCodesProperties(String iib, String bancsApp) {
}
