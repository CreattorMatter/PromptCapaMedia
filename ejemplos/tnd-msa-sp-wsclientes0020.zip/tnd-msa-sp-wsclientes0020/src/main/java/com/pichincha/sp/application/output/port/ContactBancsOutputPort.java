package com.pichincha.sp.application.output.port;

import com.pichincha.sp.domain.model.ExistingContact;
import reactor.core.publisher.Mono;

public interface ContactBancsOutputPort {

  Mono<ExistingContact> getExistingContact(
      String cif, String contactType);

  Mono<Void> updateContact(
      String cif, String contactType, String option,
      String email, String phone, String status);
}
