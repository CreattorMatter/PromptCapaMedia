package com.pichincha.sp.infrastructure.soap.helper;

import com.pichincha.sp.infrastructure.config.BancsErrorCodesProperties;
import com.pichincha.sp.infrastructure.exception.ErrorCatalogConstants;
import com.pichincha.sp.generated.GenericError;
import com.pichincha.sp.generated.GenericHeaderIn;
import com.pichincha.sp.generated.GenericHeaderOut;
import com.pichincha.sp.generated.Journal;
import com.pichincha.sp.generated.Journals;
import com.pichincha.sp.generated.TransaccionFinancieraType;
import com.pichincha.sp.infrastructure.input.adapter.rest.dto
    .SoapEnvelopeResponseDto;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import java.io.StringWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.stereotype.Component;

@Component
public class SoapResponseHelper {

  private final BancsErrorCodesProperties backendCodes;

  public SoapResponseHelper(
      BancsErrorCodesProperties backendCodes) {
    this.backendCodes = backendCodes;
  }

  public static GenericHeaderOut buildHeaderOut(
      GenericHeaderIn headerIn) {
    GenericHeaderOut headerOut = new GenericHeaderOut();
    headerOut.setDocumento(buildDocument());
    if (headerIn == null) {
      return headerOut;
    }
    headerOut.setDispositivo(headerIn.getDispositivo());
    headerOut.setEmpresa(headerIn.getEmpresa());
    headerOut.setCanal(headerIn.getCanal());
    headerOut.setMedio(headerIn.getMedio());
    headerOut.setAplicacion(headerIn.getAplicacion());
    headerOut.setAgencia(headerIn.getAgencia());
    headerOut.setTipoTransaccion(headerIn.getTipoTransaccion());
    headerOut.setGeolocalizacion(headerIn.getGeolocalizacion());
    headerOut.setUsuario(headerIn.getUsuario());
    headerOut.setUnicidad(headerIn.getUnicidad());
    headerOut.setGuid(headerIn.getGuid());
    headerOut.setFechaHora(headerIn.getFechaHora());
    headerOut.setFiller(headerIn.getFiller());
    headerOut.setIdioma(headerIn.getIdioma());
    headerOut.setSesion(headerIn.getSesion());
    headerOut.setIp(headerIn.getIp());
    headerOut.setIdCliente(headerIn.getIdCliente());
    headerOut.setTipoIdCliente(headerIn.getTipoIdCliente());
    return headerOut;
  }

  /** Success — tipo=INFO, backend=IIB. */
  public GenericError buildSuccessError(
      String codigo, String mensaje, String mensajeNegocio) {
    return buildError(codigo, mensaje, mensajeNegocio,
        ErrorCatalogConstants.ERROR_TYPE_INFO,
        ErrorCatalogConstants.WS_COMPONENTE,
        backendCodes.iib());
  }

  /** Business validation — tipo=ERROR, backend=IIB. */
  public GenericError buildBusinessError(
      String codigo, String mensaje, String mensajeNegocio) {
    return buildError(codigo, mensaje, mensajeNegocio,
        ErrorCatalogConstants.ERROR_TYPE_ERROR,
        ErrorCatalogConstants.WS_COMPONENTE,
        backendCodes.iib());
  }

  /** Header/catch-all fatal — tipo=FATAL, backend=IIB. */
  public GenericError buildFatalError(
      String codigo, String mensaje) {
    return buildError(codigo, mensaje, mensaje,
        ErrorCatalogConstants.ERROR_TYPE_FATAL,
        ErrorCatalogConstants.WS_COMPONENTE,
        backendCodes.iib());
  }

  /** BANCS TX error — tipo=FATAL, backend=BANCS, componente=TX code. */
  public GenericError buildBancsError(
      String codigo, String mensaje, String txCode) {
    return buildError(codigo, mensaje, mensaje,
        ErrorCatalogConstants.ERROR_TYPE_FATAL,
        txCode, backendCodes.bancsApp());
  }

  private static GenericError buildError(
      String codigo, String mensaje, String mensajeNegocio,
      String tipo, String componente, String backend) {
    GenericError error = new GenericError();
    error.setCodigo(nullSafe(codigo));
    error.setMensaje(nullSafe(mensaje));
    error.setMensajeNegocio(nullSafe(mensajeNegocio));
    error.setTipo(tipo);
    error.setRecurso(ErrorCatalogConstants.WS_RECURSO);
    error.setComponente(nullSafe(componente));
    error.setBackend(nullSafe(backend));
    return error;
  }

  private static String nullSafe(String v) {
    return v == null ? "" : v;
  }

  private static TransaccionFinancieraType buildDocument() {
    TransaccionFinancieraType document = new TransaccionFinancieraType();
    document.setFechaContable("");
    document.setNumeroDocumento("");
    document.setJournals(buildJournals());
    return document;
  }

  private static Journals buildJournals() {
    Journal journal = new Journal();
    journal.setValor("");
    Journals journals = new Journals();
    journals.getJournals().add(journal);
    return journals;
  }

  private static final JAXBContext JAXB_CTX;
  private static final Pattern EMPTY_TAG =
      Pattern.compile("<([\\w:]+)(\\s[^>]*)?>\\s*</\\1>");
  private static final Pattern XMLNS_DECL =
      Pattern.compile("\\s+xmlns:(\\w+)=\"([^\"]*)\"");
  private static final String NS1 = "NS1";

  static {
    try {
      JAXB_CTX = JAXBContext.newInstance(
          SoapEnvelopeResponseDto.class);
    } catch (JAXBException e) {
      throw new ExceptionInInitializerError(e);
    }
  }

  public String marshalToXml(SoapEnvelopeResponseDto envelope) {
    try {
      Marshaller m = JAXB_CTX.createMarshaller();
      m.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
      StringWriter sw = new StringWriter();
      m.marshal(envelope, sw);
      String xml = sw.toString();
      xml = scopeNamespaces(xml);
      xml = EMPTY_TAG.matcher(xml).replaceAll("<$1$2/>");
      return xml;
    } catch (JAXBException e) {
      throw new IllegalStateException(
          "Failed to marshal SOAP response", e);
    }
  }

  private static String scopeNamespaces(String xml) {
    int rootEnd = xml.indexOf('>');
    if (rootEnd < 0) {
      return xml;
    }
    String rootTag = xml.substring(0, rootEnd + 1);
    Matcher m = XMLNS_DECL.matcher(rootTag);
    java.util.List<String[]> toMove = new java.util.ArrayList<>();
    while (m.find()) {
      if (!m.group(1).equals(NS1)) {
        toMove.add(new String[] {m.group(1), m.group(2)});
      }
    }
    if (toMove.isEmpty()) {
      return xml;
    }
    String newRoot = rootTag;
    for (String[] ns : toMove) {
      newRoot = newRoot.replaceFirst(
          "\\s+xmlns:" + Pattern.quote(ns[0])
              + "=\"" + Pattern.quote(ns[1]) + "\"", "");
    }
    String rest = xml.substring(rootEnd + 1);
    for (String[] ns : toMove) {
      Pattern use = Pattern.compile(
          "<(" + Pattern.quote(ns[0]) + ":\\w+)");
      Matcher um = use.matcher(rest);
      if (um.find()) {
        rest = rest.substring(0, um.end())
            + " xmlns:" + ns[0] + "=\"" + ns[1] + "\""
            + rest.substring(um.end());
      }
    }
    return newRoot + rest;
  }
}
