package com.pichincha.sp.domain.model;

public record ContactOperationResult(
    String errorCode,
    String errorMessage,
    String component,
    String backend) {

  public static ContactOperationResult success() {
    return new ContactOperationResult("0", "OK", "", "");
  }

  public static ContactOperationResult failure(
      String errorCode, String errorMessage) {
    return new ContactOperationResult(
        errorCode, errorMessage, "", "");
  }
}
