package com.pichincha.sp.domain.model;

public record TransactionalContact(
    String type,
    String email,
    String phone,
    boolean activate) {
}
