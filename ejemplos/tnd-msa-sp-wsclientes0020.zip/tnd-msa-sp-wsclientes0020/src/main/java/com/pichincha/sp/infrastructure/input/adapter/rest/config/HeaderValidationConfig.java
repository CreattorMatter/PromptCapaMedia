package com.pichincha.sp.infrastructure.input.adapter.rest.config;

import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "header-validation")
public class HeaderValidationConfig {

  private Map<String, String> patterns;
  private Map<String, Integer> maxLengths;
}
