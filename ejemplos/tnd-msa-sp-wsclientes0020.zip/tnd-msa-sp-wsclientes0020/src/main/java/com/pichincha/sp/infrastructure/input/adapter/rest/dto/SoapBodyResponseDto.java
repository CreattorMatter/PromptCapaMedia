package com.pichincha.sp.infrastructure.input.adapter.rest.dto;

import com.pichincha.sp.generated.ActualizarContactoTransaccional31Response;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class SoapBodyResponseDto {

  @XmlElement(
      name = "ActualizarContactoTransaccional31Response",
      namespace = "http://bpichincha.com/servicios")
  private ActualizarContactoTransaccional31Response
      actualizarContactoTransaccional31Response;
}
