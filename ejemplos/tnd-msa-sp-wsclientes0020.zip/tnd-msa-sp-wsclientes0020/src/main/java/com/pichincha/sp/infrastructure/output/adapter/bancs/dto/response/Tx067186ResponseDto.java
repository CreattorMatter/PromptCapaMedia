package com.pichincha.sp.infrastructure.output.adapter.bancs.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public record Tx067186ResponseDto(
    @JsonProperty("trxCelular") String trxCelular,
    @JsonProperty("trxEmail") String trxEmail,
    @JsonProperty("trxEstado") String trxEstado) {
}
