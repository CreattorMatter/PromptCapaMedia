package com.pichincha.sp.domain.exception;

import lombok.Getter;

@Getter
public class BancsOperationException extends RuntimeException {

  private final String errorCode;
  private final String errorMessage;
  private final String transactionId;

  public BancsOperationException(
      String errorCode,
      String errorMessage,
      String transactionId) {
    super(errorMessage);
    this.errorCode = errorCode;
    this.errorMessage = errorMessage;
    this.transactionId = transactionId;
  }
}
