package com.pichincha.sp.infrastructure.exception;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ErrorCatalogConstants {

  public static final String FAULT_CODE = "soapenv:Client";
  public static final String FAULT_ACTOR =
      "http://pichincha.com/wsdl/Service";
  public static final String EXCEPTION_TITLE = "Service exception";
  public static final String DETAILED_ERROR_INFORMATION =
      "Detailed error information:";

  public static final String WS_RECURSO =
      "WSClientes0020/ActualizarContactoTransaccional31";
  public static final String WS_COMPONENTE =
      "ActualizarContactoTransaccional31";

  public static final String SUCCESS_CODE = "0";
  public static final String SUCCESS_MESSAGE = "OK";
  public static final String ERROR_CODE_GENERIC = "999";

  public static final String ERROR_TYPE_INFO = "INFO";
  public static final String ERROR_TYPE_ERROR = "ERROR";
  public static final String ERROR_TYPE_FATAL = "FATAL";
}
