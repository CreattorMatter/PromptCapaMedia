package com.pichincha.sp.domain.exception;

import lombok.Getter;

@Getter
public class BusinessValidationException extends RuntimeException {

  private final String errorCode;
  private final String errorMessage;
  private final String errorType;

  public BusinessValidationException(
      String errorCode, String errorMessage, String errorType) {
    super(errorMessage);
    this.errorCode = errorCode;
    this.errorMessage = errorMessage;
    this.errorType = errorType;
  }

  public BusinessValidationException(
      String errorCode, String errorMessage) {
    this(errorCode, errorMessage, "ERROR");
  }
}
