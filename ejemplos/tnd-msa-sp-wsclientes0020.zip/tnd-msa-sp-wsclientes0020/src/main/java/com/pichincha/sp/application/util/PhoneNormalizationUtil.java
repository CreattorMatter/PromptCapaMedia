package com.pichincha.sp.application.util;

import com.pichincha.sp.domain.model.PhoneNormalizationConfig;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

@UtilityClass
public class PhoneNormalizationUtil {

  public static String normalize(
      String phone, PhoneNormalizationConfig config) {
    if (StringUtils.isBlank(phone)) {
      return phone == null ? "" : phone;
    }
    if (phone.length() > config.internationalLength()
        && phone.startsWith(config.prefixExclude())) {
      return config.prefixReplace()
          + phone.substring(config.prefixExclude().length());
    }
    return phone;
  }
}
