# ANALISIS_WSClientes0020.md

---

## 1. Header (Metadata)

| Campo | Valor |
|---|---|
| Servicio | WSClientes0020 |
| Operacion SOAP | ActualizarContactoTransaccional31 |
| Namespace | `http://bpichincha.com/servicios` |
| Version artefacto | 1.0.0-RC1 |
| Packaging | iib-bar |
| Integration Server | ISClientes211 |
| Autor original | Christian Herrera Narvaez (TCS Tata Consultancy Services) |
| Fecha creacion | 23 Junio 2017 |
| Repositorio | `tpl-bus-omnicanal/sqb-msa-wsclientes0020` |
| Owner Backstage | `celulabuS@pichincha.com` |
| Sistema | tpl-bus-omnicanal |
| Lifecycle | production |
| Tags | esql, plataforma-y-sre, middleware |
| Fecha de analisis | 2026-04-09 |
| Analista | Claude Opus 4.6 (analisis automatizado) |

**Fuente:** `catalog-info.yaml` lineas 1-27, `pom.xml` lineas 1-10.

---

## 2. Descripcion General

WSClientes0020 es un microservicio IIB que expone una operacion SOAP llamada `ActualizarContactoTransaccional31`. Su proposito es gestionar (crear, actualizar y eliminar) los contactos transaccionales de un cliente en el core BANCS.

El servicio implementa un patron de "consulta-antes-de-escribir":
1. Primero consulta si el cliente ya tiene un contacto transaccional del tipo solicitado (invocando UMPClientes0003).
2. Segun el resultado de la consulta y la bandera `activar` del request, decide si debe insertar (option=1), actualizar (option=3) o desactivar (estado=99) el contacto.
3. Ejecuta la escritura invocando UMPClientes0005.

Ambos UMPs internamente invocan la misma transaccion BANCS **TX 067186**, diferenciandose por el campo `option`:
- `option=2` para consulta (UMPClientes0003)
- `option=1` para insercion y `option=3` para actualizacion (UMPClientes0005, donde el valor viene del orquestador)

**Fuente:** ESQL principal lineas 20-247, WSDL linea 31 documentacion.

---

## 3. Archivos Analizados

### 3.1 Servicio Principal (WSClientes0020)

| # | Archivo | Ruta absoluta | Tipo |
|---|---|---|---|
| 1 | ActualizarContactoTransaccional31.esql | `/Users/jeanpierregarcia/BP/0020/sqb-msa-wsclientes0020/com/bpichincha/esb/wsclientes0020/ActualizarContactoTransaccional31.esql` | ESQL (logica de negocio) |
| 2 | WSClientes0020.wsdl | `/Users/jeanpierregarcia/BP/0020/sqb-msa-wsclientes0020/WSClientes0020.wsdl` | WSDL (contrato SOAP) |
| 3 | WSClientes0020_InlineSchema1.xsd | `/Users/jeanpierregarcia/BP/0020/sqb-msa-wsclientes0020/WSClientes0020_InlineSchema1.xsd` | XSD (tipos de datos) |
| 4 | WSClientes0020.xsd | `/Users/jeanpierregarcia/BP/0020/sqb-msa-wsclientes0020/WSClientes0020.xsd` | XSD (wrapper) |
| 5 | WSClientes0020.msgflow | `/Users/jeanpierregarcia/BP/0020/sqb-msa-wsclientes0020/com/bpichincha/esb/wsclientes0020/WSClientes0020.msgflow` | Message Flow principal |
| 6 | ActualizarContactoTransaccional31.subflow | `/Users/jeanpierregarcia/BP/0020/sqb-msa-wsclientes0020/com/bpichincha/esb/wsclientes0020/ActualizarContactoTransaccional31.subflow` | Subflow de operacion |
| 7 | pom.xml | `/Users/jeanpierregarcia/BP/0020/sqb-msa-wsclientes0020/pom.xml` | Maven POM |
| 8 | catalog-info.yaml | `/Users/jeanpierregarcia/BP/0020/sqb-msa-wsclientes0020/catalog-info.yaml` | Backstage catalog |

### 3.2 UMPClientes0003 (Consulta Contacto Notificacion)

| # | Archivo | Ruta absoluta | Tipo |
|---|---|---|---|
| 9 | ConsultarContactoNotificacion01.esql | `/Users/jeanpierregarcia/BP/UMP/sqb-msa-umpclientes0003/com/bpichincha/esb/umpclientes0003/ConsultarContactoNotificacion01.esql` | ESQL (logica UMP) |
| 10 | ConsultarContactoNotificacion01.subflow | `/Users/jeanpierregarcia/BP/UMP/sqb-msa-umpclientes0003/com/bpichincha/esb/umpclientes0003/ConsultarContactoNotificacion01.subflow` | Subflow UMP |
| 11 | pom.xml | `/Users/jeanpierregarcia/BP/UMP/sqb-msa-umpclientes0003/pom.xml` | Maven POM |

### 3.3 UMPClientes0005 (Actualizar Contacto Transaccional)

| # | Archivo | Ruta absoluta | Tipo |
|---|---|---|---|
| 12 | ActualizarContactoTransaccional31.esql | `/Users/jeanpierregarcia/BP/UMP/sqb-msa-umpclientes0005/com/bpichincha/esb/umpclientes0005/ActualizarContactoTransaccional31.esql` | ESQL (logica UMP) |
| 13 | ActualizarContactoTransaccional31.subflow | `/Users/jeanpierregarcia/BP/UMP/sqb-msa-umpclientes0005/com/bpichincha/esb/umpclientes0005/ActualizarContactoTransaccional31.subflow` | Subflow UMP |
| 14 | pom.xml | `/Users/jeanpierregarcia/BP/UMP/sqb-msa-umpclientes0005/pom.xml` | Maven POM |

### 3.4 Artefactos Genericos Referenciados (no incluidos directamente)

| # | Artefacto | Version | Proposito |
|---|---|---|---|
| 15 | GenericSOAP.xsd | N/A (via TCSProcesarServicioSOAP) | Tipos GenericHeaderIn, GenericHeaderOut, GenericError |
| 16 | TCSProcesarServicioSOAP | 1.0.1-RC1 | Framework SOAP generico (IniciarServicioSOAP, FinalizarServicioSOAP) |
| 17 | TCSProcesarBancs | 1.0.2-RC1 | Framework invocacion BANCS (InvocarBancs) |
| 18 | TCSProcesarError | 1.0.0-RC1 | Manejo errores UMP (ProcesarErrorMicroservicio) |

**Fuente:** `pom.xml` lineas 130-163, UMP pom.xml archivos.

---

## 4. Endpoints Expuestos (Contrato SOAP Completo)

### 4.1 Endpoint

| Campo | Valor |
|---|---|
| URL | `http://localhost:7800/IntegrationBus/soap/WSClientes0020` |
| urlSelector (IIB) | `/IntegrationBus/soap/WSClientes0020` |
| Puerto documentado | 7911 (WSDL doc) / 7800 (soap:address) |
| Binding style | document/literal |
| soapAction | `http://bpichincha.com/servicios/NewOperation` |
| Transport | HTTP |
| PortType | WSClientes0020 |
| Binding | WSClientes0020SOAP |
| Port | WSClientes0020SOAP |

**Fuente:** `WSClientes0020.wsdl` lineas 42-62.

### 4.2 Operacion Unica

| Operacion | Input Message | Output Message |
|---|---|---|
| ActualizarContactoTransaccional31 | ActualizarContactoTransaccional31Request | ActualizarContactoTransaccional31Response |

**Fuente:** `WSClientes0020.wsdl` lineas 16-27.

### 4.3 Request — `ActualizarContactoTransaccional31`

```
ActualizarContactoTransaccional31
  |-- headerIn : GenericHeaderIn [1..1]
  |     |-- dispositivo : string [1..1]    (32 chars, SHA256 dispositivo)
  |     |-- empresa : string [1..1]        (ej: "0010")
  |     |-- canal : string [1..1]          (2 chars, ej: "02")
  |     |-- medio : string [1..1]          (6 chars, ej: "020002")
  |     |-- aplicacion : string [1..1]     (5 chars, ej: "00270")
  |     |-- agencia : string [1..1]        (ej: "00012")
  |     |-- tipoTransaccion : string [1..1](9 chars, ej: "304100111")
  |     |-- geolocalizacion : string [1..1]
  |     |-- usuario : string [1..1]        (8 chars, ej: "USINTERT")
  |     |-- unicidad : string [1..1]       (44 chars)
  |     |-- guid : string [1..1]           (32 chars, UUID sin guiones)
  |     |-- fechaHora : string [1..1]      (18 chars, YYYYMMDDhhmmssnnnn)
  |     |-- filler : string [1..1]         (50 chars, relleno)
  |     |-- idioma : string [1..1]         (2 chars, ej: "es")
  |     |-- sesion : string [1..1]
  |     |-- ip : string [1..1]             (15 chars max)
  |     |-- idCliente : string [1..1]      (identificacion cliente)
  |     |-- tipoIdCliente : string [1..1]  (4 chars, ej: "0001")
  |     +-- bancs : BancsTeller [0..1]
  |           |-- teller : string [1..1]      (8 chars)
  |           |-- terminal : string [1..1]    (6 chars)
  |           |-- institucion : string [1..1] (6 chars)
  |           |-- agencia : string [1..1]     (5 chars)
  |           |-- estacion : string [1..1]    (3 chars)
  |           |-- aplicacion : string [1..1]  (3 chars)
  |           +-- canal : string [1..1]       (1 char)
  |
  +-- bodyIn : bodyIN [1..1]
        |-- cif : string [1..1]            (max 16 chars, CIF cliente)
        +-- contactosTransaccionales : datosContacto [1..1]
              +-- contactosTransaccional : contacto [1..unbounded]
                    |-- tipo : string [1..1]    (1 char: "1"=principal, "2"=secundario)
                    |-- email : string [0..1]   (20 chars max)
                    |-- celular : string [0..1] (10 chars max)
                    +-- activar : boolean [1..1] (true=activar, false=desactivar)
```

**Fuente:** `WSClientes0020_InlineSchema1.xsd` lineas 10-149, `GenericSOAP.xsd` lineas 109-287.

### 4.4 Response — `ActualizarContactoTransaccional31Response`

```
ActualizarContactoTransaccional31Response
  |-- headerOut : GenericHeaderOut [1..1]
  |     |-- (mismos campos que GenericHeaderIn)
  |     +-- documento : transaccionFinancieraType [1..1]
  |           |-- fechaContable : string [1..1]
  |           |-- numeroDocumento : string [1..1]
  |           +-- journals : journals [1..1]
  |                 +-- journal : journal [0..unbounded]
  |                       +-- valor : string [1..1]
  |
  |-- bodyOut : bodyOUT [0..1]    <<< VACIO (complexType sin elementos)
  |
  +-- error : GenericError [1..1]
        |-- codigo : string [1..1]        ("0" = exito)
        |-- mensaje : string [1..1]       ("OK" = exito)
        |-- mensajeNegocio : string [1..1]
        |-- tipo : string [1..1]          ("ERROR", "FATAL", "INFO")
        |-- recurso : string [1..1]       (nombre/metodo)
        |-- componente : string [1..1]    (ej: "TX067186")
        +-- backend : string [1..1]       (ej: "00045" para BANCS)
```

**NOTA IMPORTANTE:** El `bodyOUT` esta definido como complexType vacio (linea 86-89 de InlineSchema1.xsd). El servicio NO retorna datos de negocio en el body de la respuesta; toda la informacion relevante esta en el bloque `error`.

**Fuente:** `WSClientes0020_InlineSchema1.xsd` lineas 30-60, 86-89. `GenericSOAP.xsd` lineas 289-650.

---

## 5. Mapeo UMP a TX BANCS (TX 067186 Completo)

### 5.1 Resumen de Invocaciones

Ambos UMPs invocan la **misma transaccion BANCS TX 067186**. La diferenciacion de comportamiento se logra mediante el campo `option`:

| UMP | Metodo | TX BANCS | option | Proposito |
|---|---|---|---|---|
| UMPClientes0003 | ConsultarContactoNotificacion01 | 067186 | `"2"` (fijo) | Consultar contacto transaccional existente |
| UMPClientes0005 | ActualizarContactoTransaccional31 | 067186 | variable (`"1"` o `"3"`) | Insertar o actualizar contacto transaccional |

**Fuente:** UMPClientes0003 ESQL linea 50 (`SET Environment.BancsSubflow.tx = '067186'`), linea 57 (`SET bancsIn.option = '2'`). UMPClientes0005 ESQL linea 49 (`SET Environment.BancsSubflow.tx = '067186'`), linea 56 (`SET bancsIn.option = operacion.opcion`).

### 5.2 TX 067186 — Campos de Entrada (BANCS Input)

#### 5.2.1 UMPClientes0003 — Consulta (option=2)

| Campo BANCS | Valor asignado | Linea | Fijo/Dinamico |
|---|---|---|---|
| `instNo` | `'3'` | UMPClientes0003 ESQL L55 | Fijo |
| `customerNo` | `operacion.CIF` (CIF del cliente, padded a 16 chars) | UMPClientes0003 ESQL L56 | Dinamico |
| `option` | `'2'` | UMPClientes0003 ESQL L57 | Fijo |
| `trxType` | `'1'` | UMPClientes0003 ESQL L58 | Fijo |
| `trxInstance` | `operacion.tipo` (tipo de contacto: "1" o "2") | UMPClientes0003 ESQL L59 | Dinamico |

**Fuente:** `ConsultarContactoNotificacion01.esql` lineas 53-59.

#### 5.2.2 UMPClientes0005 — Insercion/Actualizacion (option=1 o 3)

| Campo BANCS | Valor asignado | Linea | Fijo/Dinamico |
|---|---|---|---|
| `instNo` | `'3'` | UMPClientes0005 ESQL L54 | Fijo |
| `customerNo` | `operacion.CIF` (CIF del cliente, padded a 16 chars) | UMPClientes0005 ESQL L55 | Dinamico |
| `option` | `operacion.opcion` (viene del orquestador: "1" o "3") | UMPClientes0005 ESQL L56 | Dinamico |
| `trxType` | `'1'` | UMPClientes0005 ESQL L57 | Fijo |
| `trxInstance` | `operacion.tipo` (tipo de contacto: "1" o "2") | UMPClientes0005 ESQL L58 | Dinamico |
| `trxcelular` | `operacion.celular` | UMPClientes0005 ESQL L59 | Dinamico |
| `trxemail` | `operacion.email` | UMPClientes0005 ESQL L60 | Dinamico |
| `trxestado` | `operacion.estado` ("00" activo, "99" desactivado) | UMPClientes0005 ESQL L61 | Dinamico |

**Fuente:** `ActualizarContactoTransaccional31.esql` (UMPClientes0005) lineas 52-61.

### 5.3 TX 067186 — Campos de Salida (BANCS Output)

#### 5.3.1 UMPClientes0003 — Campos leidos de la respuesta BANCS

| Campo BANCS Output | Campo mapeado en servicio | Linea | Uso |
|---|---|---|---|
| `bancsOut.bodyOut.trxestado` | Evaluado contra `'99'` | UMPClientes0003 ESQL L71 | Si es "99", el contacto esta desactivado |
| `bancsOut.bodyOut.trxcelular` | `servicio.bodyOut.celular` | UMPClientes0003 ESQL L89 | Celular del contacto existente |
| `bancsOut.bodyOut.trxemail` | `servicio.bodyOut.email` | UMPClientes0003 ESQL L90 | Email del contacto existente |
| `bancsOut.error.codigo` | Evaluado contra `'0'` y `'0282'` | UMPClientes0003 ESQL L66, L80 | Control de errores BANCS |

**Fuente:** `ConsultarContactoNotificacion01.esql` lineas 66-90.

#### 5.3.2 UMPClientes0005 — Campos leidos de la respuesta BANCS

| Campo BANCS Output | Campo mapeado en servicio | Linea | Uso |
|---|---|---|---|
| `bancsOut.error.codigo` | Evaluado contra `'0'` | UMPClientes0005 ESQL L68 | Solo se verifica exito/error |

**NOTA:** UMPClientes0005 NO lee campos del bodyOut de BANCS. Solo verifica que `error.codigo` sea `'0'`. El output de la TX 067186 en modo escritura no contiene datos de negocio que el servicio necesite.

**Fuente:** `ActualizarContactoTransaccional31.esql` (UMPClientes0005) lineas 67-71.

### 5.4 Semantica del Campo `option` en TX 067186

| option | Significado | Usado por | Determinado por |
|---|---|---|---|
| `"1"` | Insertar nuevo contacto transaccional | UMPClientes0005 | Orquestador: cuando consulta retorna error `0282` (no existe) |
| `"2"` | Consultar contacto transaccional existente | UMPClientes0003 | Fijo en UMP (hardcoded) |
| `"3"` | Actualizar contacto transaccional existente | UMPClientes0005 | Orquestador: cuando consulta retorna exito `0` o error `1` |

**Fuente:** ESQL principal lineas 176-183 (determinacion de opcion), UMPClientes0003 ESQL linea 57, UMPClientes0005 ESQL linea 56.

### 5.5 Semantica del Campo `trxestado` en TX 067186

| trxestado | Significado | Contexto |
|---|---|---|
| `"00"` | Contacto activo | Enviado por UMPClientes0005 al activar (ESQL principal linea 100, 105, 112, 119) |
| `"99"` | Contacto desactivado/eliminado | Enviado por UMPClientes0005 al desactivar (ESQL principal linea 135). Tambien evaluado en la respuesta de consulta (UMPClientes0003 ESQL linea 71) |

---

## 6. Uso de Base de Datos

**NO EVIDENCIA.** No se encontraron sentencias SQL (SELECT, INSERT, UPDATE, DELETE), referencias ODBC, ni DataSource en ningun archivo ESQL analizado (servicio principal ni UMPs). Toda la persistencia se delega al core BANCS via TX 067186.

---

## 7. Almacenamiento Temporal

### 7.1 Environment Tree (arbol de contexto IIB)

El servicio hace uso extensivo del arbol `Environment` para pasar datos entre procedimientos y subflows:

| Ruta Environment | Proposito | Archivo / Linea |
|---|---|---|
| `Environment.entrada.[<].bodyIn` | Entrada del servicio deserializada | ESQL principal L53, L75, L155, L201 |
| `Environment.salida.[<].error` | Salida de error construida | ESQL principal L39-40, L57-58, L92, L128-129, L185, L241 |
| `Environment.UMPSubflow.ump` | Nombre del UMP a invocar | ESQL principal L158, L205 |
| `Environment.UMPSubflow.metodo` | Metodo del UMP | ESQL principal L159, L206 |
| `Environment.UMPSubflow.configurable` | Flag de configurabilidad | ESQL principal L160, L207 |
| `Environment.UMPSubflow.ConsultarContactoNotificacion01` | Datos entrada/salida UMP0003 | ESQL principal L164, L172 |
| `Environment.UMPSubflow.ActualizarContactoTransaccional31` | Datos entrada/salida UMP0005 | ESQL principal L211, L237 |
| `Environment.BancsSubflow.tx` | Numero de TX BANCS | UMP0003 ESQL L50, UMP0005 ESQL L49 |
| `Environment.BancsSubflow.Input` | Campos de entrada a BANCS | UMP0003 ESQL L54, UMP0005 ESQL L53 |
| `Environment.BancsSubflow.Output` | Respuesta BANCS | UMP0005 ESQL L67 |
| `Environment.BancsSubflow.error` | Error BANCS | UMP0003 ESQL L66 |
| `Environment.cache.WSClientes0020Config` | Configuracion cacheada del servicio | ESQL principal L202 |
| `Environment.cache.codigosBackend` | Codigos de backend para errores | UMP0003 ESQL L47 |
| `Environment.ServiceData.UMP.recurso` | Recurso UMP para error | UMP0003 ESQL L75-76 |
| `Environment.ServiceData.UMP.metodo` | Metodo UMP para error | UMP0003 ESQL L76 |

**Fuente:** Multiples archivos ESQL como se indica en la columna.

---

## 8. Uso de Mensajeria (Colas MQ)

### 8.1 Cola de Configuracion

| Cola | Nodo | Proposito | Transaction Mode |
|---|---|---|---|
| `CE_WSClientes0020Config` | MQ Recursos (MQInput) | Carga configuracion del servicio en cache | `no` (sin transaccion) |

**Fuente:** `WSClientes0020.msgflow` linea 10 (`queueName="CE_WSClientes0020Config"`).

### 8.2 Patron

El nodo MQInput lee un mensaje de la cola `CE_WSClientes0020Config` y lo envia al subflow `IniciarServicioSOAP` para poblar `Environment.cache.WSClientes0020Config`. Este es un patron estandar de IIB para cargar propiedades configurables sin redeployar.

Las propiedades configurables identificadas en el codigo son:
- `propiedades.longitudCelularInternacional` — ESQL principal linea 221
- `propiedades.prefijoIntExc` — ESQL principal linea 222 (prefijo a excluir, probablemente "5930")
- `propiedades.prefijoIntEc` — ESQL principal linea 223 (prefijo Ecuador correcto, probablemente "593")

**Fuente:** ESQL principal lineas 202, 221-223.

---

## 9. Logica de Negocio Paso a Paso

### 9.1 Flujo Principal (msgflow)

```
SOAP Input ──> IniciarServicioSOAP ──> Route To Label
                    ^                        |
              MQ Recursos                    v
         (CE_WSClientes0020Config)    Label: ActualizarContactoTransaccional31
                                             |
                                             v
                                 SubflujoActualizarContactoTransaccional31
```

**Fuente:** `WSClientes0020.msgflow` lineas 10-32.

### 9.2 Subflow ActualizarContactoTransaccional31

```
Input ──> Procesar (Compute) ──> FinalizarServicioSOAP
              |
              |── PROPAGATE 'et_ump' ──> Label: et_ConsultarContactoNotificacion01
              |                                  |
              |                                  v
              |                          ConsultarContactoNotificacion01 (UMP0003 subflow)
              |
              |── PROPAGATE 'et_ump' ──> Label: et_ActualizarContactoTransaccional31
              |                                  |
              |                                  v
              |                          ActualizarContactoTransaccional31 (UMP0005 subflow)
              |
              +── PROPAGATE 'et_fin' (en caso de error de negocio)
```

**Fuente:** `ActualizarContactoTransaccional31.subflow` lineas 10-38.

### 9.3 Flujo de Cada UMP

Ambos UMPs siguen el mismo patron:

```
Input ──> TryCatch
              |── try ──> Procesar (Compute) ──> [sale por Environment]
              +── catch ──> ProcesarErrorMicroservicio
```

Dentro de cada Compute, el UMP:
1. Arma los campos de entrada en `Environment.BancsSubflow.Input`
2. Hace `PROPAGATE TO LABEL 'et_bancs'`
3. El subflow `InvocarBancs` (externo) ejecuta la TX
4. Lee la respuesta de `Environment.BancsSubflow`

**Fuente:** UMP0003 subflow lineas 9-24, UMP0005 subflow lineas 9-24.

### 9.4 Algoritmo Detallado del Orquestador (ESQL Principal)

```
PROCEDIMIENTO Main():
  1. ValidarEntrada()
     - Si cif esta vacio -> error codigo='1', PROPAGATE 'et_fin', RETURN FALSE
  
  2. OrquestarTX()
     - Para cada contacto en contactosTransaccionales:
       a. InvocarDatosTransaccionales(contacto.tipo)
          -> Llama UMPClientes0003 con option='2'
          -> Si respuesta OK (codigo='0'):
               opcion = '3' (actualizar)
               Recupera emailOut y celularOut del contacto existente
          -> Si error '0282':
               opcion = '1' (insertar, no existe)
          -> Si error '1':
               opcion = '3' (actualizar, contacto desactivado estado=99)
          -> Cualquier otro error: propaga error y RETURN FALSE
       
       b. Si contacto.activar == TRUE:
          - Si email Y celular vacios -> error codigo='4', RETURN FALSE
          - Si opcion == '3' (actualizar existente):
            * Compara email input vs emailOut existente
            * Compara celular input vs celularOut existente
            * Solo actualiza los campos que cambiaron
            * Los campos sin cambio mantienen el valor anterior
          - Si opcion != '3' (insertar nuevo):
            * Llama ActualizarContactoTransaccional con estado='00'
       
       c. Si contacto.activar == FALSE:
          - Si opcion == '1' (no existe):
            -> error codigo='3' "No existe contacto para eliminar"
          - Si opcion != '1' (existe):
            -> Llama ActualizarContactoTransaccional con email='', 
               celular='', estado='99'
     
     - Si todo OK -> error codigo='0', mensaje='OK'
```

**Fuente:** ESQL principal lineas 20-247 (todo el modulo).

### 9.5 Detalle de Comparacion para Actualizacion Selectiva (opcion='3')

Cuando el contacto existe y se quiere activar/actualizar, el servicio hace una comparacion campo a campo para enviar solo los valores que cambiaron:

| Email cambia? | Celular cambia? | Email enviado | Celular enviado | Lineas |
|---|---|---|---|---|
| SI | SI | contacto.email | contacto.celular | L100 |
| SI | NO | contacto.email | celularOut (existente) | L105 |
| NO | SI | emailOut (existente) | contacto.celular | L112 |
| NO | NO | (no se invoca UMP0005) | (no se invoca UMP0005) | L116 (implito) |

**Fuente:** ESQL principal lineas 96-117.

---

## 10. Normalizaciones de Datos

### 10.1 Padding CIF a 16 Caracteres

**Transformacion:** `RIGHT('0000000000000000' || bodyIn.cif, 16)`

Aplica padding left con ceros hasta alcanzar 16 caracteres.

| Donde se aplica | Linea |
|---|---|
| ESQL principal — InvocarDatosTransaccionales | L165 |
| ESQL principal — ActualizarContactoTransaccional | L212 |

**Ejemplo:** CIF `"399743"` se transforma en `"0000000000399743"`.

**Fuente:** ESQL principal lineas 165, 212.

### 10.2 Limpieza de Escape Characters en Email

**Transformacion:** `TRIM(tab FROM email)` donde `tab = CAST(X'090D0A20' AS CHAR CCSID 1208)`

Elimina los siguientes caracteres del email:
- `0x09` — Tab
- `0x0D` — Carriage Return
- `0x0A` — Line Feed
- `0x20` — Space

**Comentario del codigo:** "Adicion logica version 1.2 para controlar los correo electronico desde escape characters"

**Fuente:** ESQL principal lineas 216-218.

### 10.3 Normalizacion Celular Internacional

**Logica:** Si el celular tiene mas caracteres que `longitudCelularInternacional` (configurable) y empieza con `prefijoIntExc` (probablemente "5930"), se reemplaza por `prefijoIntEc` (probablemente "593") concatenado con el resto del numero.

```
SI LENGTH(celular) > longitudCelularInternacional ENTONCES
    SI celular empieza con "5930" ENTONCES
        celular = "593" + SUBSTRING(celular DESDE posicion 5)
    FIN SI
FIN SI
```

**Comentario del codigo:** "Adicion logica version 1.1 para controlar los numeros de telefono con 5930"

**Fuente:** ESQL principal lineas 220-229.

---

## 11. Asimetria de Formato CIF

| Contexto | Formato CIF | Evidencia |
|---|---|---|
| Request SOAP (bodyIn.cif) | String sin padding (ej: "399743") | XSD: `<xsd:element name="cif" type="xsd:string">` max 16 |
| Envio a BANCS (customerNo) | Padded a 16 chars con ceros izquierda | ESQL principal L165, L212: `RIGHT('0000000000000000' \|\| bodyIn.cif, 16)` |
| Response SOAP | No aplica (bodyOut vacio) | XSD bodyOUT: complexType vacio |

**CRITICO para migracion:** El padding se aplica en DOS lugares del ESQL principal (L165 y L212) y se hace ANTES de enviar a cada UMP. Los UMPs reciben el CIF ya normalizado en `operacion.CIF`.

**Fuente:** ESQL principal lineas 165, 212. XSD lineas 66-73.

---

## 12. Mapa de Propagacion de Errores

### 12.1 Flujo de Propagacion

```
[BANCS TX 067186]
       |
       v
[UMP0003/UMP0005] ── error BANCS ──> Environment.BancsSubflow.error
       |                                        |
       |                                        v
       |                              UMP evalua error.codigo
       |                                        |
       |                         (UMP0003: propaga '0282' como opcion='1')
       |                         (UMP0003: propaga '1' como opcion='3')
       |                         (UMP0003: otros errores -> servicio.error)
       |                         (UMP0005: cualquier error -> servicio.error)
       |
       v
[ESQL Principal] ── Environment.UMPSubflow.*.error
       |
       |── Error de validacion local -> Environment.salida.[<].error
       |── Error de UMP no manejado -> Environment.salida.[<].error
       |
       v
[FinalizarServicioSOAP] ── Lee Environment.salida -> Arma Response SOAP
       |
       v
[SOAP Reply] ── GenericError en response XML
```

### 12.2 Errores Absorbidos vs Propagados

| Error | Origen | Comportamiento | Fuente |
|---|---|---|---|
| BANCS `0282` | UMPClientes0003 | **ABSORBIDO** — se interpreta como "no existe", opcion='1' | UMP0003 ESQL L80 |
| BANCS `1` (con estado 99) | UMPClientes0003 | **ABSORBIDO** — se interpreta como "desactivado", opcion='3' | UMP0003 ESQL L82 |
| BANCS cualquier otro error | UMPClientes0003 | **PROPAGADO** al servicio principal | UMP0003 ESQL L67, ESQL principal L185-187 |
| BANCS cualquier error | UMPClientes0005 | **PROPAGADO** al servicio principal | UMP0005 ESQL L68-70, ESQL principal L240-243 |
| CIF vacio | Validacion local | **GENERADO** codigo='1' | ESQL principal L56-60 |
| Contacto vacio | Validacion local | **GENERADO** codigo='4' | ESQL principal L90-94 |
| No existe para eliminar | Logica negocio | **GENERADO** codigo='3' | ESQL principal L127-131 |
| Excepcion runtime | UMP TryCatch | **CAPTURADO** por ProcesarErrorMicroservicio | UMP subflows (nodo TryCatch) |

**Fuente:** Multiples archivos como se indica.

---

## 13. Manejo de Errores de Negocio (Tabla Consolidada)

### 13.1 Errores Generados por el Servicio Principal

| Codigo | Mensaje | Condicion | Procedimiento | Lineas |
|---|---|---|---|---|
| `0` | `OK` | Procesamiento exitoso | Main | L39-40 |
| `1` | `Valor del campo cif vacio o invalido` | `LENGTH(TRIM(bodyIn.cif)) = 0` | ValidarEntrada | L57-58 |
| `3` | `No existe contacto transaccional para eliminar del tipo {tipo}` | `activar=FALSE` y `opcion='1'` (no existe en BANCS) | OrquestarTX | L128-129 |
| `4` | `contacto transaccional del tipo {tipo} vacio` | `activar=TRUE` y email y celular vacios | OrquestarTX | L91-92 |

**Fuente:** ESQL principal lineas indicadas.

### 13.2 Errores Generados por UMPClientes0003

| Codigo | Mensaje | Condicion | Procedimiento | Lineas |
|---|---|---|---|---|
| `0` | `OK` | Consulta exitosa con datos | Main | UMP0003 ESQL L33-34 |
| `1` | `Cliente no tiene parametrizado contacto transaccional` | Estado `trxestado='99'` o ambos campos vacios | ConsultarTX067186 | UMP0003 ESQL L72-73, L81-82 |
| `0282` | (propagado de BANCS) | Registro no existe en BANCS | ConsultarTX067186 | UMP0003 ESQL L80 (absorbido por orquestador) |

### 13.3 Errores Generados por UMPClientes0005

| Codigo | Mensaje | Condicion | Procedimiento | Lineas |
|---|---|---|---|---|
| `0` | `OK` | Escritura exitosa | Main | UMP0005 ESQL L33-34 |
| (cualquier) | (propagado de BANCS) | Cualquier error BANCS | InvocarTX067186 | UMP0005 ESQL L68-70 |

### 13.4 Errores de ProcesarErrorMicroservicio (TryCatch)

Ambos UMPs capturan excepciones runtime via nodo TryCatch y las derivan al subflow generico `ProcesarErrorMicroservicio`. El formato de error resultante depende de la libreria `TCSProcesarError` (no analizada directamente).

**Fuente:** UMP0003 subflow lineas 15-23, UMP0005 subflow lineas 15-23.

---

## 14. Errores Runtime

### 14.1 TryCatch en UMPs

Ambos UMPs implementan un nodo `TryCatch` que captura excepciones no controladas:

| UMP | Nodo | Flujo catch | Fuente |
|---|---|---|---|
| UMPClientes0003 | Try Catch | -> ProcesarErrorMicroservicio | UMP0003 subflow L15-23 |
| UMPClientes0005 | Try Catch | -> ProcesarErrorMicroservicio | UMP0005 subflow L15-23 |

### 14.2 Ausencia de TryCatch en el Servicio Principal

El ESQL principal (`ActualizarContactoTransaccional31_Procesar`) NO tiene un bloque TryCatch propio. Las excepciones que ocurran en el Compute node del subflow principal (fuera de los UMPs) serian manejadas por el framework generico `IniciarServicioSOAP`/`FinalizarServicioSOAP` o quedarian sin capturar.

**INFERENCIA:** Es probable que el framework `TCSProcesarServicioSOAP` tenga un manejo global de errores, pero esto no se puede confirmar sin analizar ese artefacto.

### 14.3 Posibles Errores Runtime Identificados

| Escenario | Causa | Impacto |
|---|---|---|
| BANCS timeout | InvocarBancs no recibe respuesta | Manejado por TCSProcesarBancs (INFERENCIA) |
| CIF no numerico | Padding con RIGHT funciona pero BANCS podria rechazar | Error BANCS propagado |
| Null reference en contacto | Si `contactosTransaccional` vacio | NullPointerException en WHILE LASTMOVE |

---

## 15. Configuracion del Servicio

### 15.1 Configuracion via Cola MQ

| Propiedad | Ruta en Environment | Uso | Linea |
|---|---|---|---|
| `longitudCelularInternacional` | `Environment.cache.WSClientes0020Config.longitudCelularInternacional` | Umbral para detectar numero internacional | ESQL principal L221 |
| `prefijoIntExc` | `Environment.cache.WSClientes0020Config.prefijoIntExc` | Prefijo a excluir (prob. "5930") | ESQL principal L222 |
| `prefijoIntEc` | `Environment.cache.WSClientes0020Config.prefijoIntEc` | Prefijo Ecuador correcto (prob. "593") | ESQL principal L223 |

**Fuente:** ESQL principal lineas 202, 221-223. Cola: `CE_WSClientes0020Config` en msgflow linea 10.

### 15.2 Configuracion IIB

| Parametro | Valor | Fuente |
|---|---|---|
| Integration Server | `ISClientes211` | pom.xml L10 |
| URL Selector | `/IntegrationBus/soap/WSClientes0020` | msgflow L13 |
| Allow Query WSDL | `true` | msgflow L13 |
| Use HTTP Transport | `true` | msgflow L13 |
| MQ Transaction Mode | `no` | msgflow L10 |

### 15.3 Dependencias Maven

| Artefacto | GroupId | Version | Scope |
|---|---|---|---|
| TCSProcesarBancs | com.bpichincha.esb | 1.0.2-RC1 | compile |
| TCSProcesarServicioSOAP | com.bpichincha.esb | 1.0.1-RC1 | compile |
| UMPClientes0003 | com.bpichincha.esb | 1.0.0-RC1 | compile |
| UMPClientes0005 | com.bpichincha.esb | 1.0.0-RC1 | compile |
| junit | junit | 4.11 | test |

**Fuente:** pom.xml lineas 130-171.

### 15.4 Mapeo de Configuracion Legacy a Spring Boot (Recomendacion Migracion)

| Legacy (MQ Config) | Propuesta Spring Boot | Tipo |
|---|---|---|
| `longitudCelularInternacional` | `${CCC_PHONE_INTERNATIONAL_LENGTH}` | Integer |
| `prefijoIntExc` | `${CCC_PHONE_PREFIX_EXCLUDE}` | String |
| `prefijoIntEc` | `${CCC_PHONE_PREFIX_ECUADOR}` | String |

---

## 16. Metricas del Servicio (Tabla de Cuantificacion)

| Metrica | Valor | Detalle |
|---|---|---|
| Operaciones SOAP | 1 | ActualizarContactoTransaccional31 |
| UMPs invocados | 2 | UMPClientes0003, UMPClientes0005 |
| TX BANCS distintas | 1 | TX 067186 (3 modos via option) |
| Campos entrada BANCS (consulta, UMP0003) | 5 | instNo, customerNo, option, trxType, trxInstance |
| Campos entrada BANCS (escritura, UMP0005) | 8 | instNo, customerNo, option, trxType, trxInstance, trxcelular, trxemail, trxestado |
| Campos salida BANCS leidos (UMP0003) | 3 | trxestado, trxcelular, trxemail |
| Campos salida BANCS leidos (UMP0005) | 1 | error.codigo (solo validacion) |
| Campos request SOAP (bodyIn) | 5 | cif + contactosTransaccional(tipo, email, celular, activar) |
| Campos request SOAP (headerIn) | 19 | GenericHeaderIn completo (18 campos + bancs opcional con 7 subcampos) |
| Campos response SOAP (bodyOut) | 0 | bodyOUT vacio |
| Campos response SOAP (error) | 7 | codigo, mensaje, mensajeNegocio, tipo, recurso, componente, backend |
| Codigos error negocio propios | 4 | 0 (OK), 1, 3, 4 |
| Codigos error absorbidos de BANCS | 2 | 0282, 1 (en contexto UMP0003) |
| Normalizaciones | 3 | CIF padding, email trim, celular prefijo |
| Propiedades configurables | 3 | longitudCelularInternacional, prefijoIntExc, prefijoIntEc |
| Colas MQ | 1 | CE_WSClientes0020Config |
| Queries SQL | 0 | Sin acceso a BD |
| Subflows en servicio | 1 | ActualizarContactoTransaccional31.subflow |
| Subflows UMP | 2 | ConsultarContactoNotificacion01.subflow, ActualizarContactoTransaccional31.subflow |
| Frameworks genericos | 3 | TCSProcesarServicioSOAP, TCSProcesarBancs, TCSProcesarError |
| Procedimientos ESQL principal | 4 | Main, ValidarEntrada, OrquestarTX, InvocarDatosTransaccionales, ActualizarContactoTransaccional |
| Procedimientos ESQL UMP0003 | 2 | Main, ConsultarTX067186 |
| Procedimientos ESQL UMP0005 | 2 | Main, InvocarTX067186 |
| Dead code | 0 | Todos los procedimientos son invocados |
| Archivos analizados | 14 | Ver seccion 3 |

---

## 17. Clasificacion BUS vs WAS

| Criterio | Evaluacion | Evidencia |
|---|---|---|
| Protocolo de entrada | SOAP (SOAPInput node) | msgflow L13 |
| Framework | IIB (IBM Integration Bus) | pom.xml packaging=iib-bar |
| Transporte | HTTP sincrono | msgflow L13 `useHTTPTransport="true"` |
| Cola MQ | Solo para configuracion, NO para mensajeria de negocio | msgflow L10 |
| Backend | BANCS via InvocarBancs (TCP/IP socket, INFERENCIA) | subflow L22 |
| Patron | Request-Response sincrono | ESQL: PROPAGATE y lectura de Environment |

**Clasificacion: BUS (Bus de Integracion)**

El servicio se ejecuta en IBM Integration Bus (IIB), no en WebSphere Application Server (WAS). Usa nodos nativos de IIB (SOAPInput, MQInput, Compute, RouteToLabel, Label) y subflows para la orquestacion. El patron es sincrono request-response via SOAP sobre HTTP.

---

## 18. Items Intencionalmente Omitidos

| Item | Razon |
|---|---|
| Contenido de TCSProcesarServicioSOAP (IniciarServicioSOAP, FinalizarServicioSOAP) | Framework generico compartido; no es especifico de este servicio. Su analisis aplica globalmente. |
| Contenido de TCSProcesarBancs (InvocarBancs) | Framework generico de invocacion BANCS; no contiene logica de negocio especifica. |
| Contenido de TCSProcesarError (ProcesarErrorMicroservicio) | Framework generico de errores; no afecta la logica de negocio. |
| Formato exacto del mensaje XML enviado a BANCS | Depende de InvocarBancs; los campos estan documentados en seccion 5. |
| Formato del mensaje en cola CE_WSClientes0020Config | No se encontro evidencia del XML de configuracion; los campos consumidos estan documentados. |
| SOAP Faults | El servicio no genera SOAP Faults explicitamente; los errores van en GenericError dentro del envelope de respuesta normal. |
| Seguridad/Autenticacion | No hay evidencia de WS-Security ni autenticacion en los archivos analizados. Probablemente manejado en capa WSO2 (INFERENCIA basada en documentacion del headerIn). |

---

## 19. Incertidumbres y Supuestos

### 19.1 Incertidumbres

| # | Incertidumbre | Impacto en migracion | Severidad |
|---|---|---|---|
| I-1 | Valores exactos de `longitudCelularInternacional`, `prefijoIntExc`, `prefijoIntEc` provienen de la cola MQ y no estan en el codigo | Necesario configurar en env vars. Los valores probables son 12, "5930", "593" respectivamente pero NO hay evidencia directa. | MEDIA |
| I-2 | Formato exacto del mensaje XML en cola `CE_WSClientes0020Config` | Afecta la definicion del `@ConfigurationProperties` | BAJA |
| I-3 | Comportamiento exacto de `ProcesarErrorMicroservicio` ante excepciones runtime | Define estructura del error en respuesta SOAP ante fallos no controlados | MEDIA |
| I-4 | Campos adicionales que BANCS TX 067186 pueda retornar y que no sean leidos | Podria haber campos ignorados que sean relevantes en el futuro | BAJA |
| I-5 | Comportamiento del label `et_ump` — se asume que rutea al subflow UMP correcto segun `Environment.UMPSubflow.ump` | Si el ruteo es diferente, la logica de invocacion UMP cambiaria | MEDIA |
| I-6 | Codigos de backend (`Environment.cache.codigosBackend.iib`) — valor exacto desconocido | Afecta el campo `backend` del GenericError | BAJA |

### 19.2 Supuestos

| # | Supuesto | Base |
|---|---|---|
| S-1 | `prefijoIntExc` = "5930" y `prefijoIntEc` = "593" | INFERENCIA del comentario "controlar los numeros de telefono con 5930" (L220) y del `SUBSTRING(celular FROM 5)` que descarta 4 chars |
| S-2 | `longitudCelularInternacional` esta en el rango 10-12 | INFERENCIA: celulares Ecuador son 10 digitos, internacionales hasta 15 |
| S-3 | La propagacion a label `et_ump` en el subflow principal es interceptada por el framework IniciarServicioSOAP que rutea al UMP correcto | INFERENCIA de la estructura del subflow que tiene labels `et_ConsultarContactoNotificacion01` y `et_ActualizarContactoTransaccional31` |
| S-4 | El bodyOut de BANCS en modo consulta (option=2) contiene los campos `trxestado`, `trxcelular`, `trxemail` como campos de primer nivel | EVIDENCIA DIRECTA del ESQL de UMP0003 lineas 71, 80, 89-90 |
| S-5 | El servicio retorna HTTP 200 para TODOS los casos (exito y error de negocio), con el error descrito en el bloque GenericError | INFERENCIA del patron estandar IIB de Banco Pichincha |

---

## 20. Score de Confianza Pre-Migracion

### 20.1 Score por Area

| Area | Score | Justificacion |
|---|---|---|
| Contrato SOAP (request/response) | **95%** | EVIDENCIA DIRECTA completa de WSDL + XSD + GenericSOAP.xsd. Solo falta confirmar si hay validaciones de schema adicionales en el framework. |
| Logica de negocio (orquestacion) | **95%** | EVIDENCIA DIRECTA completa del ESQL principal. Todos los procedimientos, bifurcaciones y validaciones estan documentados. |
| Mapeo TX BANCS (campos entrada) | **98%** | EVIDENCIA DIRECTA completa de ambos UMPs. Los 8 campos de entrada (escritura) y 5 campos (consulta) estan confirmados en el codigo fuente. |
| Mapeo TX BANCS (campos salida) | **90%** | EVIDENCIA DIRECTA de los campos leidos (trxestado, trxcelular, trxemail). Podria haber campos adicionales retornados por BANCS que no se leen. |
| Normalizaciones | **95%** | EVIDENCIA DIRECTA de las 3 normalizaciones (CIF, email, celular). Valores de config del celular son INFERENCIA. |
| Manejo de errores | **90%** | EVIDENCIA DIRECTA de todos los codigos y mensajes generados. Falta detalle de ProcesarErrorMicroservicio para errores runtime. |
| Configuracion | **80%** | Se conocen las 3 propiedades configurables y la cola MQ, pero los valores exactos dependen del contenido del mensaje MQ. |
| Flujo de nodos (msgflow/subflow) | **90%** | EVIDENCIA DIRECTA de la estructura de nodos. Falta detalle interno de IniciarServicioSOAP y FinalizarServicioSOAP. |

### 20.2 Score Global

| Metrica | Valor |
|---|---|
| **Score global de confianza** | **92%** |
| Tipo de evidencia predominante | EVIDENCIA DIRECTA |
| Archivos con evidencia directa | 14 de 14 analizados |
| Archivos referenciados no analizados | 3 (TCSProcesarServicioSOAP, TCSProcesarBancs, TCSProcesarError) |

### 20.3 Justificacion del Score Alto

El score de 92% se justifica porque:

1. **Se tuvo acceso directo al codigo ESQL de AMBOS UMPs**, lo que permite documentar los campos exactos de la TX BANCS 067186 sin inferencias.
2. **La TX BANCS es una sola (067186)** con 3 modos de operacion claramente diferenciados por el campo `option`, todos confirmados en el codigo fuente.
3. **El contrato SOAP esta completo** incluyendo los tipos genericos (GenericHeaderIn, GenericHeaderOut, GenericError, BancsTeller).
4. **No hay acceso a BD, ni colas MQ de negocio, ni invocaciones HTTP externas** — la complejidad esta acotada a la logica ESQL y la TX BANCS.
5. **Las unicas incertidumbres significativas** son los valores de configuracion (que se resuelven con env vars) y el comportamiento del framework generico (que es comun a todos los servicios).

### 20.4 Riesgos Residuales para Migracion

| Riesgo | Probabilidad | Impacto | Mitigacion |
|---|---|---|---|
| Valores de config del celular incorrectos | BAJA | MEDIO | Validar contra ambiente de produccion |
| Campos BANCS adicionales no documentados | BAJA | BAJO | Revisar especificacion TX 067186 de BANCS |
| Comportamiento diferente del framework generico | BAJA | MEDIO | Usar patron de referencia `tnd-msa-sp-wsclientes0024` |
| Logica de ruteo `et_ump` diferente a lo inferido | BAJA | ALTO | Confirmar con equipo de soporte IIB |

---

*Documento generado automaticamente. Toda afirmacion esta respaldada por evidencia directa del codigo fuente analizado, con archivo y numero de linea citados. Las inferencias estan explicitamente marcadas como tales.*
